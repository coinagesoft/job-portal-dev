"use client";

import React, { useState, useEffect, useRef, useMemo } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import styles from "./post-job.module.css";
import { useToast } from "@/components/Toast";

import currencyCodes from "currency-codes";
import countries from "world-countries";
import JobPreviewModal from "@/components/JobPreviewModal";
import { mapResumeToForm } from "@/utils/jobFormMapper";
import { Country, State } from "country-state-city";
import { resolveCountry } from "@/utils/locationResolver";

const ALL_CSC_COUNTRIES = Country.getAllCountries();

const getCountryIso = (countryName) => {
  if (!countryName) return "";
  const cleaned = countryName.trim().toLowerCase();

  const match = ALL_CSC_COUNTRIES.find(
    (c) => c.name.trim().toLowerCase() === cleaned || c.isoCode.trim().toLowerCase() === cleaned
  );
  if (match) return match.isoCode;

  const resolvedName = resolveCountry(countryName);
  if (resolvedName) {
    const matchResolved = ALL_CSC_COUNTRIES.find(
      (c) => c.name.trim().toLowerCase() === resolvedName.trim().toLowerCase()
    );
    if (matchResolved) return matchResolved.isoCode;
  }

  const partial = ALL_CSC_COUNTRIES.find(
    (c) => c.name.trim().toLowerCase().includes(cleaned) || cleaned.includes(c.name.trim().toLowerCase())
  );
  return partial?.isoCode || "";
};

const getStatesForCountry = (countryName) => {
  const iso = getCountryIso(countryName);
  if (!iso) return [];
  return State.getStatesOfCountry(iso).map((s) => s.name);
};

const countryOptions = countries
  .map((country) => country.name.common)
  .sort((a, b) => a.localeCompare(b));

const currencies = currencyCodes.data.map((currency) => ({
  value: currency.code,
  label: `${currency.code} - ${currency.currency}`,
}));

import {
  saveJobDetails,
  saveCompensation,
  saveSkills,
  saveEligibility,
  saveLocation,
  saveQuestions,
  publishJob,
  saveDraft,
  getJobResume,
  generateJobDescription,
  getInlineSuggestion,
  searchRoles,
  suggestSkills,
  getJobPostDropdownData,
  getJobDropdowns,
  submitJobSuggestion,
} from "@/services/recruiter/recruiterJobPostService";

import {
  getIndustries,
  submitIndustrySuggestion,
  getTradeCategoriesByIndustry,
  getSubTradesByTradeCategory,
} from "@/services/recruiter/recruiterRegistrationService";
import { getDecodedToken } from "@/utils/authHelper";

const COMBOBOX_SEARCH_THRESHOLD = 8;

/* ─── constant used to mark the "type your own" option on API-driven dropdowns ─── */
const OTHER_OPTION = "Other";

/** Case-insensitive check for whether a dropdown value is the "Other" sentinel */
const isOtherValue = (value) => (value || "").trim().toLowerCase() === "other";

/**
 * Normalizes a list of API names into Combobox-ready options and guarantees
 * an "Other" entry is always present at the end (API lists don't include it,
 * static fallback lists already do — Set-based unique keeps either case safe).
 */
const withOtherOption = (names) => {
  const cleaned = (names || []).filter(Boolean);
  const deduped = Array.from(new Set(cleaned));
  if (!deduped.some((n) => isOtherValue(n))) {
    deduped.push(OTHER_OPTION);
  }
  return deduped;
};

/* ─── static data ─────────────────────────────────────────────────────────── */
const roleCategories = [
  "Welding",
  "Fabrication",
  "Electrician",
  "Plumber",
  "Machine Operator",
  "Marine Crew",
  "Warehouse",
  "Carpenter",
  "Mason",
  "Painter",
  "HVAC Technician",
  "Rigger",
  "Scaffolder",
  "Crane Operator",
  "Forklift Operator",
  "Mechanic",
  "Diesel Mechanic",
  "Pipefitter",
  "Boilermaker",
  "Insulation Technician",
  "Sheet Metal Worker",
  "CNC Operator",
  "Quality Inspector",
  "Safety Officer",
  "Logistics Coordinator",
  "Driver",
  "Security Guard",
  "Housekeeping Staff",
  "Chef / Cook",
  "Waiter / Steward",
  "Technician (General)",
  "Civil Engineer",
  "Site Supervisor",
  "Store Keeper",
  "Data Entry Operator",
  "Customer Service Executive",
  "Other",
];

const jobPostTypes = [
  { label: "Regular Hiring", value: "Regular Hiring" },
  { label: "Hot Vacancy", value: "Hot Vacancy" },
  { label: "Urgent Hiring", value: "Urgent Hiring" },
  { label: "Bulk Hiring", value: "Bulk Hiring" },
  // { label: "Classified", value: "Classified" },
];

const employmentTypeOptions = [
  { label: "Full Time", value: "Full Time" },
  { label: "Part Time", value: "Part Time" },
  { label: "Contract", value: "Contract" },
  { label: "Freelance", value: "Freelance" },
  { label: "Internship / Trainee", value: "Internship" },
  // { label: "Apprenticeship", value: "Apprenticeship" }, 
  // { label: "Permanent", value: "Permanent" }, 
  // { label: "Temporary", value: "Temporary" }, 
];

const employmentModeOptions = [
  { label: "Onsite", value: "Onsite" },
  { label: "Remote", value: "Remote" },
  { label: "Hybrid", value: "Hybrid" },
];
const suggestedSkills = [
  "Java",
  "JavaScript",
  "Spring Boot",
  "Welding Inspection",
  "Safety Compliance",
  "AutoCAD",
];
const suggestedBenefits = [
  "Health Insurance",
  "Provident Fund",
  "Paid Leave",
  "Accommodation",
  "Food Allowance",
  "Transport",
  "Overtime Pay",
  "Annual Bonus",
  "Life Insurance",
  "Skill Training",
];
// Personal documents — proof of identity, unrelated to the trade/job itself
const suggestedPersonalDocs = [
  "Government-issued ID",
  "Aadhaar Card / Identity Proof",
  "Passport",
  "Driving License",
  "Medical Fitness Certificate",
  "Police Verification Certificate",
];

// Working documents — trade/professional qualifications tied to the job
const suggestedWorkingDocs = [
  "ITI Certificate",
  "Diploma Certificate",
  "Degree Certificate",
  "Safety Training Certificate",
  "Heavy Equipment Operator Certificate",
  "Forklift Operator License",
  "Welding Certification (CSWIP / AWS)",
  "Work Experience Certificate",
];

const suggestedLanguages = [
  "English",
  "Hindi",
  "Marathi",
  "Tamil",
  "Telugu",
  "Kannada",
  "Bengali",
  "Gujarati",
  "Punjabi",
  "Malayalam",
  "Odia",
  // "Local Language", 
];

const industryOptions = [
  "Recruitement Agency",
  "Construction & Infrastructure",
  "Marine & Shipping",
  "Oil & Gas",
  "Manufacturing",
  "Logistics & Transportation",
  "Warehousing & Supply Chain",
  "Hospitality & Facilities",
  "Ports & Terminals",
  "Mining",
  "Aviation",
  "Renewable Energy",
  "Engineering Services",
  "Healthcare",
  "IT & Technology",
  "Retail",
  "Power & Utilities",
  "Chemicals & Petrochemicals",
  "Automotive",
  "Real Estate",
  "Telecommunications",
  "Agriculture",
  "Banking & Financial Services",
  "Education",
  "Government / Public Sector",
  "Other",
];


const departmentOptions = [
  "Operations",
  "Production",
  "Maintenance",
  "Quality Assurance",
  "Human Resources",
  "Administration",
  "Logistics",
  "Safety",
  "Procurement",
  "Other",
];


const indianStates = [
  "Andhra Pradesh",
  "Assam",
  "Bihar",
  "Delhi",
  "Goa",
  "Gujarat",
  "Haryana",
  "Jharkhand",
  "Karnataka",
  "Kerala",
  "Madhya Pradesh",
  "Maharashtra",
  "Odisha",
  "Punjab",
  "Rajasthan",
  "Tamil Nadu",
  "Telangana",
  "Uttar Pradesh",
  "West Bengal",
  "Other",
];

const salaryDisplayOptions = [
  { value: "Show Range", label: "Show Range" },
  { value: "Show Min Only", label: "Show Minimum Only" },
  { value: "Show Max Only", label: "Show Maximum Only" },
  { value: "Negotiable", label: "Negotiable" },
  { value: "Hide Salary", label: "Hide Salary" },
];

const salaryPeriodOptions = [
  { value: "Hourly", label: "Hourly" },
  { value: "Monthly", label: "Monthly" },
  { value: "Annual", label: "Annual" },
];

const educationOptions = [
  { value: "No Specific Requirement", label: "No Specific Requirement" },
  { value: "Below 10th", label: "Below 10th" },
  { value: "10th Pass", label: "10th Pass" },
  { value: "12th Pass", label: "12th Pass" },
  { value: "ITI Diploma", label: "ITI / Diploma" },
  { value: "Graduate", label: "Graduate" },
  { value: "Post Graduate", label: "Post Graduate" },
];
const genderOptions = [
  { value: "Any", label: "Not Specified" },
  { value: "Male", label: "Male" },
  { value: "Female", label: "Female" },
];
const locationTypeOptions = [
  { value: "Onshore", label: "Onshore" },
  { value: "Offshore", label: "Offshore" },
];
const companyVisibilityOptions = [
  { value: "ShowName", label: "Show Company Name" },
  { value: "HideName", label: "Hide Company Name" },
];

const JOB_STEPS = [
  { id: "job-details", step: "01", title: "Job Details" },
  { id: "compensation", step: "02", title: "Compensation" },
  { id: "skills-jd", step: "03", title: "Skills & JD" },
  { id: "eligibility", step: "04", title: "Eligibility" },
  { id: "location", step: "05", title: "Location" },
  { id: "screening-questions", step: "06", title: "Questions" },
  { id: "publishing", step: "07", title: "Publishing" },
];


const contractPeriodOptions = [
  { label: "1 Month", value: "1 Month" },
  { label: "3 Months", value: "3 Months" },
  { label: "6 Months", value: "6 Months" },
  { label: "1 Year", value: "1 Year" },
  { label: "2 Years", value: "2 Years" },
  { label: "3+ Years", value: "3+ Years" },
  { label: "Other", value: "Other" },
];
/** 
 * Single source of truth for "is this job ready to publish?". 
 * Walks every step's required fields (mirroring each handleStepN's own 
 * checks) so the Step 7 checklist and the final Publish guard never 
 * drift out of sync with each other. 
 * Returns an array of { stepNum, title, message } — empty means all good. 
 */
function validateAllSteps(jobForm) {
  const issues = [];

  // Step 1 – Job Details 
  if (!jobForm.JobTitle?.trim())
    issues.push({ stepNum: 1, title: "Job Details", message: "Job Title is required" });
  if (!jobForm.TradeCategory)
    issues.push({ stepNum: 1, title: "Job Details", message: "Trade / Role Category is required" });
  if (isOtherValue(jobForm.TradeCategory) && !jobForm.TradeCategoryOther?.trim())
    issues.push({ stepNum: 1, title: "Job Details", message: "Please specify the Trade Category for 'Other'" });
  if (!jobForm.IndustryType)
    issues.push({ stepNum: 1, title: "Job Details", message: "Industry Type is required" });
  if (isOtherValue(jobForm.IndustryType) && !jobForm.IndustryTypeOther?.trim())
    issues.push({ stepNum: 1, title: "Job Details", message: "Please specify the Industry Type for 'Other'" });
  if (isOtherValue(jobForm.Department) && !jobForm.DepartmentOther?.trim())
    issues.push({ stepNum: 1, title: "Job Details", message: "Please specify the Department for 'Other'" });
  if (!jobForm.JobType)
    issues.push({ stepNum: 1, title: "Job Details", message: "Job Type is required" });
  if (
    jobForm.IsClientHiring &&
    !jobForm.ClientName?.trim()
  ) {
    issues.push({
      stepNum: 1,
      title: "Job Details",
      message: "Client Name is required"
    });
  }
  if (!jobForm.EmploymentType)
    issues.push({ stepNum: 1, title: "Job Details", message: "Employment Type is required" });
  if (!jobForm.EmploymentMode)
    issues.push({ stepNum: 1, title: "Job Details", message: "Employment Mode is required" });

  // Step 2 – Compensation
  if (!jobForm.SalaryMin)
    issues.push({ stepNum: 2, title: "Compensation", message: "Minimum Salary is required" });
  else if (Number(jobForm.SalaryMin) < 0)
    issues.push({ stepNum: 2, title: "Compensation", message: "Minimum Salary cannot be negative" });
  if (!jobForm.SalaryMax)
    issues.push({ stepNum: 2, title: "Compensation", message: "Maximum Salary is required" });
  else if (Number(jobForm.SalaryMax) < 0)
    issues.push({ stepNum: 2, title: "Compensation", message: "Maximum Salary cannot be negative" });
  if (
    jobForm.SalaryMin &&
    jobForm.SalaryMax &&
    Number(jobForm.SalaryMin) > Number(jobForm.SalaryMax)
  )
    issues.push({ stepNum: 2, title: "Compensation", message: "Minimum Salary cannot be greater than Maximum Salary" });

  // Step 3 – Skills & JD
  if (!jobForm.JobDescription?.trim())
    issues.push({ stepNum: 3, title: "Skills & JD", message: "Job Description is required" });

  // Step 1 – Experience range
  if (
    jobForm.ExperienceMinYears !== "" &&
    jobForm.ExperienceMinYears != null &&
    (Number(jobForm.ExperienceMinYears) < 0 || Number(jobForm.ExperienceMinYears) > 50)
  )
    issues.push({ stepNum: 1, title: "Job Details", message: "Experience Min must be between 0 and 50 years" });
  if (
    jobForm.ExperienceMaxYears !== "" &&
    jobForm.ExperienceMaxYears != null &&
    (Number(jobForm.ExperienceMaxYears) < 0 || Number(jobForm.ExperienceMaxYears) > 50)
  )
    issues.push({ stepNum: 1, title: "Job Details", message: "Experience Max must be between 0 and 50 years" });
  if (
    jobForm.ExperienceMinYears !== "" &&
    jobForm.ExperienceMaxYears !== "" &&
    Number(jobForm.ExperienceMinYears) > Number(jobForm.ExperienceMaxYears)
  )
    issues.push({ stepNum: 1, title: "Job Details", message: "Experience Min cannot be greater than Experience Max" });

  // Step 4 – Eligibility
  if (!jobForm.Vacancies)
    issues.push({ stepNum: 4, title: "Eligibility", message: "Number of Vacancies is required" });

  if (
    jobForm.AgeMin !== "" &&
    jobForm.AgeMin != null &&
    (Number(jobForm.AgeMin) < 18 || Number(jobForm.AgeMin) > 99)
  )
    issues.push({ stepNum: 4, title: "Eligibility", message: "Minimum Age must be between 18 and 99 years" });
  if (
    jobForm.AgeMax !== "" &&
    jobForm.AgeMax != null &&
    (Number(jobForm.AgeMax) < 18 || Number(jobForm.AgeMax) > 99)
  )
    issues.push({ stepNum: 4, title: "Eligibility", message: "Maximum Age must be between 18 and 99 years" });
  if (
    jobForm.AgeMin !== "" &&
    jobForm.AgeMax !== "" &&
    Number(jobForm.AgeMin) > Number(jobForm.AgeMax)
  )
    issues.push({ stepNum: 4, title: "Eligibility", message: "Minimum Age cannot be greater than Maximum Age" });


  // Step 5 – Location 
  if (!jobForm.LocationType)
    issues.push({ stepNum: 5, title: "Location", message: "Location Type is required" });
  if (jobForm.LocationType === "Offshore" && !jobForm.OffshoreVesselName?.trim())
    issues.push({ stepNum: 5, title: "Location", message: "Vessel / Platform Name is required" });

  // Step 1 – Job Details (continued)
  if (
    jobForm.DutyHoursPerDay !== "" &&
    jobForm.DutyHoursPerDay != null &&
    (Number(jobForm.DutyHoursPerDay) < 1 || Number(jobForm.DutyHoursPerDay) > 24)
  )
    issues.push({ stepNum: 1, title: "Job Details", message: "Duty Hours Per Day must be between 1 and 24" });

  // Step 7 – Publishing
  if (!jobForm.ApplicationDeadline)
    issues.push({ stepNum: 7, title: "Publishing", message: "Application Deadline is required" });
  else if (jobForm.ApplicationDeadline < todayDateString())
    issues.push({ stepNum: 7, title: "Publishing", message: "Application Deadline cannot be in the past" });

  return issues;
}

// yyyy-MM-dd for today, in the local timezone — matches the format a date
// input's value uses, so it can be compared directly as a string.
function todayDateString() {
  const d = new Date();
  const offset = d.getTimezoneOffset();
  return new Date(d.getTime() - offset * 60000).toISOString().split("T")[0];
}

/* ─── helpers ─────────────────────────────────────────────────────────────── */
function Field({ label, required, hint, children }) {
  return (
    <div className={styles.field}>
      <label className={styles.label}>
        {label}
        {required && <span className={styles.required}>*</span>}
      </label>
      {children}
      {hint && <p className={styles.hint}>{hint}</p>}
    </div>
  );
}

/** 
 * Dropdown-with-search field: pick from a known list only — typing is purely 
 * a filter/search aid over the option list and never sets the field's value 
 * on its own. The underlying value only changes when the user actually picks 
 * an option (click, or pressing Enter on an exact/singular match). If the 
 * user types something that matches nothing and clicks away/tabs out, the 
 * text snaps back to whatever is actually selected. 
 */


function Combobox({ value, onChange, options, placeholder }) {
  const normalized = (options || []).map((o) =>
    typeof o === "string" ? { value: o, label: o } : o
  );
  const isSearchable = normalized.length > COMBOBOX_SEARCH_THRESHOLD;

  const [open, setOpen] = useState(false);
  const wrapRef = useRef(null);
  const justSelectedRef = useRef(false);

  const matched = normalized.find((o) => o.value === value);
  const [query, setQuery] = useState(matched ? matched.label : (value || ""));

  useEffect(() => {
    const m = normalized.find((o) => o.value === value);
    setQuery(m ? m.label : (value || ""));
    // eslint-disable-next-line react-hooks/exhaustive-deps 
  }, [value]);

  const revertIfUnmatched = () => {
    const m = normalized.find((o) => o.value === value);
    setQuery(m ? m.label : (value || ""));
  };

  useEffect(() => {
    const onClickOutside = (e) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) {
        setOpen(false);
        revertIfUnmatched();
      }
    };
    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
    // eslint-disable-next-line react-hooks/exhaustive-deps 
  }, [value, options]);

  const filtered = isSearchable && query
    ? (() => {
      const q = query.toLowerCase().trim();
      const starts = [];
      const contains = [];
      for (const o of normalized) {
        const label = o.label.toLowerCase();
        if (label.startsWith(q)) starts.push(o);
        else if (label.includes(q)) contains.push(o);
      }
      starts.sort((a, b) => a.label.localeCompare(b.label));
      contains.sort((a, b) => a.label.localeCompare(b.label));
      return [...starts, ...contains];
    })()
    : normalized;

  const selectOption = (opt) => {
    justSelectedRef.current = true;
    onChange(opt.value);
    setQuery(opt.label);
    setOpen(false);
  };

  return (
    <div ref={wrapRef} style={{ position: "relative" }}>
      <input
        className={styles.control}
        value={query}
        readOnly={!isSearchable}
        placeholder={placeholder || "Type to search…"}
        autoComplete="off"
        onChange={(e) => {
          if (!isSearchable) return;
          setQuery(e.target.value);
          setOpen(true);
        }}
        onFocus={() => setOpen(true)}
        onClick={() => setOpen(true)}
        onKeyDown={(e) => {
          if (!isSearchable) {
            if (e.key === "Enter" || e.key === " ") {
              e.preventDefault();
              setOpen((o) => !o);
            } else if (e.key === "Escape") {
              setOpen(false);
            }
            return;
          }
          if (e.key === "Enter") {
            e.preventDefault();
            if (filtered.length === 1) {
              selectOption(filtered[0]);
            } else {
              const exact = normalized.find(
                (o) => o.label.toLowerCase() === query.trim().toLowerCase()
              );
              if (exact) selectOption(exact);
              else revertIfUnmatched();
            }
            setOpen(false);
          } else if (e.key === "Escape") {
            setOpen(false);
            revertIfUnmatched();
          }
        }}
        onBlur={() => {
          window.setTimeout(() => {
            if (justSelectedRef.current) {
              justSelectedRef.current = false;
              return;
            }
            setOpen(false);
            if (isSearchable) revertIfUnmatched();
          }, 0);
        }}
        style={!isSearchable ? { cursor: "pointer", backgroundColor: "#fff" } : undefined}
      />
      {open && filtered.length > 0 && (
        <div
          style={{
            position: "absolute",
            top: "calc(100% + 4px)",
            left: 0,
            right: 0,
            zIndex: 40,
            background: "#fff",
            border: "1px solid rgba(18,35,89,0.12)",
            borderRadius: 10,
            boxShadow: "0 12px 28px rgba(18,35,89,0.14)",
            maxHeight: 220,
            overflowY: "auto",
          }}
        >
          {filtered.map((opt) => (
            <div
              key={opt.value}
              onMouseDown={() => selectOption(opt)}
              style={{
                padding: "10px 16px",
                fontSize: "14px",
                cursor: "pointer",
                color: "#122359",
                background: opt.label === query ? "#FFF4E0" : "transparent",
              }}
              onMouseEnter={(e) => (e.currentTarget.style.background = "#FFF4E0")}
              onMouseLeave={(e) =>
              (e.currentTarget.style.background =
                opt.label === query ? "#FFF4E0" : "transparent")
              }
            >
              {opt.label}
            </div>
          ))}
        </div>
      )}
      {open && filtered.length === 0 && (
        <div
          style={{
            position: "absolute",
            top: "calc(100% + 4px)",
            left: 0,
            right: 0,
            zIndex: 40,
            background: "#fff",
            border: "1px solid rgba(18,35,89,0.12)",
            borderRadius: 10,
            boxShadow: "0 12px 28px rgba(18,35,89,0.14)",
            padding: "10px 16px",
            fontSize: 13,
            color: "#94a3b8",
          }}
        >
          No matches — pick from the list
        </div>
      )}
    </div>
  );
}

function MasterHierarchyCombobox({
  value,
  onChange,
  options = [],
  placeholder,
  disabled = false,
  loading = false,
  addLabel,
  onAddNew,
}) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");

  const selected = options.find((x) => {
    const optionValue =
      x?.value ??
      x?.id ??
      x?.Id ??
      x?.registrationIndustryId ??
      x?.RegistrationIndustryId ??
      x?.tradeCategoryId ??
      x?.TradeCategoryId ??
      x?.subTradeId ??
      x?.SubTradeId;

    return optionValue === value;
  });
  const filteredOptions = options.filter((option) => {
    const label =
      option?.label ??
      option?.name ??
      option?.Name ??
      "";

    return label
      .toString()
      .toLowerCase()
      .includes(search.toLowerCase());
  });

  useEffect(() => {
    const handleOutsideClick = (event) => {
      if (!event.target.closest("[data-master-combobox]")) {
        setOpen(false);
      }
    };

    document.addEventListener("mousedown", handleOutsideClick);

    return () => {
      document.removeEventListener("mousedown", handleOutsideClick);
    };
  }, []);

  return (
    <div
      data-master-combobox
      style={{
        position: "relative",
        width: "100%",
      }}
    >
      <button
        type="button"
        disabled={disabled}
        onClick={() => !disabled && setOpen((prev) => !prev)}
        style={{
          width: "100%",
          minHeight: 42,
          padding: "9px 12px",
          border: "1px solid #d6d3d1",
          borderRadius: 8,
          background: disabled ? "#f5f5f4" : "#fff",
          color: selected ? "#292524" : "#78716c",
          textAlign: "left",
          cursor: disabled ? "not-allowed" : "pointer",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <span>
          {loading
            ? "Loading..."
            : selected?.label ??
            selected?.name ??
            selected?.Name ??
            placeholder}
        </span>

        <span style={{ fontSize: 12 }}>▼</span>
      </button>

      {open && !disabled && (
        <div
          style={{
            position: "absolute",
            top: "calc(100% + 5px)",
            left: 0,
            right: 0,
            zIndex: 1000,
            background: "#fff",
            border: "1px solid #e7e5e4",
            borderRadius: 10,
            boxShadow: "0 8px 25px rgba(0,0,0,0.12)",
            overflow: "hidden",
          }}
        >
          <div style={{ padding: 8 }}>
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search..."
              autoFocus
              style={{
                width: "100%",
                padding: "8px 10px",
                border: "1px solid #d6d3d1",
                borderRadius: 7,
                outline: "none",
              }}
            />
          </div>

          <div
            style={{
              maxHeight: 220,
              overflowY: "auto",
            }}
          >
            {loading ? (
              <div
                style={{
                  padding: 12,
                  color: "#78716c",
                  fontSize: 13,
                }}
              >
                Loading...
              </div>
            ) : filteredOptions.length > 0 ? (
              filteredOptions.map((option, index) => {
                const optionValue =
                  option?.value ??
                  option?.id ??
                  option?.Id ??
                  option?.registrationIndustryId ??
                  option?.RegistrationIndustryId ??
                  option?.tradeCategoryId ??
                  option?.TradeCategoryId ??
                  option?.subTradeId ??
                  option?.SubTradeId ??
                  `option-${index}`;

                const optionLabel =
                  option?.label ??
                  option?.name ??
                  option?.Name ??
                  "";

                return (
                  <button
                    key={String(optionValue)}
                    type="button"
                    onClick={() => {
                      onChange(optionValue);
                      setSearch("");
                      setOpen(false);
                    }}
                    style={{
                      width: "100%",
                      border: "none",
                      background:
                        value === optionValue
                          ? "#f5f5f4"
                          : "#fff",
                      padding: "10px 12px",
                      textAlign: "left",
                      cursor: "pointer",
                      fontSize: 14,
                    }}
                  >
                    {optionLabel}
                  </button>
                );
              })
            ) : (<div
              style={{
                padding: "12px",
                color: "#78716c",
                fontSize: 13,
              }}
            >
              No options available.
            </div>
            )}
          </div>

          <div
            style={{
              borderTop: "1px solid #e7e5e4",
              padding: 8,
            }}
          >
            <button
              type="button"
              onClick={() => {
                setOpen(false);
                setSearch("");
                onAddNew?.();
              }}
              style={{
                width: "100%",
                border: "none",
                background: "#f8fafc",
                color: "#2563eb",
                padding: "9px 10px",
                borderRadius: 7,
                textAlign: "left",
                fontWeight: 600,
                cursor: "pointer",
                fontSize: 13,
              }}
            >
              {addLabel}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/** 
 * Same dropdown-with-typing UX as Combobox, but the option list comes from 
 * a live API call (GET /api/recruiter/jobs/search-roles) instead of a fixed 
 * array — used for "Role / Specialisation" so suggestions are based on roles 
 * already posted across the platform. Falls back to free typing (AllowCustom) 
 * when there are no matches or the query is too short. 
 */
function AsyncCombobox({ value, onChange, fetchOptions, placeholder, minChars = 2 }) {
  const [open, setOpen] = useState(false);
  const [options, setOptions] = useState([]);
  const [loading, setLoading] = useState(false);
  const wrapRef = useRef(null);
  const debounceRef = useRef(null);

  useEffect(() => {
    const onClickOutside = (e) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, []);

  const runSearch = (q) => {
    clearTimeout(debounceRef.current);
    if (!q || q.length < minChars) {
      setOptions([]);
      return;
    }
    debounceRef.current = setTimeout(async () => {
      setLoading(true);
      try {
        const result = await fetchOptions(q);
        setOptions(result?.suggestions ?? []);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }, 300);
  };

  return (
    <div ref={wrapRef} style={{ position: "relative" }}>
      <input
        className={styles.control}
        value={value || ""}
        placeholder={placeholder || "Type to search…"}
        autoComplete="off"
        onChange={(e) => {
          onChange(e.target.value);
          setOpen(true);
          runSearch(e.target.value);
        }}
        onFocus={() => setOpen(true)}
      />
      {open && (loading || options.length > 0) && (
        <div
          style={{
            position: "absolute",
            top: "calc(100% + 4px)",
            left: 0,
            right: 0,
            zIndex: 40,
            background: "#fff",
            border: "1px solid rgba(18,35,89,0.12)",
            borderRadius: 10,
            boxShadow: "0 12px 28px rgba(18,35,89,0.14)",
            maxHeight: 220,
            overflowY: "auto",
          }}
        >
          {loading ? (
            <div style={{ padding: "10px 16px", fontSize: 13, color: "#66789c" }}>
              Searching…
            </div>
          ) : (
            options.map((opt) => (
              <div
                key={opt}
                onMouseDown={() => {
                  onChange(opt);
                  setOpen(false);
                }}
                style={{
                  padding: "10px 16px",
                  fontSize: "14px",
                  cursor: "pointer",
                  color: "#122359",
                }}
                onMouseEnter={(e) => (e.currentTarget.style.background = "#FFF4E0")}
                onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
              >
                {opt}
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}

/** Split a comma-separated string into a trimmed array, ignoring blanks */
const splitComma = (value) =>
  value
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);

/** Join an array back to a comma-separated display string */
const joinComma = (arr) => (arr ?? []).join(", ");

/** Toggle a value inside a comma-separated string (add if absent, remove if present) */
const toggleCommaValue = (currentString, item) => {
  const list = splitComma(currentString || "");
  const next = list.includes(item)
    ? list.filter((x) => x !== item)
    : [...list, item];
  return joinComma(next);
};

/** 
 * "Pick from a list, don't type" multi-select rendered as toggleable chips. 
 * Used for fields that should only ever be built by selecting predefined 
 * options — never free-typed — such as required licences/documents, 
 * languages, and benefits. 
 */
function ChipSelect({ options, selected, onToggle }) {
  return (
    <div className={styles.chipOptions}>
      {(options || []).map((opt) => {
        const active = (selected || []).includes(opt);
        return (
          <button
            key={opt}
            type="button"
            onClick={() => onToggle(opt)}
            className={`${styles.chipOption} ${active ? styles.chipOptionActive : ""}`}
          >
            {active && (
              <span className={styles.chipCheck}>
                <svg viewBox="0 0 12 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M1 5L4.3 8.3L11 1.5"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </span>
            )}
            {opt}
          </button>
        );
      })}
    </div>
  );
}

/** 
 * Same idea as Key Skills: pick from suggested chips, or type your own and 
 * press Enter / click Add. Typing never submits on its own — if what you 
 * typed already matches an existing chip (suggested or previously added), 
 * that chip is simply selected instead of creating a near-duplicate. Only 
 * genuinely new text becomes a new chip. 
 */
function ChipSelectWithAdd({ options, selected, onToggle, placeholder }) {
  const [inputValue, setInputValue] = useState("");

  // Suggested options plus any already-selected custom entries that aren't 
  // part of the fixed list, so manually-added chips show up (and can be 
  // removed the same way as any other chip). 
  const allChips = [...(options || [])];
  (selected || []).forEach((s) => {
    if (!allChips.some((o) => o.toLowerCase() === s.toLowerCase())) {
      allChips.push(s);
    }
  });

  const commitInput = () => {
    const value = inputValue.trim();
    if (!value) return;

    const existing = allChips.find(
      (o) => o.toLowerCase() === value.toLowerCase()
    );
    const target = existing || value;
    const alreadySelected = (selected || []).some(
      (s) => s.toLowerCase() === target.toLowerCase()
    );

    // Only adds a brand-new chip when nothing below already matches it; 
    // otherwise it just selects the existing one. 
    if (!alreadySelected) onToggle(target);
    setInputValue("");
  };

  return (
    <div>
      <div className={styles.chipInputRow}>
        <input
          className={styles.chipInput}
          placeholder={placeholder || "Type and press Enter…"}
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              commitInput();
            }
          }}
        />
        <button
          type="button"
          className={styles.chipAddBtn}
          onClick={commitInput}
        >
          + Add
        </button>
      </div>

      <ChipSelect options={allChips} selected={selected} onToggle={onToggle} />
    </div>
  );
}

/* ─── Top progress bar ────────────────────────────────────────────────────── */
function StepProgressBar({ activeStep, onStepClick, lastCompletedStep = 0 }) {
  return (
    <div className={styles.progressContainer}>
      <div className={styles.stepWrapper}>
        {JOB_STEPS.map((s, i) => {
          const n = i + 1;
          const active = n === activeStep;
          // A checkmark only appears once that step's data has actually been 
          // saved (Save & Continue) — simply navigating past it doesn't count. 
          const done = n <= lastCompletedStep && !active;
          const handleClick = () => onStepClick?.(n);
          return (
            <React.Fragment key={s.id}>
              <div
                className={styles.stepItem}
                onClick={handleClick}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") onStepClick?.(n);
                }}
                title={`Go to ${s.title}`}
                style={{ cursor: "pointer" }}
              >
                <div
                  className={[
                    styles.stepCircle,
                    done ? styles.stepCompleted : "",
                    active ? styles.stepActive : "",
                  ].join(" ")}
                >
                  {done ? "✓" : s.step}
                </div>
                <span
                  className={[
                    styles.stepLabel,
                    active ? styles.stepLabelActive : "",
                  ].join(" ")}
                >
                  {s.title}
                </span>
              </div>
              {i < JOB_STEPS.length - 1 && (
                <div
                  className={[
                    styles.stepLine,
                    done ? styles.stepLineActive : "",
                  ].join(" ")}
                />
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
}

/* ─── Step card wrapper ───────────────────────────────────────────────────── */
function StepCard({ stepNum, title, subtitle, children, onBack, onContinue, isLast }) {
  return (
    <div className={styles.sectionCard}>
      <div className={styles.sectionBody}>
        <div className={styles.sectionHeading}>
          <span className={styles.sectionStep}>
            {String(stepNum).padStart(2, "0")}
          </span>
          <div>
            <h5 className={styles.sectionTitle}>{title}</h5>
            {subtitle && <p className={styles.sectionSub}>{subtitle}</p>}
          </div>
        </div>

        <div style={{ marginTop: 24 }}>{children}</div>

        <div className={styles.stepActions}>
          {stepNum > 1 && (
            <button
              type="button"
              className={`btn btn-border ${styles.backBtn}`}
              onClick={onBack}
            >
              Back
            </button>
          )}
          <button
            type="button"
            className={`btn btn-default ${styles.continueBtn}`}
            onClick={onContinue}
          >
            {isLast ? "Save & Publish" : "Save & Continue"}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ─── STEP 1 – Job Details ────────────────────────────────────────────────── */
function Step1({
  go,
  jobForm,
  setJobForm,
  onSubmit,
  selectedSubTradeId,
  onSubTradeChange,
  roleCategoriesList = roleCategories,
  departmentOptionsList = departmentOptions,
  handleDepartmentChange,
  industryOptionsList = [],
  tradeOptionsList = [],
  subTradeOptionsList = [],

  selectedIndustryId,
  selectedTradeCategoryId,
  customIndustry,
  customTrade,
  customSubTrade,

  industryIsCustom,
  tradeIsCustom,

  hasIndustry,
  hasTrade,

  industryLoading,
  tradeLoading,
  subTradeLoading,

  onIndustryChange,
  onTradeChange,

  onAddIndustry,
  onAddTrade,
  onAddSubTrade,
}) {
  // Single source of truth for "is this dropdown's value the 'Other' sentinel?"

  const isDeptOther = isOtherValue(jobForm.Department);


  // Contract duration UI state
  const [contractYears, setContractYears] = useState("");
  const [contractMonths, setContractMonths] = useState("");
  const [contractDays, setContractDays] = useState("");


  // Load existing ContractPeriod string into the 3 UI fields
  useEffect(() => {
    const value = jobForm.ContractPeriod || "";

    if (!value) {
      setContractYears("");
      setContractMonths("");
      setContractDays("");
      return;
    }

    const yearsMatch = value.match(/(\d+)\s*Years?/i);
    const monthsMatch = value.match(/(\d+)\s*Months?/i);
    const daysMatch = value.match(/(\d+)\s*Days?/i);

    setContractYears(yearsMatch ? yearsMatch[1] : "");
    setContractMonths(monthsMatch ? monthsMatch[1] : "");
    setContractDays(daysMatch ? daysMatch[1] : "");
  }, [jobForm.ContractPeriod]);

  // Convert Years / Months / Days into the single ContractPeriod string
  const updateContractPeriod = (years, months, days) => {
    const parts = [];

    if (years) {
      parts.push(
        `${Number(years)} ${Number(years) === 1 ? "Year" : "Years"}`
      );
    }


    if (months) {
      parts.push(
        `${Number(months)} ${Number(months) === 1 ? "Month" : "Months"}`
      );
    }


    if (days) {
      parts.push(
        `${Number(days)} ${Number(days) === 1 ? "Day" : "Days"}`
      );
    }

    const contractPeriod = parts.join(" ");

    setJobForm((p) => ({
      ...p,
      ContractPeriod: contractPeriod,
    }));
  };

  return (
    <StepCard
      stepNum={1}
      title="Job Details"
      subtitle="Core role information"
      onContinue={onSubmit}
      isFirst
    >
      {/* Job Title */}
      <Field label="Job Title" required>
        <input
          className={styles.control}
          value={jobForm.JobTitle}
          onChange={(e) => setJobForm((p) => ({ ...p, JobTitle: e.target.value }))}
          placeholder="e.g. Senior Welder"
        />
      </Field>

      {/* Industry Type */}
      <Field
        label="Industry Type"
        required
        hint="Select an industry or add a new one"
      >
        <MasterHierarchyCombobox
          value={selectedIndustryId}
          onChange={onIndustryChange}
          options={industryOptionsList}
          loading={industryLoading}
          placeholder={customIndustry || "Select Industry Type"}
          addLabel="Add New Industry Type"
          onAddNew={onAddIndustry}
        />
      </Field>

      <div className={styles.grid2}>
        {/* Trade / Role Category */}
        <Field
          label="Trade / Role Category"
          required
          hint={
            selectedIndustryId
              ? "Select a trade category or add a new one"
              : "Select Industry Type first"
          }
        >
          <MasterHierarchyCombobox
            value={selectedTradeCategoryId}
            onChange={onTradeChange}
            options={industryIsCustom ? [] : tradeOptionsList}
            disabled={!hasIndustry}
            loading={industryIsCustom ? false : tradeLoading}
            placeholder={
              !hasIndustry
                ? "Select Industry Type first"
                : customTrade
                  ? customTrade
                  : "Select Trade / Role Category"
            }
            addLabel="Add New Trade"
            onAddNew={onAddTrade}
          />
        </Field>



        {/* SubTrade / Category */}
        <Field
          label="SubTrade / Category"
          hint={
            selectedTradeCategoryId
              ? "Select a category or add a new one"
              : "Select Trade / Role Category first"
          }
        >
          <MasterHierarchyCombobox
            value={selectedSubTradeId}
            onChange={onSubTradeChange}
            options={tradeIsCustom ? [] : subTradeOptionsList}
            disabled={!hasTrade}
            loading={tradeIsCustom ? false : subTradeLoading}
           placeholder={
  !hasTrade
    ? "Select Trade / Role Category first"
    : customSubTrade
      ? customSubTrade
      : "Select SubTrade / Category"
}
            addLabel="Add New SubTrade"
            onAddNew={onAddSubTrade}
          />
        </Field>



        {/* Role (optional free-text specialisation) */}
        <Field label="Role / Specialisation">
          <input
            value={jobForm.Role}
            onChange={(e) => setJobForm((p) => ({ ...p, Role: e.target.value }))}
            className={styles.control}
            placeholder="e.g. Pipe Welder"
          />
        </Field>


        <Field label="Hiring for Client">
          <label
            style={{
              display: "flex",
              alignItems: "center",
              gap: "10px",
              marginTop: "12px",
            }}
          >
            <input
              type="checkbox"
              checked={jobForm.IsClientHiring}
              onChange={(e) =>
                setJobForm((p) => ({
                  ...p,
                  IsClientHiring: e.target.checked,
                  ClientName: e.target.checked ? p.ClientName : "",
                  ShowClientName: e.target.checked
                    ? p.ShowClientName
                    : false,
                }))
              }
            />

            This job is posted for another client
          </label>
        </Field>


        {jobForm.IsClientHiring && (
          <Field label="Client Name" required>
            <input
              className={styles.control}
              value={jobForm.ClientName}
              onChange={(e) =>
                setJobForm((p) => ({
                  ...p,
                  ClientName: e.target.value,
                }))
              }
              placeholder="ABC Shipping Pvt Ltd"
            />
          </Field>
        )}

        {jobForm.IsClientHiring && (
          <Field label="Show Client Name to Candidate">
            <label
              style={{
                display: "flex",
                alignItems: "center",
                gap: "10px",
                marginTop: "12px",
              }}
            >
              <input
                type="checkbox"
                checked={jobForm.ShowClientName}
                onChange={(e) =>
                  setJobForm((p) => ({
                    ...p,
                    ShowClientName: e.target.checked,
                  }))
                }
              />

              Show Client Name
            </label>
          </Field>
        )}
        {/* Experience Min */}
        <Field label="Experience Min (yrs)">
          <input
            type="number"
            min={0}
            max={50}
            className={styles.control}
            value={jobForm.ExperienceMinYears}
            onChange={(e) =>
              setJobForm((p) => ({ ...p, ExperienceMinYears: e.target.value }))
            }
            onBlur={(e) => {
              const raw = e.target.value;
              if (raw === "") return;
              const clamped = Math.min(50, Math.max(0, Math.trunc(Number(raw) || 0)));
              if (String(clamped) !== raw) {
                setJobForm((p) => ({ ...p, ExperienceMinYears: String(clamped) }));
              }
            }}
          />
        </Field>

        {/* Experience Max */}
        <Field label="Experience Max (yrs)">
          <input
            type="number"
            min={0}
            max={50}
            className={styles.control}
            value={jobForm.ExperienceMaxYears}
            onChange={(e) =>
              setJobForm((p) => ({ ...p, ExperienceMaxYears: e.target.value }))
            }
            onBlur={(e) => {
              const raw = e.target.value;
              if (raw === "") return;
              const clamped = Math.min(50, Math.max(0, Math.trunc(Number(raw) || 0)));
              if (String(clamped) !== raw) {
                setJobForm((p) => ({ ...p, ExperienceMaxYears: String(clamped) }));
              }
            }}
          />
        </Field>

        {jobForm.ExperienceMinYears !== "" &&
          jobForm.ExperienceMaxYears !== "" &&
          Number(jobForm.ExperienceMinYears) > Number(jobForm.ExperienceMaxYears) && (
            <p
              style={{
                gridColumn: "1 / -1",
                marginTop: -12,
                marginBottom: 4,
                fontSize: 13,
                color: "#dc2626",
                fontWeight: 600,
                display: "flex",
                alignItems: "center",
                gap: 6,
              }}
            >
              ⚠ Experience Min cannot be greater than Experience Max
            </p>
          )}


        {/* Job Type */}
        <Field label="Job Type" required>
          <Combobox
            value={jobForm.JobType}
            onChange={(v) => setJobForm((p) => ({ ...p, JobType: v }))}
            options={jobPostTypes}
            placeholder="e.g. Regular Hiring"
          />
        </Field>

        {/* Employment Type */}
        <Field label="Employment Type" required>
          <Combobox
            value={jobForm.EmploymentType}
            onChange={(v) =>
              setJobForm((p) => ({
                ...p,
                EmploymentType: v,
                // clear any stale period if they switch away from Contract
                ContractPeriod: v === "Contract" ? p.ContractPeriod : "",
              }))
            }
            options={employmentTypeOptions}
            placeholder="e.g. Full Time"
          />
        </Field>

        {/* Contract Period — only when Employment Type is Contract */}
        {jobForm.EmploymentType === "Contract" && (
          <Field
            label="Contract Period"
            required
          >
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(3, 1fr)",
                gap: "12px",
                width: "100%",
              }}
            >
              {/* Years */}
              <div>
                <input
                  type="number"
                  min="0"
                  className={styles.control}
                  value={contractYears}
                  onChange={(e) => {
                    const value = e.target.value;

                    setContractYears(value);
                    updateContractPeriod(
                      value,
                      contractMonths,
                      contractDays
                    );
                  }}
                  placeholder="0"
                />

                <div
                  style={{
                    marginTop: "6px",
                    fontSize: "12px",
                    color: "#66789c",
                    fontWeight: 500,
                  }}
                >
                  Years
                </div>
              </div>

              {/* Months */}
              <div>
                <input
                  type="number"
                  min="0"
                  max="11"
                  className={styles.control}
                  value={contractMonths}
                  onChange={(e) => {
                    const value = e.target.value;

                    setContractMonths(value);
                    updateContractPeriod(
                      contractYears,
                      value,
                      contractDays
                    );
                  }}
                  placeholder="0"
                />

                <div
                  style={{
                    marginTop: "6px",
                    fontSize: "12px",
                    color: "#66789c",
                    fontWeight: 500,
                  }}
                >
                  Months
                </div>
              </div>

              {/* Days */}
              <div>
                <input
                  type="number"
                  min="0"
                  max="30"
                  className={styles.control}
                  value={contractDays}
                  onChange={(e) => {
                    const value = e.target.value;

                    setContractDays(value);
                    updateContractPeriod(
                      contractYears,
                      contractMonths,
                      value
                    );
                  }}
                  placeholder="0"
                />

                <div
                  style={{
                    marginTop: "6px",
                    fontSize: "12px",
                    color: "#66789c",
                    fontWeight: 500,
                  }}
                >
                  Days
                </div>
              </div>
            </div>
          </Field>
        )}

        {/* Employment Mode */}
        <Field label="Employment Mode" required>
          <Combobox
            value={jobForm.EmploymentMode}
            onChange={(v) => setJobForm((p) => ({ ...p, EmploymentMode: v }))}
            options={employmentModeOptions}
            placeholder="e.g. Onsite"
          />
        </Field>

        {/* Department */}
        <Field label="Department">
          <Combobox
            value={jobForm.Department}
            onChange={handleDepartmentChange}
            options={departmentOptionsList}
            placeholder="Select Department"
          />
        </Field>

        {/* Duty Hours Per Day */}
        <div
          style={{
            gridColumn: "1 / -1", // take full width of the parent grid 
            display: "flex",
            gap: "24px",
            alignItems: "flex-start",
            width: "100%",
          }}
        >
          <div style={{ flex: 2 }}>
            <Field label="Duty Hours Per Day" hint="1–24 hours">
              <input
                type="number"
                min={1}
                max={24}
                className={styles.control}
                value={jobForm.DutyHoursPerDay}
                onChange={(e) =>
                  setJobForm((p) => ({
                    ...p,
                    DutyHoursPerDay: e.target.value,
                  }))
                }
                onBlur={(e) => {
                  const raw = e.target.value;
                  if (raw === "") return;
                  const clamped = Math.min(24, Math.max(1, Number(raw) || 1));
                  if (String(clamped) !== raw) {
                    setJobForm((p) => ({ ...p, DutyHoursPerDay: String(clamped) }));
                  }
                }}
              />
            </Field>
          </div>

          <div style={{ flex: 1 }}>
            <Field label="Paid Overtime">
              <label
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "8px",
                  marginTop: "12px",
                }}
              >
                <input
                  type="checkbox"
                  checked={jobForm.PaidOvertime}
                  onChange={(e) =>
                    setJobForm((p) => ({
                      ...p,
                      PaidOvertime: e.target.checked,
                    }))
                  }
                />
                Overtime will be paid
              </label>
            </Field>
          </div>

          <div style={{ flex: 1 }}>
            {/* <Field label="Oil Field"> 
              <label 
                style={{ 
                  display: "flex", 
                  alignItems: "center", 
                  gap: "8px", 
                  marginTop: "12px", 
                }} 
              > 
                <input 
                  type="checkbox" 
                  checked={jobForm.IsOilField} 
                  onChange={(e) => 
                    setJobForm((p) => ({ 
                      ...p, 
                      IsOilField: e.target.checked, 
                    })) 
                  } 
                /> 
                Oil field job 
              </label> 
            </Field> */}
          </div>
        </div>
      </div>

    </StepCard>
  );
}

/* ─── STEP 2 – Compensation ───────────────────────────────────────────────── */
function Step2({ go, jobForm, setJobForm, onSubmit }) {
  const salaryMinNegative = jobForm.SalaryMin !== "" && Number(jobForm.SalaryMin) < 0;
  const salaryMaxNegative = jobForm.SalaryMax !== "" && Number(jobForm.SalaryMax) < 0;
  const salaryInvalid =
    jobForm.SalaryMin !== "" &&
    jobForm.SalaryMax !== "" &&
    Number(jobForm.SalaryMin) > Number(jobForm.SalaryMax);

  return (
    <StepCard
      stepNum={2}
      title="Compensation"
      subtitle="Salary information"
      onBack={() => go(1)}
      onContinue={onSubmit}
    >
      <div className={styles.grid2}>

        <Field label="Salary Period" required>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "24px",
              flexWrap: "wrap",
            }}
          >
            {salaryPeriodOptions.map((option) => (
              <label
                key={option.value}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "8px",
                  cursor: "pointer",
                  fontSize: "15px",
                  color: "#122359",
                }}
              >
                <input
                  type="radio"
                  name="salaryPeriod"
                  value={option.value}
                  checked={jobForm.SalaryPeriod === option.value}
                  onChange={(e) =>
                    setJobForm((p) => ({
                      ...p,
                      SalaryPeriod: e.target.value,
                    }))
                  }
                />

                {option.label}
              </label>
            ))}
          </div>
        </Field>

        {/* Currency First */}
        <Field label="Currency" required>
          <Combobox
            value={jobForm.SalaryCurrency}
            onChange={(v) => setJobForm((p) => ({ ...p, SalaryCurrency: v }))}
            options={currencies}
            placeholder="e.g. INR"
          />
        </Field>

        {/* Display Option Second */}
        <Field label="Salary Display Option" required>
          <Combobox
            value={jobForm.SalaryDisplayOption}
            onChange={(v) => setJobForm((p) => ({ ...p, SalaryDisplayOption: v }))}
            options={salaryDisplayOptions}
            placeholder="e.g. Show Range"
          />
        </Field>

        {/* Min Salary */}
        <Field label="Min Salary" required>
          <input
            type="number"
            min={0}
            className={styles.control}
            value={jobForm.SalaryMin}
            onChange={(e) =>
              setJobForm((p) => ({
                ...p,
                SalaryMin: e.target.value,
              }))
            }
            onBlur={(e) => {
              const raw = e.target.value;
              if (raw === "") return;
              if (Number(raw) < 0) {
                setJobForm((p) => ({ ...p, SalaryMin: "0" }));
              }
            }}
          />
        </Field>

        {/* Max Salary */}
        <Field label="Max Salary" required>
          <input
            type="number"
            min={0}
            className={styles.control}
            value={jobForm.SalaryMax}
            onChange={(e) =>
              setJobForm((p) => ({
                ...p,
                SalaryMax: e.target.value,
              }))
            }
            onBlur={(e) => {
              const raw = e.target.value;
              if (raw === "") return;
              if (Number(raw) < 0) {
                setJobForm((p) => ({ ...p, SalaryMax: "0" }));
              }
            }}
          />
        </Field>

      </div>

      {(salaryMinNegative || salaryMaxNegative) && (
        <p
          style={{
            marginTop: -12,
            marginBottom: 16,
            fontSize: 13,
            color: "#dc2626",
            fontWeight: 600,
            display: "flex",
            alignItems: "center",
            gap: 6,
          }}
        >
          ⚠ Salary amounts cannot be negative
        </p>
      )}

      {salaryInvalid && (
        <p
          style={{
            marginTop: -12,
            marginBottom: 16,
            fontSize: 13,
            color: "#dc2626",
            fontWeight: 600,
            display: "flex",
            alignItems: "center",
            gap: 6,
          }}
        >
          ⚠ Minimum Salary cannot be greater than Maximum Salary
        </p>
      )}
    </StepCard>
  );
}

/* ─── STEP 3 – Skills & JD ────────────────────────────────────────────────── */
function Step3({ go, jobForm, setJobForm, onSubmit, additionalJdSuggestions, handleGenerateAdditionalJD, loadingAI, handleSuggestSkills, skillsLoading, handleGenerateJD, jdSuggestions, ghostSuggestion, handleJDTab }) {
  const [newSkillInput, setNewSkillInput] = useState("");

  const addManualSkill = () => {
    const value = newSkillInput.trim();
    if (!value) return;

    const alreadyExists = jobForm.KeySkills.some(
      (s) => s.toLowerCase() === value.toLowerCase(),
    );
    if (alreadyExists) {
      setNewSkillInput("");
      return;
    }

    setJobForm((p) => ({ ...p, KeySkills: [...p.KeySkills, value] }));
    setNewSkillInput("");
  };

  return (
    <StepCard
      stepNum={3}
      title="Skills & JD"
      subtitle="Skills, benefits and extended description"
      onBack={() => go(2)}
      onContinue={onSubmit}
    >
      {/* Job Description */}
      <Field label="Job Description" required>
        <button
          type="button"
          className={styles.aiGenerateBtn}
          style={{ marginBottom: 10 }}
          onClick={handleGenerateJD}
        >
          {loadingAI ? "Generating…" : "✨ Generate with AI"}
        </button>

        <textarea
          className={styles.textarea}
          rows={6}
          value={jobForm.JobDescription}
          onChange={(e) =>
            setJobForm((p) => ({ ...p, JobDescription: e.target.value }))
          }
          onKeyDown={handleJDTab}
        />

        {ghostSuggestion && (
          <div className={styles.inlineSuggestion}>
            <span className={styles.tabHint}>Press TAB ↹</span>
            <span className={styles.suggestionText}>{ghostSuggestion}</span>
          </div>
        )}

        {jdSuggestions.length > 0 && (
          <div className={styles.aiSuggestions}>
            {jdSuggestions.map((suggestion, index) => (
              <div
                key={index}
                className={styles.aiSuggestion}
                onClick={() =>
                  setJobForm((p) => ({
                    ...p,
                    JobDescription: p.JobDescription + " " + suggestion,
                  }))
                }
              >
                {suggestion}
              </div>
            ))}
          </div>
        )}
      </Field>

      {/* Key Skills — AI-generated, plus manual add */}
      <Field
        label="Key Skills"
        required
        hint="Generate with AI, or type your own and press Enter / click Add. Remove any that don't fit."
      >
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 12 }}>
          <button
            type="button"
            className={styles.aiGenerateBtn}
            onClick={handleSuggestSkills}
            disabled={skillsLoading}
          >
            {skillsLoading
              ? "Generating…"
              : jobForm.KeySkills.length > 0
                ? "✨ Regenerate with AI"
                : "✨ Generate Skills with AI"}
          </button>
        </div>

        <div className={styles.chipInputRow}>
          <input
            className={styles.chipInput}
            placeholder="Type a skill and press Enter…"
            value={newSkillInput}
            onChange={(e) => setNewSkillInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                addManualSkill();
              }
            }}
          />
          <button
            type="button"
            className={styles.chipAddBtn}
            onClick={addManualSkill}
          >
            + Add
          </button>
        </div>

        {jobForm.KeySkills.length === 0 && !skillsLoading && (
          <p className={styles.emptyStateHint}>
            No skills yet — generate with AI above, or type your own and hit
            Enter.
          </p>
        )}

        {jobForm.KeySkills.length > 0 && (
          <div className={styles.chipOptions}>
            {jobForm.KeySkills.map((s) => (
              <span key={s} className={styles.selectedChip}>
                {s}
                <button
                  type="button"
                  aria-label={`Remove ${s}`}
                  className={styles.selectedChipRemove}
                  onClick={() =>
                    setJobForm((p) => ({
                      ...p,
                      KeySkills: p.KeySkills.filter((k) => k !== s),
                    }))
                  }
                >
                  ×
                </button>
              </span>
            ))}
          </div>
        )}
      </Field>

      {/* Language Required — select from suggestions, or type your own */}
      <Field label="Language Required" hint="Select all that apply, or type your own and press Enter / click Add">
        <ChipSelectWithAdd
          options={suggestedLanguages}
          selected={splitComma(jobForm.LanguageRequired || "")}
          placeholder="e.g. English, Hindi"
          onToggle={(item) =>
            setJobForm((p) => ({
              ...p,
              LanguageRequired: toggleCommaValue(p.LanguageRequired, item),
            }))
          }
        />
      </Field>

      {/* Benefits — select from suggestions, or type your own */}
      <Field label="Benefits" hint="Select all that apply, or type your own and press Enter / click Add">
        <ChipSelectWithAdd
          options={suggestedBenefits}
          selected={jobForm.Benefits}
          placeholder="e.g. Health Insurance, Provident Fund"
          onToggle={(b) =>
            setJobForm((p) => {
              const benefits = p.Benefits.includes(b)
                ? p.Benefits.filter((x) => x !== b)
                : [...p.Benefits, b];

              return {
                ...p,
                Benefits: benefits,
                BenefitsText: benefits.join(", "),
              };
            })
          }
        />
      </Field>
    </StepCard>
  );
}

/* ─── STEP 4 – Eligibility ────────────────────────────────────────────────── */
function Step4({ go, jobForm, setJobForm, onSubmit }) {
  const ageMinOutOfRange = jobForm.AgeMin !== "" && (Number(jobForm.AgeMin) < 18 || Number(jobForm.AgeMin) > 99);
  const ageMaxOutOfRange = jobForm.AgeMax !== "" && (Number(jobForm.AgeMax) < 18 || Number(jobForm.AgeMax) > 99);
  const ageRangeInvalid =
    jobForm.AgeMin !== "" &&
    jobForm.AgeMax !== "" &&
    Number(jobForm.AgeMin) > Number(jobForm.AgeMax);

  return (
    <StepCard
      stepNum={4}
      title="Eligibility"
      subtitle="Candidate eligibility criteria"
      onBack={() => go(3)}
      onContinue={onSubmit}
    >
      <div className={styles.grid2}>
        <Field label="Number of Vacancies" required>
          <input
            type="number"
            min={1}
            className={styles.control}
            value={jobForm.Vacancies}
            onChange={(e) =>
              setJobForm((p) => ({ ...p, Vacancies: e.target.value }))
            }
          />
        </Field>

        <Field label="Education Required" required>
          <Combobox
            value={jobForm.EducationRequired}
            onChange={(v) => setJobForm((p) => ({ ...p, EducationRequired: v }))}
            options={educationOptions}
            placeholder="e.g. Graduate"
          />
        </Field>

        <Field label="Minimum Age">
          <input
            type="number"
            min={18}
            max={99}
            className={styles.control}
            value={jobForm.AgeMin}
            onChange={(e) =>
              setJobForm((p) => ({ ...p, AgeMin: e.target.value }))
            }
            onBlur={(e) => {
              const raw = e.target.value;
              if (raw === "") return;
              const clamped = Math.min(99, Math.max(18, Math.trunc(Number(raw) || 18)));
              if (String(clamped) !== raw) {
                setJobForm((p) => ({ ...p, AgeMin: String(clamped) }));
              }
            }}
          />
        </Field>

        <Field label="Maximum Age">
          <input
            type="number"
            min={18}
            max={99}
            className={styles.control}
            value={jobForm.AgeMax}
            onChange={(e) =>
              setJobForm((p) => ({ ...p, AgeMax: e.target.value }))
            }
            onBlur={(e) => {
              const raw = e.target.value;
              if (raw === "") return;
              const clamped = Math.min(99, Math.max(18, Math.trunc(Number(raw) || 18)));
              if (String(clamped) !== raw) {
                setJobForm((p) => ({ ...p, AgeMax: String(clamped) }));
              }
            }}
          />
        </Field>

        {(ageMinOutOfRange || ageMaxOutOfRange) && (
          <p
            style={{
              gridColumn: "1 / -1",
              marginTop: -4,
              marginBottom: 4,
              fontSize: 13,
              color: "#dc2626",
              fontWeight: 600,
              display: "flex",
              alignItems: "center",
              gap: 6,
            }}
          >
            ⚠ Age must be between 18 and 99 years
          </p>
        )}

        {!ageMinOutOfRange && !ageMaxOutOfRange && ageRangeInvalid && (
          <p
            style={{
              gridColumn: "1 / -1",
              marginTop: -4,
              marginBottom: 4,
              fontSize: 13,
              color: "#dc2626",
              fontWeight: 600,
              display: "flex",
              alignItems: "center",
              gap: 6,
            }}
          >
            ⚠ Minimum Age cannot be greater than Maximum Age
          </p>
        )}

        <Field label="Gender Preferred">
          <Combobox
            value={jobForm.GenderPreferred}
            onChange={(v) => setJobForm((p) => ({ ...p, GenderPreferred: v }))}
            options={genderOptions}
            placeholder="e.g. Not Specified"
          />
        </Field>

        <Field label="Disability Eligible">
          <div style={{ paddingTop: 12 }}>
            <label style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <input
                type="checkbox"
                checked={jobForm.DisabilityEligible}
                onChange={(e) =>
                  setJobForm((p) => ({
                    ...p,
                    DisabilityEligible: e.target.checked,
                  }))
                }
              />
              Open to persons with disabilities
            </label>
          </div>
        </Field>

        <Field label="Passport Required">
          <div style={{ paddingTop: 12 }}>
            <label style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <input
                type="checkbox"
                checked={jobForm.PassportRequired}
                onChange={(e) =>
                  setJobForm((p) => ({
                    ...p,
                    PassportRequired: e.target.checked,
                    PassportValidityMonths: e.target.checked
                      ? p.PassportValidityMonths
                      : "",
                  }))
                }
              />
              Passport is required
            </label>
          </div>
        </Field>

        {jobForm.PassportRequired && (
          <Field
            label="Passport Validity Required (Months)"
            hint="Minimum remaining validity"
          >
            <input
              type="number"
              min={1}
              max={120}
              className={styles.control}
              value={jobForm.PassportValidityMonths}
              onChange={(e) =>
                setJobForm((p) => ({
                  ...p,
                  PassportValidityMonths: e.target.value,
                }))
              }
            />
          </Field>
        )}
      </div>

      {/* Licence / Documents Required — split into Personal vs Working docs */}
      <Field
        label="Personal Documents Required"
        hint="Identity proof documents — select all that apply, or type your own and press Enter / click Add"
      >
        <ChipSelectWithAdd
          options={suggestedPersonalDocs}
          selected={splitComma(jobForm.LicenceDocsRequired || "")}
          placeholder="e.g. Aadhaar Card / Identity Proof"
          onToggle={(item) =>
            setJobForm((p) => ({
              ...p,
              LicenceDocsRequired: toggleCommaValue(p.LicenceDocsRequired, item),
            }))
          }
        />
      </Field>

      <Field
        label="Working Documents Required"
        hint="Trade / professional certificates — select all that apply, or type your own and press Enter / click Add"
      >
        <ChipSelectWithAdd
          options={suggestedWorkingDocs}
          selected={splitComma(jobForm.WorkingDocsRequired || "")}
          placeholder="e.g. Welding Certification (CSWIP / AWS)"
          onToggle={(item) =>
            setJobForm((p) => ({
              ...p,
              WorkingDocsRequired: toggleCommaValue(
                p.WorkingDocsRequired,
                item
              ),
            }))
          }
        />
      </Field>
    </StepCard>
  );
}

/* ─── STEP 5 – Location ───────────────────────────────────────────────────── */
function Step5({ go, jobForm, setJobForm, onSubmit, errors, }) {
  const isOnshore = jobForm.LocationType === "Onshore";
  const isOffshore = jobForm.LocationType === "Offshore";

  const activeCountry = jobForm.OnshoreCountry || "India";

  const stateOptions = useMemo(() => {
    const states = getStatesForCountry(activeCountry);
    return states.length > 0 ? states : indianStates;
  }, [activeCountry]);

  // A job is International when its country is set and is not India. Same
  // rule the backend uses to set IsInternational (shown on the JD).
  const isOutsideIndia = (c) =>
    !!c && c.trim() !== "" && c.trim().toLowerCase() !== "india";
  const isInternationalJob =
    isOutsideIndia(jobForm.Country) ||
    (isOnshore && isOutsideIndia(jobForm.OnshoreCountry)) ||
    (isOffshore && isOutsideIndia(jobForm.OffshoreCountry));

  const handleCountryChange = (countryVal) => {
    setJobForm((p) => {
      const next = { ...p, Country: countryVal };

      // Keep the Onshore/Offshore country in step with the general Country
      // unless the recruiter deliberately set it to something else, so the
      // two can't silently disagree (which made international jobs show up
      // as "International Job: No" on the JD).
      if (!p.OnshoreCountry || p.OnshoreCountry === p.Country) {
        const validStates = getStatesForCountry(countryVal);
        next.OnshoreCountry = countryVal;
        if (
          !(validStates.length === 0 || validStates.includes(p.OnshoreState))
        ) {
          next.OnshoreState = "";
        }
      }
      if (!p.OffshoreCountry || p.OffshoreCountry === p.Country) {
        next.OffshoreCountry = countryVal;
      }
      return next;
    });
  };

  const handleOnshoreCountryChange = (countryVal) => {
    setJobForm((p) => {
      const validStates = getStatesForCountry(countryVal);

      const isCurrentStateValid =
        validStates.length === 0 ||
        validStates.includes(p.OnshoreState);

      return {
        ...p,
        OnshoreCountry: countryVal,
        OnshoreState: isCurrentStateValid
          ? p.OnshoreState
          : "",
      };
    });
  };

  return (
    <StepCard
      stepNum={5}
      title="Location"
      subtitle="Job location details"
      onBack={() => go(4)}
      onContinue={onSubmit}
    >
      <div className={styles.grid2}>
        {/* Location Type */}
        <Field label="Location Type" required>
          <Combobox
            value={jobForm.LocationType}
            onChange={(v) => setJobForm((p) => ({ ...p, LocationType: v }))}
            options={locationTypeOptions}
            placeholder="e.g. Onshore"
          />
        </Field>

        {/* General Country */}
        <Field label="Country" required>
          <Combobox
            value={jobForm.Country}
            onChange={handleCountryChange}
            options={countryOptions}
            placeholder="e.g. India"
          />
        </Field>

        {/* International Job — set automatically from the country */}
        <Field
          label="International Job"
          hint="Set automatically: any country other than India makes this an International job."
        >
          <div
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: 8,
              padding: "8px 12px",
              borderRadius: 8,
              fontSize: 13,
              fontWeight: 700,
              border: `1px solid ${isInternationalJob ? "rgba(255,163,0,.4)" : "#e4eaf3"}`,
              background: isInternationalJob ? "#fff7e8" : "#f8faff",
              color: isInternationalJob ? "#8a5a00" : "#66789c",
            }}
          >
            {isInternationalJob ? "Yes — International job" : "No — Domestic job (India)"}
          </div>
        </Field>

        {/* Work Address Line (both types) */}
        <Field label="Work Address / Site" style={{ gridColumn: "1/-1" }}>
          <input
            className={styles.control}
            placeholder="e.g. Plot 12, Industrial Area, Phase 2"
            value={jobForm.WorkAddressLine}
            onChange={(e) =>
              setJobForm((p) => ({ ...p, WorkAddressLine: e.target.value }))
            }
          />
        </Field>

        {/* ── ONSHORE fields ── */}
        {isOnshore && (
          <>
            <Field label="City" required>
              <input
                className={styles.control}
                value={jobForm.OnshoreCity}
                onChange={(e) =>
                  setJobForm((p) => ({ ...p, OnshoreCity: e.target.value }))
                }
              />
            </Field>

            <Field label="State / Province" required>
              <Combobox
                value={jobForm.OnshoreState}
                onChange={(v) => setJobForm((p) => ({ ...p, OnshoreState: v }))}
                options={stateOptions}
                placeholder={
                  activeCountry
                    ? `e.g. Select state in ${activeCountry}`
                    : "Select a state"
                }
              />
            </Field>

            <Field label="Onshore Country">
              <Combobox
                value={jobForm.OnshoreCountry}
                onChange={handleOnshoreCountryChange}
                options={countryOptions}
                placeholder="e.g. India"
              />
            </Field>


            <Field label="Pin / Zip Code">
              <input
                className={styles.control}
                value={jobForm.OnshorePincode}
                onChange={(e) =>
                  setJobForm((p) => ({ ...p, OnshorePincode: e.target.value }))
                }
              />
            </Field>
          </>
        )}

        {/* ── OFFSHORE fields ── */}
        {isOffshore && (
          <>
            <Field label="Vessel / Platform Name" required>
              <input
                className={styles.control}
                value={jobForm.OffshoreVesselName}
                onChange={(e) =>
                  setJobForm((p) => ({
                    ...p,
                    OffshoreVesselName: e.target.value,
                  }))
                }

                required
              />
            </Field>

            <Field label="Offshore Region" required>
              <input
                className={styles.control}
                placeholder="e.g. Arabian Gulf, North Sea, Gulf of Mexico"
                value={jobForm.OffshoreRegion}
                onChange={(e) =>
                  setJobForm((p) => ({
                    ...p,
                    OffshoreRegion: e.target.value,
                  }))
                }
              />
            </Field>

            <Field label="Offshore Country">
              <Combobox
                value={jobForm.OffshoreCountry}
                onChange={(v) => setJobForm((p) => ({ ...p, OffshoreCountry: v }))}
                options={countryOptions}
                placeholder="e.g. UAE"
              />
            </Field>
          </>
        )}
      </div>
    </StepCard>
  );
}

/* ─── STEP 6 – Screening Questions ───────────────────────────────────────── */
function Step6({ go, jobForm, setJobForm, onSubmit }) {
  const addQuestion = () => {
    setJobForm((p) => ({
      ...p,
      questions: [
        ...p.questions,
        {
          questionText: "",
        },
      ],
    }));
  };

  const removeQuestion = (index) => {
    setJobForm((p) => ({
      ...p,
      questions: p.questions.filter((_, i) => i !== index),
    }));
  };

  const updateQuestion = (index, field, value) => {
    setJobForm((p) => ({
      ...p,
      questions: p.questions.map((q, i) =>
        i === index ? { ...q, [field]: value } : q
      ),
    }));
  };

  return (
    <StepCard
      stepNum={6}
      title="Questions"
      subtitle="Screening questions for applicants (optional)"
      onBack={() => go(5)}
      onContinue={onSubmit}
    >
      <p style={{ fontSize: 13, color: "#66789c", marginBottom: 16 }}>
        Screening questions are entirely optional. Add one or more if you&apos;d
        like candidates to answer specific questions when they apply, or skip
        this step and continue.
      </p>

      {jobForm.questions.length === 0 && (
        <div
          style={{
            padding: "20px",
            marginBottom: 16,
            textAlign: "center",
            border: "1px dashed #ddd",
            borderRadius: 8,
            color: "#66789c",
            fontSize: 13,
          }}
        >
          No screening questions added yet. You can skip this step, or add a
          question below.
        </div>
      )}

      {jobForm.questions.map((question, index) => (
        <div
          key={index}
          style={{
            marginBottom: 20,
            padding: 15,
            border: "1px solid #ddd",
            borderRadius: 8,
          }}
        >
          <Field label={`Question ${index + 1}`}>
            <input
              className={styles.control}
              value={question.questionText}
              onChange={(e) =>
                updateQuestion(index, "questionText", e.target.value)
              }
              placeholder="e.g. Do you have a valid CSWIP 3.1 certificate?"
            />
          </Field>
          <button
            type="button"
            className="btn btn-danger btn-sm"
            onClick={() => removeQuestion(index)}
          >
            Remove
          </button>
        </div>
      ))}

      <button type="button" className="btn btn-border" onClick={addQuestion}>
        + Add Question
      </button>
    </StepCard>
  );
}

/* ─── STEP 7 – Publishing ─────────────────────────────────────────────────── */
function Step7({ go, jobForm, setJobForm, onSubmit, preflightIssues = [] }) {
  return (
    <StepCard
      stepNum={7}
      title="Publishing"
      subtitle="Set visibility and publish your job"
      onBack={() => go(6)}
      onContinue={onSubmit}
      isLast
    >
      {/* Pre-publish checklist */}
      <div
        style={{
          marginBottom: 24,
          padding: "16px 18px",
          borderRadius: 12,
          border: `1px solid ${preflightIssues.length ? "#FBD5D5" : "#BBF7D0"}`,
          background: preflightIssues.length ? "#FFF5F5" : "#F0FDF4",
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 8,
            fontWeight: 700,
            fontSize: 14,
            color: preflightIssues.length ? "#B91C1C" : "#166534",
            marginBottom: preflightIssues.length ? 10 : 0,
          }}
        >
          <span>{preflightIssues.length ? "⚠" : "✓"}</span>
          {preflightIssues.length
            ? `${preflightIssues.length} item${preflightIssues.length > 1 ? "s" : ""} need${preflightIssues.length > 1 ? "" : "s"} your attention before publishing`
            : "Everything looks good — Ready to publish"}
        </div>

        {preflightIssues.length > 0 && (
          <ul style={{ margin: 0, paddingLeft: 20 }}>
            {preflightIssues.map((issue, i) => (
              <li
                key={i}
                style={{
                  fontSize: 13,
                  color: "#7f1d1d",
                  marginBottom: 6,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  gap: 10,
                }}
              >
                <span>
                  <strong>{issue.title}:</strong> {issue.message}
                </span>
                <button
                  type="button"
                  onClick={() => go(issue.stepNum)}
                  style={{
                    background: "none",
                    border: "none",
                    color: "#1D4ED8",
                    fontWeight: 700,
                    fontSize: 12,
                    cursor: "pointer",
                    whiteSpace: "nowrap",
                    textDecoration: "underline",
                  }}
                >
                  Fix now
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className={styles.grid2}>
        {/* Application Deadline */}
        <Field label="Application Deadline" required>
          <input
            type="date"
            min={todayDateString()}
            className={styles.control}
            value={jobForm.ApplicationDeadline}
            onChange={(e) =>
              setJobForm((p) => ({
                ...p,
                ApplicationDeadline: e.target.value,
              }))
            }
          />
        </Field>

        {/* Company Visibility */}
        <Field label="Company Visibility">
          <Combobox
            value={jobForm.CompanyVisibility}
            onChange={(v) => setJobForm((p) => ({ ...p, CompanyVisibility: v }))}
            options={companyVisibilityOptions}
            placeholder="e.g. Show Company Name"
          />
        </Field>
      </div>
    </StepCard>
  );
}

const STEP_VIEWS = [Step1, Step2, Step3, Step4, Step5, Step6, Step7];

/* ─── Page ────────────────────────────────────────────────────────────────── */
export default function DashboardPostJobPage() {
  const router = useRouter();
  const showToast = useToast();
  const [editJobId, setEditJobId] = useState(null);

  // These three start out with the static fallback lists (which already
  // include "Other") so the form isn't empty while the homepage API call
  // is in flight; the API load below replaces them with live data + "Other".
  const [roleCategoriesList, setRoleCategoriesList] = useState(roleCategories);
  const [departmentOptionsList, setDepartmentOptionsList] = useState(departmentOptions);
  const [industryOptionsList, setIndustryOptionsList] = useState([]);
  const [tradeOptionsList, setTradeOptionsList] = useState([]);
  const [subTradeOptionsList, setSubTradeOptionsList] = useState([]);

  const [selectedIndustryId, setSelectedIndustryId] = useState("");
  const [selectedTradeCategoryId, setSelectedTradeCategoryId] = useState("");
  const [selectedSubTradeId, setSelectedSubTradeId] = useState("");
  const [industryOptionsReady, setIndustryOptionsReady] = useState(false);
  const [customIndustry, setCustomIndustry] = useState("");
  const [customTrade, setCustomTrade] = useState("");
  const [customSubTrade, setCustomSubTrade] = useState("");
  const [addNewType, setAddNewType] = useState(null);
  // "industry" | "trade" | "subTrade" | null



  const [customHierarchyModal, setCustomHierarchyModal] = useState({
    open: false,
    type: "",
    title: "",
    placeholder: "",
  });

  const [customHierarchyValue, setCustomHierarchyValue] = useState("");

  const [addNewValue, setAddNewValue] = useState("");
  const [addNewLoading, setAddNewLoading] = useState(false);

  const [pendingIndustrySuggestionId, setPendingIndustrySuggestionId] = useState(null);
  const [pendingTradeSuggestionId, setPendingTradeSuggestionId] = useState(null);
  const [industryLoading, setIndustryLoading] = useState(false);
  const [tradeLoading, setTradeLoading] = useState(false);
  const [subTradeLoading, setSubTradeLoading] = useState(false);


  const industryIsCustom = Boolean(customIndustry.trim());
  const tradeIsCustom = Boolean(customTrade.trim());

  const hasIndustry =
    Boolean(selectedIndustryId) || industryIsCustom;

  const hasTrade =
    Boolean(selectedTradeCategoryId) || tradeIsCustom;

  useEffect(() => {
    const fetchDropdownOptions = async () => {
      try {
        const res = await getJobDropdowns();

        if (res?.success) {
          // Trade / Role Category - legacy field
          const apiTrades = (res.tradeRoles || [])
            .map((t) => t.name)
            .filter(Boolean);

          if (apiTrades.length > 0) {
            setRoleCategoriesList(withOtherOption(apiTrades));
          }

          // Department
          const apiDepts = (res.departments || [])
            .map((d) => d.name)
            .filter(Boolean);

          if (apiDepts.length > 0) {
            setDepartmentOptionsList(withOtherOption(apiDepts));
          }
        }
      } catch (err) {
        console.error(
          "Failed to load post-job dropdown options via getJobDropdowns:",
          err
        );
      }
    };

    fetchDropdownOptions();
  }, []);


  useEffect(() => {
    const loadIndustries = async () => {
      try {
        setIndustryLoading(true);

        const res = await getIndustries();

        if (res?.success) {
          const industries = (res.industries || [])
            .map((x) => ({
              value:
                x?.id ??
                x?.Id ??
                x?.registrationIndustryId ??
                x?.RegistrationIndustryId,
              label:
                x?.name ??
                x?.Name ??
                "",
            }))
            .filter((x) => x.value && x.label);

          setIndustryOptionsList(industries);
        } else {
          setIndustryOptionsList([]);
        }
      } catch (error) {
        console.error("Failed to load industries:", error);
        setIndustryOptionsList([]);
      } finally {
        setIndustryLoading(false);
        setIndustryOptionsReady(true);
      }
    };

    loadIndustries();
  }, []);

  useEffect(() => {
    const loadIndustries = async () => {
      try {
        setIndustryLoading(true);

        const res = await getIndustries();

        console.log("INDUSTRIES API RESPONSE:", res);

        if (res?.success) {
          const industries = (res.industries || [])
            .map((x) => ({
              value:
                x?.id ??
                x?.Id ??
                x?.registrationIndustryId ??
                x?.RegistrationIndustryId,
              label:
                x?.name ??
                x?.Name ??
                "",
            }))
            .filter((x) => x.value && x.label);

          setIndustryOptionsList(industries);
        } else {
          setIndustryOptionsList([]);
        }
      } catch (error) {
        console.error("Failed to load industries:", error);
        setIndustryOptionsList([]);
      } finally {
        setIndustryLoading(false);
        setIndustryOptionsReady(true);
      }
    };

    loadIndustries();
  }, []);

  useEffect(() => {
    if (editJobId && industryOptionsReady) {
      loadJobForEdit(editJobId);
    }
  }, [editJobId, industryOptionsReady]);

  const [activeStep, setActiveStep] = useState(1);
  const [jdSuggestions, setJdSuggestions] = useState([]);
  const [additionalJdSuggestions, setAdditionalJdSuggestions] = useState([]);
  const [ghostSuggestion, setGhostSuggestion] = useState("");
  const [loadingAI, setLoadingAI] = useState(false);
  const [skillsLoading, setSkillsLoading] = useState(false);
  const [jobId, setJobId] = useState(null);
  const [lastCompletedStep, setLastCompletedStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [showPreview, setShowPreview] = useState(false);
  /* ── initial state – every API field present ── */
  const [jobForm, setJobForm] = useState({
    // Step 1 
    JobTitle: "",
    TradeCategory: "",
    TradeCategoryOther: "", // free-text value when TradeCategory === "Other"
    SubTrade: "",
    Role: "",
    IndustryType: "",
    IndustryTypeOther: "", // free-text value when IndustryType === "Other"
    ExperienceMinYears: "",
    ExperienceMaxYears: "",
    JobType: "",
    EmploymentType: "",
    ContractPeriod: "",
    EmploymentMode: "",
    Department: "",
    DepartmentOther: "", // free-text value when Department === "Other"
    DutyHoursPerDay: "",
    IsOilField: false,
    PaidOvertime: false,
    KeyResponsibilities: [],   // step-1 copy (also sent in step-1 payload) 
    JobDescription: "",
    IsClientHiring: false,
    ClientName: "",
    ShowClientName: false,
    // Step 2 
    SalaryMin: "",
    SalaryMax: "",
    // SalaryCurrency: "INR", 
    // SalaryDisplayOption: "Show_Range", 

    // Step 3 
    KeySkills: [],
    KeySkillsText: "",

    Benefits: [],
    BenefitsText: "",
    Step3KeyResponsibilities: [],  // step-3 separate field 
    AdditionalJobDescription: "",

    Tags: [],

    // Step 4 
    Vacancies: "",
    EducationRequired: "",
    AgeMin: "",
    AgeMax: "",
    GenderPreferred: "",
    DisabilityEligible: false,
    PassportRequired: false,
    PassportValidityMonths: "",
    LicenceDocsRequired: "",
    WorkingDocsRequired: "",
    // Step 5 
    LocationType: "",
    Country: "",
    WorkAddressLine: "",
    OnshoreCity: "",
    OnshoreState: "",
    OnshoreCountry: "",
    OnshorePincode: "",
    OffshoreVesselName: "",
    OffshoreRegion: "",
    OffshoreCountry: "",

    // Step 6 
    questions: [],

    // Step 7 
    ApplicationDeadline: "",
    CompanyVisibility: "ShowName",
    PublishingTags: [],
    PublishNow: true,
  });


  const handleIndustryChange = async (industryId) => {
    setSelectedIndustryId(industryId);

    setCustomIndustry("");
    setPendingIndustrySuggestionId(null);

    setSelectedTradeCategoryId("");
    setCustomTrade("");
    setPendingTradeSuggestionId(null);

    setSelectedSubTradeId("");
    setCustomSubTrade("");

    setTradeOptionsList([]);
    setSubTradeOptionsList([]);

    const selectedIndustry = industryOptionsList.find(
      (x) => x.value === industryId
    );

    setJobForm((prev) => ({
      ...prev,
      IndustryType: selectedIndustry?.label || "",
      TradeCategory: "",
      SubTrade: "",
    }));

    if (!industryId) return;

    try {
      setTradeLoading(true);

      const res = await getTradeCategoriesByIndustry(industryId);

      console.log("TRADE API RESPONSE:", res);

      if (res?.success) {
        const trades = (res.tradeCategories || [])
          .map((x) => ({
            value:
              x?.id ??
              x?.Id ??
              x?.tradeCategoryId ??
              x?.TradeCategoryId,
            label:
              x?.name ??
              x?.Name ??
              "",
          }))
          .filter((x) => x.value && x.label);

        setTradeOptionsList(trades);
      } else {
        setTradeOptionsList([]);
      }
    } catch (error) {
      console.error("Failed to load trade categories:", error);
      setTradeOptionsList([]);
    } finally {
      setTradeLoading(false);
    }
  };

  const handleTradeChange = async (tradeCategoryId) => {

    setSelectedTradeCategoryId(tradeCategoryId);
    setSelectedSubTradeId("");

    setSubTradeOptionsList([]);

    const selectedTrade = tradeOptionsList.find(
      (x) => x.value === tradeCategoryId
    );

    setJobForm((prev) => ({
      ...prev,
      TradeCategory: selectedTrade?.label || "",
      SubTrade: "",
    }));

    if (!tradeCategoryId) return;

    try {
      setSubTradeLoading(true);

      const res = await getSubTradesByTradeCategory(
        tradeCategoryId
      );

      console.log("SUBTRADE API RESPONSE:", res);

      if (res?.success) {
        const subTrades = (res.subTrades || [])
          .map((x) => ({
            value:
              x?.id ??
              x?.Id ??
              x?.subTradeId ??
              x?.SubTradeId,
            label:
              x?.name ??
              x?.Name ??
              "",
          }))
          .filter((x) => x.value && x.label);

        setSubTradeOptionsList(subTrades);
      } else {
        setSubTradeOptionsList([]);
      }
    } catch (error) {
      console.error("Failed to load sub trades:", error);
      setSubTradeOptionsList([]);
    } finally {
      setSubTradeLoading(false);
    }
  };

  const handleSubTradeChange = (subTradeId) => {
    setSelectedSubTradeId(subTradeId);

    const selectedSubTrade = subTradeOptionsList.find(
      (x) => x.value === subTradeId
    );

    setJobForm((prev) => ({
      ...prev,
      SubTrade: selectedSubTrade?.label || "",
    }));
  };

  const handleDepartmentChange = (value) => {
    if (isOtherValue(value)) {
      setCustomHierarchyValue("");

      setCustomHierarchyModal({
        open: true,
        type: "department",
        title: "Add New Department",
        placeholder: "Enter Department",
      });

      return;
    }

    setJobForm((prev) => ({
      ...prev,
      Department: value,
      DepartmentOther: "",
    }));
  };

  const handleAddIndustry = async () => {
    setCustomHierarchyValue(customIndustry || "");

    setCustomHierarchyModal({
      open: true,
      type: "industry",
      title: "Add New Industry Type",
      placeholder: "Enter Industry Type",
    });
  };


  const handleAddTrade = async () => {
    if (!hasIndustry) {
      showToast(
        "Please select or add an Industry Type first.",
        "warning"
      );
      return;
    }

    setCustomHierarchyValue(customTrade || "");

    setCustomHierarchyModal({
      open: true,
      type: "trade",
      title: "Add New Trade / Role Category",
      placeholder: "Enter Trade / Role Category",
    });
  };


  const handleAddSubTrade = async () => {
    if (!hasTrade) {
      showToast(
        "Please select or add a Trade / Role Category first.",
        "warning"
      );
      return;
    }

    setCustomHierarchyValue(customSubTrade || "");

    setCustomHierarchyModal({
      open: true,
      type: "subTrade",
      title: "Add New SubTrade / Category",
      placeholder: "Enter SubTrade / Category",
    });
  };

  const handleCustomHierarchySubmit = async () => {
    const value = customHierarchyValue.trim();

    if (!value) {
      showToast("Please enter a name.", "warning");
      return;
    }

    const type = customHierarchyModal.type;

    setAddNewLoading(true);

    try {
      const decoded = getDecodedToken();

      const userEmail =
        decoded?.email ||
        decoded?.sub ||
        "";

      const userName =
        decoded?.name ||
        decoded?.unique_name ||
        "Recruiter";

      // ==================================================
      // CUSTOM INDUSTRY
      // ==================================================
      if (type === "industry") {
        const response = await submitIndustrySuggestion({
          field: "RegistrationIndustry",
          suggestedName: value,
          note: "Suggested new Industry Type during job posting",
          submittedByName: userName,
          submittedByEmail: userEmail,
        });

        if (response?.success === false) {
          throw new Error(
            response?.message ||
            "Failed to submit Industry Type suggestion."
          );
        }

        // This job uses the custom Industry immediately.
        setSelectedIndustryId("");
        setSelectedTradeCategoryId("");
        setSelectedSubTradeId("");

        setCustomIndustry(value);
        setCustomTrade("");
        setCustomSubTrade("");

        setPendingIndustrySuggestionId(
          response?.suggestionId || null
        );

        setPendingTradeSuggestionId(null);

        setTradeOptionsList([]);
        setSubTradeOptionsList([]);

        setJobForm((prev) => ({
          ...prev,
          IndustryType: value,
          TradeCategory: "",
          SubTrade: "",
        }));

        showToast(
          "Industry Type added for this job and submitted for admin approval.",
          "success"
        );
      }

      // ==================================================
      // CUSTOM TRADE
      // ==================================================
      else if (type === "trade") {
        if (!hasIndustry) {
          showToast(
            "Please select or add an Industry Type first.",
            "warning"
          );
          return;
        }

        const selectedIndustry = industryOptionsList.find(
          (x) =>
            String(x.value) ===
            String(selectedIndustryId)
        );

        const response = await submitIndustrySuggestion({
          field: "TradeCategory",
          suggestedName: value,
          note: "Suggested new Trade / Role Category during job posting",

          // Only set this when Industry is an existing master record.
          registrationIndustryId:
            selectedIndustryId || null,


  // Custom Industry
           parentSuggestionId:
          pendingIndustrySuggestionId || null,

          submittedByName: userName,
          submittedByEmail: userEmail,
        });

        if (response?.success === false) {
          throw new Error(
            response?.message ||
            "Failed to submit Trade suggestion."
          );
        }

        setSelectedTradeCategoryId("");
        setSelectedSubTradeId("");

        setCustomTrade(value);
        setCustomSubTrade("");

        setPendingTradeSuggestionId(
          response?.suggestionId || null
        );

        setSubTradeOptionsList([]);

        setJobForm((prev) => ({
          ...prev,
          IndustryType:
            selectedIndustry?.label ||
            prev.IndustryType ||
            customIndustry,
          TradeCategory: value,
          SubTrade: "",
        }));

        showToast(
          "Trade added for this job and submitted for admin approval.",
          "success"
        );
      }

      // ==================================================
      // CUSTOM SUBTRADE
      // ==================================================
      else if (type === "subTrade") {
        if (!hasTrade) {
          showToast(
            "Please select or add a Trade / Role Category first.",
            "warning"
          );
          return;
        }

        const response = await submitIndustrySuggestion({
          field: "SubTrade",
          suggestedName: value,
          note: "Suggested new SubTrade / Category during job posting",

          tradeCategoryId: selectedTradeCategoryId || null,
          parentSuggestionId: pendingTradeSuggestionId || null,

          submittedByName: userName,
          submittedByEmail: userEmail,
        });

        if (response?.success === false) {
          throw new Error(
            response?.message ||
            "Failed to submit SubTrade suggestion."
          );
        }

        setSelectedSubTradeId("");
        setCustomSubTrade(value);

        setJobForm((prev) => ({
          ...prev,
          SubTrade: value,
        }));

        showToast(
          "SubTrade added for this job and submitted for admin approval.",
          "success"
        );
      } else if (type === "department") {
        setJobForm((prev) => ({
          ...prev,
          Department: value,
          DepartmentOther: "",
        }));

        showToast(
          "Department added for this job.",
          "success"
        );
      }

      // Close modal
      setCustomHierarchyModal({
        open: false,
        type: "",
        title: "",
        placeholder: "",
      });

      setCustomHierarchyValue("");

    } catch (error) {
      console.error(
        "Failed to submit custom hierarchy suggestion:",
        error
      );

      showToast(
        error?.response?.data?.message ||
        error?.message ||
        "Failed to submit suggestion.",
        "error"
      );
    } finally {
      setAddNewLoading(false);
    }
  };
  /* ── read ?jobId from URL on mount ── */
  useEffect(() => {
    if (typeof window === "undefined") return;
    const params = new URLSearchParams(window.location.search);
    setEditJobId(params.get("jobId"));
  }, []);

  /* ── load draft or edit job on mount ── */
  useEffect(() => {
    if (editJobId) {
      loadJobForEdit(editJobId);
    }
    // No editJobId means the user opened a fresh "Post a Job" — always
    // start blank. Resuming a specific draft happens explicitly via the
    // "Continue Draft" link on the Job List page, which passes ?jobId=...
    // Silently pulling in whatever old draft happened to be sitting in
    // localStorage here caused unrelated, stale data (e.g. a previous
    // job's trade/role) to reappear on a brand-new post.
  }, [editJobId]);

  /* ── inline AI suggestions ── */
  useEffect(() => {
    const timer = setTimeout(() => fetchInlineSuggestions(jobForm.JobDescription, "job"), 1200);
    return () => clearTimeout(timer);
  }, [jobForm.JobDescription]);

  useEffect(() => {
    const timer = setTimeout(() => fetchInlineSuggestions(jobForm.AdditionalJobDescription, "additional"), 1200);
    return () => clearTimeout(timer);
  }, [jobForm.AdditionalJobDescription]);

  /* ── helpers ── */
  const preflightIssues = useMemo(() => validateAllSteps(jobForm), [jobForm]);

  const go = (n) => {
    setActiveStep(n);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const updateDraft = (response) => {
    setLastCompletedStep(response.stepStatus?.lastCompletedStep ?? 0);

    if (response.stepStatus?.lastCompletedStep >= 7) {
      localStorage.removeItem("jobDraft");
      return;
    }

    localStorage.setItem(
      "jobDraft",
      JSON.stringify({
        jobId: response.jobId,
        currentStep: response.stepStatus.lastCompletedStep + 1,
        lastCompletedStep: response.stepStatus.lastCompletedStep,
      })
    );
  };

  const loadJobForEdit = async (id) => {
    try {
      const response = await getJobResume(id);

      console.log("FULL RESPONSE:", response);

      setJobId(id);

      const flatForm = mapResumeToForm(
        response,
        roleCategories[0]
      );

      // =========================================================
      // 1. First populate normal form values
      // =========================================================

      setJobForm((prev) => ({
        ...prev,
        ...flatForm,
      }));

      // =========================================================
      // 2. RESET HIERARCHY STATE
      // =========================================================

      setSelectedIndustryId("");
      setSelectedTradeCategoryId("");
      setSelectedSubTradeId("");

      setCustomIndustry("");
      setCustomTrade("");
      setCustomSubTrade("");

      setTradeOptionsList([]);
      setSubTradeOptionsList([]);

      // =========================================================
      // 3. INDUSTRY
      // =========================================================

      const savedIndustry =
        flatForm.IndustryType?.trim() || "";

      if (!savedIndustry) {
        setLastCompletedStep(
          response.stepStatus?.lastCompletedStep ?? 0
        );

        setActiveStep(1);
        return;
      }

      const industryMatch =
        industryOptionsList.find(
          (x) =>
            String(x.label).trim().toLowerCase() ===
            savedIndustry.toLowerCase()
        );

      // ---------------------------------------------------------
      // EXISTING INDUSTRY
      // ---------------------------------------------------------

      if (industryMatch) {
        const industryId = industryMatch.value;

        console.log(
          "EDIT - EXISTING INDUSTRY:",
          industryMatch
        );

        setSelectedIndustryId(industryId);
        setCustomIndustry("");

        // =======================================================
        // 4. LOAD TRADES FOR EXISTING INDUSTRY
        // =======================================================

        setTradeLoading(true);

        try {
          const tradeResponse =
            await getTradeCategoriesByIndustry(
              industryId
            );

          console.log(
            "EDIT - TRADE RESPONSE:",
            tradeResponse
          );

          const trades = (
            tradeResponse?.tradeCategories || []
          )
            .map((x) => ({
              value:
                x?.id ??
                x?.Id ??
                x?.tradeCategoryId ??
                x?.TradeCategoryId,

              label:
                x?.name ??
                x?.Name ??
                "",
            }))
            .filter(
              (x) =>
                x.value &&
                x.label
            );

          setTradeOptionsList(trades);

          // =====================================================
          // 5. FIND SAVED TRADE
          // =====================================================

          const savedTrade =
            flatForm.TradeCategory?.trim() || "";

          const tradeMatch =
            trades.find(
              (x) =>
                x.label.trim().toLowerCase() ===
                savedTrade.toLowerCase()
            );

          if (!tradeMatch) {
            // Saved trade is custom
            console.log(
              "EDIT - CUSTOM TRADE:",
              savedTrade
            );

            setSelectedTradeCategoryId("");
            setCustomTrade(savedTrade);

            setSelectedSubTradeId("");
            setCustomSubTrade(
              flatForm.SubTrade?.trim() || ""
            );

            setSubTradeOptionsList([]);

            return;
          }

          // =====================================================
          // EXISTING TRADE
          // =====================================================

          console.log(
            "EDIT - EXISTING TRADE:",
            tradeMatch
          );

          setSelectedTradeCategoryId(
            tradeMatch.value
          );

          setCustomTrade("");

          // =====================================================
          // 6. LOAD SUBTRADES
          // =====================================================

          setSubTradeLoading(true);

          try {
            const subTradeResponse =
              await getSubTradesByTradeCategory(
                tradeMatch.value
              );

            console.log(
              "EDIT - SUBTRADE RESPONSE:",
              subTradeResponse
            );

            const subTrades = (
              subTradeResponse?.subTrades || []
            )
              .map((x) => ({
                value:
                  x?.id ??
                  x?.Id ??
                  x?.subTradeId ??
                  x?.SubTradeId,

                label:
                  x?.name ??
                  x?.Name ??
                  "",
              }))
              .filter(
                (x) =>
                  x.value &&
                  x.label
              );

            setSubTradeOptionsList(
              subTrades
            );

            // ===================================================
            // 7. FIND SAVED SUBTRADE
            // ===================================================

            const savedSubTrade =
              flatForm.SubTrade?.trim() || "";

            if (savedSubTrade) {
              const subTradeMatch =
                subTrades.find(
                  (x) =>
                    x.label.trim().toLowerCase() ===
                    savedSubTrade.toLowerCase()
                );

              if (subTradeMatch) {
                // Existing SubTrade
                console.log(
                  "EDIT - EXISTING SUBTRADE:",
                  subTradeMatch
                );

                setSelectedSubTradeId(
                  subTradeMatch.value
                );

                setCustomSubTrade("");
              } else {
                // Custom SubTrade
                console.log(
                  "EDIT - CUSTOM SUBTRADE:",
                  savedSubTrade
                );

                setSelectedSubTradeId("");
                setCustomSubTrade(
                  savedSubTrade
                );
              }
            }
          } catch (subTradeError) {
            console.error(
              "Failed to load sub trades while editing:",
              subTradeError
            );

            setSubTradeOptionsList([]);
          } finally {
            setSubTradeLoading(false);
          }
        } catch (tradeError) {
          console.error(
            "Failed to load trades while editing:",
            tradeError
          );

          setTradeOptionsList([]);
        } finally {
          setTradeLoading(false);
        }
      }

      // ---------------------------------------------------------
      // CUSTOM INDUSTRY
      // ---------------------------------------------------------

      else {
        console.log(
          "EDIT - CUSTOM INDUSTRY:",
          savedIndustry
        );

        setSelectedIndustryId("");
        setCustomIndustry(savedIndustry);

        // Custom Industry cannot have existing Trade
        setTradeOptionsList([]);
        setSelectedTradeCategoryId("");

        const savedTrade =
          flatForm.TradeCategory?.trim() || "";

        setCustomTrade(savedTrade);

        // Custom Trade cannot have existing SubTrade
        setSubTradeOptionsList([]);
        setSelectedSubTradeId("");

        const savedSubTrade =
          flatForm.SubTrade?.trim() || "";

        setCustomSubTrade(savedSubTrade);
      }

      // =========================================================
      // 8. OTHER FORM VALUES
      // =========================================================

      setLastCompletedStep(
        response.stepStatus?.lastCompletedStep ?? 0
      );

      // Always open edit at Step 1
      setActiveStep(1);

    } catch (error) {
      console.error(
        "loadJobForEdit:",
        error
      );
    }
  };

  /* ── AI JD generation ── */
  const handleGenerateJD = async () => {
    try {
      setLoadingAI(true);
      const response = await generateJobDescription({
        jobTitle: jobForm.JobTitle,
        role: jobForm.Role,
        tradeCategory: jobForm.TradeCategory,
        experienceMinYears: jobForm.ExperienceMinYears,
        experienceMaxYears: jobForm.ExperienceMaxYears,
        jobType: jobForm.JobType,
        employmentType: jobForm.EmploymentType,
      });
      setJobForm((p) => ({
        ...p,
        // The AI response now returns one consolidated description
        // (summary + responsibilities + requirements + benefits) instead of
        // splitting it across JobDescription and a separate Key
        // Responsibilities field — previously both were filled from the
        // same responsibilities list, showing identical bullets twice on
        // this screen. KeyResponsibilities/Step3KeyResponsibilities are
        // left as-is here for manual entry if the employer wants them. 
        JobDescription: response.generatedDescription || "",
        KeySkills: response.suggestedSkills ?? p.KeySkills,
      }));
    } catch (error) {
      console.error("generateJD:", error);
    } finally {
      setLoadingAI(false);
    }
  };

  const handleGenerateAdditionalJD = async () => {
    try {
      setLoadingAI(true);
      const response = await generateJobDescription({
        jobTitle: jobForm.JobTitle,
        role: jobForm.Role,
        tradeCategory: jobForm.TradeCategory,
        experienceMinYears: jobForm.ExperienceMinYears,
        experienceMaxYears: jobForm.ExperienceMaxYears,
        jobType: jobForm.JobType,
        employmentType: jobForm.EmploymentType,
      });
      setJobForm((p) => ({
        ...p,
        AdditionalJobDescription:
          response.additionalDescription || p.AdditionalJobDescription,
        Step3KeyResponsibilities: response.requirements?.length
          ? response.requirements
          : p.Step3KeyResponsibilities,
        KeySkills: p.KeySkills?.length ? p.KeySkills : response.suggestedSkills ?? [],
      }));
    } catch (error) {
      console.error("generateAdditionalJD:", error);
    } finally {
      setLoadingAI(false);
    }
  };

  /* ── AI skill suggestions (Step 3 — skills are AI-generated only, no manual typing) ── */
  const handleSuggestSkills = async () => {
    if (!jobForm.JobTitle.trim()) {
      showToast("Add a Job Title in Step 1 first so AI knows what skills to suggest.", "warning");
      return;
    }
    try {
      setSkillsLoading(true);
      const response = await suggestSkills({
        jobTitle: jobForm.JobTitle,
        tradeCategory: jobForm.TradeCategory,
        jobDescription: jobForm.JobDescription,
      });
      setJobForm((p) => ({
        ...p,
        KeySkills: response?.skills ?? p.KeySkills,
      }));
    } catch (error) {
      console.error("suggestSkills:", error);
      showToast("Failed to generate skills. Please try again.", "error");
    } finally {
      setSkillsLoading(false);
    }
  };

  /* Auto-generate skills the first time the employer reaches Step 3, 
     as long as they haven't been filled already (e.g. from Step 1's 
     "Generate with AI" JD button, or from resuming a draft). */
  useEffect(() => {
    if (
      activeStep === 3 &&
      jobForm.KeySkills.length === 0 &&
      jobForm.JobTitle.trim() &&
      !skillsLoading
    ) {
      handleSuggestSkills();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps 
  }, [activeStep]);

  const fetchInlineSuggestions = async (currentText, target = "job") => {
    if (!currentText || currentText.length < 20) return;
    const shouldSuggest =
      currentText.endsWith(" ") ||
      currentText.endsWith(".") ||
      currentText.endsWith(",");
    if (!shouldSuggest) return;
    try {
      const response = await getInlineSuggestion({
        jobTitle: jobForm.JobTitle,
        role: jobForm.Role,
        tradeCategory: jobForm.TradeCategory,
        experienceMinYears: jobForm.ExperienceMinYears,
        jobType: jobForm.JobType,
        currentText,
      });
      if (target === "job") {
        const suggestions = response.suggestions ?? [];
        setJdSuggestions(suggestions);
        setGhostSuggestion(suggestions[0] ?? "");
      } else {
        setAdditionalJdSuggestions(response.suggestions ?? []);
      }
    } catch (error) {
      console.error("inlineSuggestion:", error);
    }
  };

  const handleJDTab = (e) => {
    if (e.key === "Tab" && ghostSuggestion) {
      e.preventDefault();
      setJobForm((p) => ({
        ...p,
        JobDescription: p.JobDescription.trimEnd() + " " + ghostSuggestion,
      }));
      setGhostSuggestion("");
    }
  };

  /* ══════════════════════════════════════════════════════════════════════════ 
     STEP SUBMIT HANDLERS 
  ══════════════════════════════════════════════════════════════════════════ */

  const handleStep1 = async () => {
    if (!jobForm.JobTitle.trim()) return showToast("Job Title is required", "error");
    if (!jobForm.TradeCategory) return showToast("Trade Category is required", "error");
    if (isOtherValue(jobForm.TradeCategory) && !jobForm.TradeCategoryOther.trim()) {
      return showToast("Please specify the Trade Category when 'Other' is selected", "error");
    }
    if (!jobForm.IndustryType) return showToast("Industry Type is required", "error");
    if (isOtherValue(jobForm.IndustryType) && !jobForm.IndustryTypeOther.trim()) {
      return showToast("Please specify the Industry Type when 'Other' is selected", "error");
    }
    if (isOtherValue(jobForm.Department) && !jobForm.DepartmentOther.trim()) {
      return showToast("Please specify the Department when 'Other' is selected", "error");
    }
    if (!jobForm.JobType) return showToast("Job Type is required", "error");
    if (!jobForm.EmploymentType) return showToast("Employment Type is required", "error");
    if (!jobForm.EmploymentMode) return showToast("Employment Mode is required", "error");
    if (jobForm.IsClientHiring && !jobForm.ClientName.trim()) {
      return showToast("Client Name is required", "error");
    }
    console.log("jobForm.ContractPeriod =", jobForm.ContractPeriod);
    setLoading(true);
    try {
      // When "Other" is selected, send the free-text value the employer
      // typed instead of the literal word "Other" so the backend/DB stores
      // a meaningful value.
      const resolvedTradeCategory = isOtherValue(jobForm.TradeCategory)
        ? jobForm.TradeCategoryOther.trim()
        : jobForm.TradeCategory;
      const resolvedIndustryType = isOtherValue(jobForm.IndustryType)
        ? jobForm.IndustryTypeOther.trim()
        : jobForm.IndustryType;
      const resolvedDepartment = isOtherValue(jobForm.Department)
        ? jobForm.DepartmentOther.trim()
        : jobForm.Department;

      console.log("===== STEP 1 SAVE =====");
      console.log("JobId:", jobId);
      console.log("IndustryType:", jobForm.IndustryType);
      console.log("TradeCategory:", jobForm.TradeCategory);
      console.log("SubTrade:", jobForm.SubTrade);
      console.log("=======================");

      const response = await saveJobDetails({
        JobId: jobId ?? "",
        JobTitle: jobForm.JobTitle,
        TradeCategory: resolvedTradeCategory,
        SubTrade: jobForm.SubTrade,
        Role: jobForm.Role,
        IndustryType: resolvedIndustryType,

        IsClientHiring: jobForm.IsClientHiring,
        ClientName: jobForm.ClientName,
        ShowClientName: jobForm.ShowClientName,

        ExperienceMinYears: jobForm.ExperienceMinYears,
        ExperienceMaxYears: jobForm.ExperienceMaxYears,
        JobType: jobForm.JobType,
        EmploymentType: jobForm.EmploymentType,
        ContractPeriod:
          jobForm.EmploymentType === "Contract"
            ? jobForm.ContractPeriod
            : "",
        EmploymentMode: jobForm.EmploymentMode,
        Department: resolvedDepartment,
        DutyHoursPerDay: jobForm.DutyHoursPerDay,
        IsOilField: jobForm.IsOilField,
        PaidOvertime: jobForm.PaidOvertime,
        KeyResponsibilities: jobForm.KeyResponsibilities,
      });

      setJobId(response.jobId);
      updateDraft(response);
      console.log("STEP 1 JOB FORM:", response);
      console.log("CONTRACT PERIOD:", response.ContractPeriod);
      console.log("EMPLOYMENT TYPE:", response.EmploymentType);

      try {
        const decoded = getDecodedToken();
        const userEmail = decoded?.email || decoded?.sub || "";
        const userName = decoded?.name || decoded?.unique_name || "";

        if (isOtherValue(jobForm.TradeCategory) && jobForm.TradeCategoryOther.trim()) {
          try {
            await submitJobSuggestion({
              field: "TradeRole",
              suggestedName: jobForm.TradeCategoryOther.trim(),
              note: "Suggested other Trade / Role Category during job posting",
              submittedByName: userName,
              submittedByEmail: userEmail,
            });
          } catch (suggestionErr) {
            console.error("Failed to submit trade suggestion:", suggestionErr);
          }
        }

        if (isOtherValue(jobForm.IndustryType) && jobForm.IndustryTypeOther.trim()) {
          try {
            await submitIndustrySuggestion({
              field: "industry",
              suggestedName: jobForm.IndustryTypeOther.trim(),
              note: "Suggested other Industry Type during job posting",
              submittedByName: userName,
              submittedByEmail: userEmail,
            });
          } catch (suggestionErr) {
            console.error("Failed to submit industry suggestion:", suggestionErr);
          }
        }

        if (isOtherValue(jobForm.Department) && jobForm.DepartmentOther.trim()) {
          try {
            await submitJobSuggestion({
              field: "Department",
              suggestedName: jobForm.DepartmentOther.trim(),
              note: "Suggested other Department during job posting",
              submittedByName: userName,
              submittedByEmail: userEmail,
            });
          } catch (suggestionErr) {
            console.error("Failed to submit department suggestion:", suggestionErr);
          }
        }
      } catch (tokenErr) {
        console.error("Failed to decode token or submit suggestions:", tokenErr);
      }

      go(2);
    } catch (error) {
      console.error("Step 1:", error?.response?.data ?? error);
      showToast(
        error?.response?.data?.message || "Failed to save job details. Please try again.",
        "error",
      );
    }

    finally {
      setLoading(false);
    }
  };

  const handleStep2 = async () => {
    if (!jobForm.SalaryMin) return showToast("Minimum Salary is required", "error");
    if (!jobForm.SalaryMax) return showToast("Maximum Salary is required", "error");
    if (Number(jobForm.SalaryMin) > Number(jobForm.SalaryMax)) {
      return showToast("Minimum Salary cannot be greater than Maximum Salary", "error");
    }

    setLoading(true);
    try {
      const response = await saveCompensation(jobId, {
        SalaryMin: jobForm.SalaryMin,
        SalaryMax: jobForm.SalaryMax,
        SalaryCurrency: jobForm.SalaryCurrency,
        SalaryDisplayOption: jobForm.SalaryDisplayOption,
        SalaryPeriod: jobForm.SalaryPeriod,
      });
      updateDraft(response);
      go(3);
    } catch (error) {
      console.error("Step 2:", error?.response?.data ?? error);
      showToast(
        error?.response?.data?.message || "Failed to save compensation. Please try again.",
        "error",
      );
    } finally {
      setLoading(false);
    }
  };

  const handleStep3 = async () => {
    if (!jobForm.JobDescription.trim()) return showToast("Job Description is required", "error");

    setLoading(true);
    try {
      console.log("Saving Step 3:", {
        Benefits: jobForm.Benefits,
        Tags: jobForm.Tags,
        KeySkills: jobForm.KeySkills,
      });
      const response = await saveSkills(jobId, {
        KeySkills: jobForm.KeySkills,
        KeyResponsibilities: jobForm.Step3KeyResponsibilities,
        AdditionalJobDescription: jobForm.AdditionalJobDescription,
        JobDescription: jobForm.JobDescription,
        LanguageRequired: jobForm.LanguageRequired,
        Benefits: jobForm.Benefits,
        Tags: jobForm.Tags,
      });
      updateDraft(response);
      go(4);
    } catch (error) {
      console.error("Step 3:", error?.response?.data ?? error);
      showToast(
        error?.response?.data?.message || "Failed to save skills. Please try again.",
        "error",
      );
    } finally {
      setLoading(false);
    }
  };

  const handleStep4 = async () => {
    if (!jobForm.Vacancies) return showToast("Number of Vacancies is required", "error");

    setLoading(true);
    try {
      const response = await saveEligibility(jobId, {
        Vacancies: jobForm.Vacancies,
        EducationRequired: jobForm.EducationRequired,
        AgeMin: jobForm.AgeMin,
        AgeMax: jobForm.AgeMax,
        GenderPreferred: jobForm.GenderPreferred,
        DisabilityEligible: jobForm.DisabilityEligible,
        PassportRequired: jobForm.PassportRequired,
        PassportValidityMonths: jobForm.PassportValidityMonths,
        LicenceDocsRequired: jobForm.LicenceDocsRequired,
        WorkingDocsRequired: jobForm.WorkingDocsRequired,
      });
      updateDraft(response);
      go(5);
    } catch (error) {
      console.error("Step 4:", error?.response?.data ?? error);
      showToast(
        error?.response?.data?.message || "Failed to save eligibility. Please try again.",
        "error",
      );
    } finally {
      setLoading(false);
    }
  };


  const handleStep5 = async () => {
    if (!jobForm.LocationType) return showToast("Location Type is required", "error");
    if (
      jobForm.LocationType === "Offshore" &&
      !jobForm.OffshoreVesselName.trim()
    ) {
      setErrors((prev) => ({
        ...prev,
        OffshoreVesselName: "Vessel / Platform Name is required",
      }));

      return;
    }

    setErrors((prev) => ({
      ...prev,
      OffshoreVesselName: "",
    }));

    setLoading(true);
    try {
      const response = await saveLocation(jobId, {
        LocationType: jobForm.LocationType,
        Country: jobForm.Country,
        WorkAddressLine: jobForm.WorkAddressLine,
        OnshoreCity: jobForm.OnshoreCity,
        OnshoreState: jobForm.OnshoreState,
        OnshoreCountry: jobForm.OnshoreCountry,
        OnshorePincode: jobForm.OnshorePincode,
        OffshoreVesselName: jobForm.OffshoreVesselName,
        OffshoreRegion: jobForm.OffshoreRegion,
        OffshoreCountry: jobForm.OffshoreCountry,
      });
      updateDraft(response);
      go(6);
    } catch (error) {
      console.error("Step 5:", error?.response?.data ?? error);
      showToast(
        error?.response?.data?.message || "Failed to save location. Please try again.",
        "error",
      );
    } finally {
      setLoading(false);
    }
  };

  const handleStep6 = async () => {
    setLoading(true);

    try {
      const response = await saveQuestions(jobId, {
        questions: jobForm.questions
          .filter((q) => q.questionText.trim() !== "")
          .map((q) => ({
            questionText: q.questionText,
          })),
      });

      updateDraft(response);
      go(7);
    } catch (error) {
      console.error("Step 6:", error?.response?.data ?? error);
      showToast(
        error?.response?.data?.message || "Failed to save questions. Please try again.",
        "error",
      );
    } finally {
      setLoading(false);
    }
  };

  const handleStep7 = async () => {
    const issues = validateAllSteps(jobForm);
    if (issues.length > 0) {
      showToast(
        `Please complete ${issues.length} pending item${issues.length > 1 ? "s" : ""} before publishing — see the checklist below`,
        "warning"
      );
      // jump to whichever earlier step has the first unresolved issue so it's not hidden off-screen 
      if (issues[0].stepNum !== 7) go(issues[0].stepNum);
      return;
    }

    setLoading(true);
    try {
      await publishJob({
        JobId: jobId,
        ApplicationDeadline: jobForm.ApplicationDeadline,
        CompanyVisibility: jobForm.CompanyVisibility,
        JobType: jobForm.JobType,
        PublishingTags: jobForm.PublishingTags,
        PublishNow: true, // "Save & Publish" always publishes directly — draft saving has its own separate button 
      });
      localStorage.removeItem("jobDraft");
      showToast("Job published successfully!", "success");
      router.push("/employeer/job-list?success=job-published");
    } catch (error) {
      console.error("Step 7:", error?.response?.data ?? error);
      showToast("Failed to publish job. Please try again.", "error");
    } finally {
      setLoading(false);
    }
  };

  const stepHandlers = [
    handleStep1,
    handleStep2,
    handleStep3,
    handleStep4,
    handleStep5,
    handleStep6,
    handleStep7,
  ];

  const ActiveStep = STEP_VIEWS[activeStep - 1] ?? Step7;

  /* ── render ── */
  return (
    <main className="main">
      <section className={`section-box mt-50 mb-50 ${styles.pageSection}`}>
        <div className={`container ${styles.layout}`}>
          <div className={styles.content}>
            {/* Header */}
            <div className="box-filters-job">
              <div className="row align-items-center">
                <div className="col-xl-8 col-lg-8">
                  <h3 className="mb-5">Post a Job</h3>
                  <span className="font-sm color-text-paragraph-2">
                    Create normal, hot vacancy, and classified posts in the same
                    employer workflow.
                  </span>
                </div>
                <div className="col-xl-4 col-lg-4 text-lg-end mt-sm-15">
                  <div className={styles.headerActions}>
                    <button
                      className={`btn btn-default btn-sm ${styles.btnSoft}`}
                      disabled={!jobId || loading}
                      onClick={async () => {
                        if (!jobId) return;
                        try {
                          await saveDraft(jobId);
                          showToast("Draft saved!", "success");
                        } catch (error) {
                          console.error(error);
                          showToast("Could not save draft.", "error");
                        }
                      }}
                    >
                      Save Draft
                    </button>
                    <button
                      type="button"
                      className="btn btn-default btn-sm"
                      onClick={() => setShowPreview(true)}
                    >
                      Preview
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Progress bar */}
            <StepProgressBar
              activeStep={activeStep}
              onStepClick={go}
              lastCompletedStep={lastCompletedStep}
            />

            {/* Active step */}
            <div className={styles.body}>
              <div className={styles.fullFormPanel}>
                {loading && (
                  <div style={{ textAlign: "center", padding: "10px 0", fontWeight: 600, color: "#555" }}>
                    Saving…
                  </div>
                )}

                <ActiveStep
                  go={go}
                  jobForm={jobForm}
                  setJobForm={setJobForm}
                  errors={errors}
                  onSubmit={stepHandlers[activeStep - 1] ?? (() => { })}
                  handleDepartmentChange={handleDepartmentChange}
                  handleGenerateJD={handleGenerateJD}
                  handleGenerateAdditionalJD={handleGenerateAdditionalJD}
                  loadingAI={loadingAI}
                  jdSuggestions={jdSuggestions}
                  additionalJdSuggestions={additionalJdSuggestions}
                  ghostSuggestion={ghostSuggestion}
                  handleJDTab={handleJDTab}
                  handleSuggestSkills={handleSuggestSkills}
                  skillsLoading={skillsLoading}
                  preflightIssues={preflightIssues}

                  roleCategoriesList={roleCategoriesList}
                  departmentOptionsList={departmentOptionsList}

                  industryOptionsList={industryOptionsList}
                  tradeOptionsList={tradeOptionsList}
                  subTradeOptionsList={subTradeOptionsList}

                  selectedIndustryId={selectedIndustryId}
                  selectedTradeCategoryId={selectedTradeCategoryId}
                  selectedSubTradeId={selectedSubTradeId}

                  customIndustry={customIndustry}
                  customTrade={customTrade}
                  customSubTrade={customSubTrade}

                  industryIsCustom={industryIsCustom}
                  tradeIsCustom={tradeIsCustom}

                  hasIndustry={hasIndustry}
                  hasTrade={hasTrade}

                  industryLoading={industryLoading}
                  tradeLoading={tradeLoading}
                  subTradeLoading={subTradeLoading}

                  onIndustryChange={handleIndustryChange}
                  onTradeChange={handleTradeChange}
                  onSubTradeChange={handleSubTradeChange}

                  onAddIndustry={handleAddIndustry}
                  onAddTrade={handleAddTrade}
                  onAddSubTrade={handleAddSubTrade}
                />

                <div className={styles.bottomLink}>
                  <Link href="/dashboard">Back to Dashboard</Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <JobPreviewModal
        open={showPreview}
        onClose={() => setShowPreview(false)}
        job={jobForm}
      />

      {customHierarchyModal.open && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(15, 23, 42, 0.45)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 9999,
            padding: "20px",
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget && !addNewLoading) {
              setCustomHierarchyModal({
                open: false,
                type: "",
                title: "",
                placeholder: "",
              });
              setCustomHierarchyValue("");
            }
          }}
        >
          <div
            style={{
              width: "100%",
              maxWidth: "480px",
              background: "#fff",
              borderRadius: "14px",
              boxShadow: "0 20px 60px rgba(0,0,0,0.20)",
              padding: "24px",
            }}
            role="dialog"
            aria-modal="true"
          >
            <h4
              style={{
                margin: "0 0 8px",
                color: "#122359",
                fontSize: "20px",
                fontWeight: 700,
              }}
            >
              {customHierarchyModal.title}
            </h4>

            <p
              style={{
                margin: "0 0 18px",
                color: "#667085",
                fontSize: "14px",
              }}
            >
              Enter the new value.
              {customHierarchyModal.type !== "development" &&
                " It will be used for this job and submitted for admin approval."}
            </p>

            <input
              type="text"
              autoFocus
              value={customHierarchyValue}
              onChange={(e) =>
                setCustomHierarchyValue(e.target.value)
              }
              onKeyDown={(e) => {
                if (e.key === "Enter" && !addNewLoading) {
                  e.preventDefault();
                  handleCustomHierarchySubmit();
                }

                if (e.key === "Escape" && !addNewLoading) {
                  setCustomHierarchyModal({
                    open: false,
                    type: "",
                    title: "",
                    placeholder: "",
                  });
                  setCustomHierarchyValue("");
                }
              }}
              placeholder={customHierarchyModal.placeholder}
              disabled={addNewLoading}
              style={{
                width: "100%",
                height: "46px",
                border: "1px solid #d0d5dd",
                borderRadius: "8px",
                padding: "0 14px",
                fontSize: "15px",
                outline: "none",
                boxSizing: "border-box",
              }}
            />

            <div
              style={{
                display: "flex",
                justifyContent: "flex-end",
                gap: "10px",
                marginTop: "20px",
              }}
            >
              <button
                type="button"
                disabled={addNewLoading}
                onClick={() => {
                  setCustomHierarchyModal({
                    open: false,
                    type: "",
                    title: "",
                    placeholder: "",
                  });
                  setCustomHierarchyValue("");
                }}
                style={{
                  height: "42px",
                  padding: "0 18px",
                  border: "1px solid #d0d5dd",
                  background: "#fff",
                  color: "#344054",
                  borderRadius: "8px",
                  cursor: addNewLoading
                    ? "not-allowed"
                    : "pointer",
                }}
              >
                Cancel
              </button>

              <button
                type="button"
                disabled={
                  addNewLoading ||
                  !customHierarchyValue.trim()
                }
                onClick={handleCustomHierarchySubmit}
                style={{
                  height: "42px",
                  padding: "0 20px",
                  border: "none",
                  background: "#ffa300",
                  color: "1223591f",
                  borderRadius: "8px",
                  fontWeight: 600,
                  cursor:
                    addNewLoading ||
                      !customHierarchyValue.trim()
                      ? "not-allowed"
                      : "pointer",
                  opacity:
                    addNewLoading ||
                      !customHierarchyValue.trim()
                      ? 0.6
                      : 1,
                }}
              >
                {addNewLoading ? "Submitting..." : "Add"}
              </button>
            </div>
          </div>
        </div>
      )}
    </main>


  );
}