'use client';
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { getAllJobs } from '@/services/candidate/allJobsService';
import { getCandidateId } from '@/utils/authHelper';
import { getProfileSummary } from '@/services/candidate/profileSummaryService';
import JobCardList from './JobCardList';
import ApplyJobModal from '@/app/Homepage/components/ApplyJobModal';
import Pagination from './Pagination';
import { getJobDetails } from "@/services/candidate/jobDetailsService";
import { getMyApplications } from "@/services/candidate/myApplicationsService";
import { useRouter } from 'next/navigation';
import { resolveCountry } from '@/utils/locationResolver';
import { getPersonalInfo } from '@/services/candidate/profileService';
import { getSkills } from '@/services/candidate/skillsService';
import { getWorkExperience } from '@/services/candidate/workExperienceService';

const normalizeString = (str) => {
  if (!str) return "";
  return String(str).toLowerCase().replace(/[^a-z0-9]/g, "");
};

const normalizeAndTokenize = (str) => {
  if (!str) return [];
  return String(str)
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter(w => w.length > 2);
};

const computeCandidateMatchScore = (job, candidateProfile) => {
  if (!candidateProfile) return 0;

  let score = 0;

  // 1. Specified Job Title & Role Match (Highest priority)
  const candidateTitles = [
    candidateProfile.trade,
    candidateProfile.jobTitle,
    candidateProfile.role
  ].filter(Boolean).map(t => t.trim().toLowerCase());

  const jobTitleLower = (job.jobTitle || "").toLowerCase();
  const tradeCategoryLower = (job.tradeCategory || "").toLowerCase();

  candidateTitles.forEach(title => {
    if (jobTitleLower === title) {
      score += 1000;
    } else if (jobTitleLower.includes(title) || title.includes(jobTitleLower)) {
      score += 600;
    } else {
      // Token overlap
      const jobTokens = normalizeAndTokenize(jobTitleLower);
      const titleTokens = normalizeAndTokenize(title);
      const common = jobTokens.filter(t => titleTokens.includes(t));
      if (common.length > 0) {
        score += 200 * common.length;
      }
    }

    if (tradeCategoryLower === title) {
      score += 800;
    } else if (tradeCategoryLower.includes(title) || title.includes(tradeCategoryLower)) {
      score += 400;
    }
  });

  // 2. Skills Match
  if (Array.isArray(candidateProfile.skills) && Array.isArray(job.skills)) {
    const jobSkills = job.skills.map(s => s.toLowerCase());
    candidateProfile.skills.forEach(skill => {
      if (jobSkills.includes(skill.toLowerCase())) {
        score += 100;
      }
    });
  }

  // 3. Work History Job Title Match
  if (Array.isArray(candidateProfile.workHistory)) {
    candidateProfile.workHistory.forEach(pastTitle => {
      const pastTitleLower = pastTitle.toLowerCase();
      if (jobTitleLower === pastTitleLower) {
        score += 150;
      } else if (jobTitleLower.includes(pastTitleLower)) {
        score += 80;
      }
    });
  }

  return score;
};

const computeClientAiMatchPercentage = (job, candidateProfile) => {
  if (!candidateProfile) return null;

  let score = 0;

  // 1. Specified Title/Role match (Max 50%)
  const candidateTitles = [
    candidateProfile.trade,
    candidateProfile.jobTitle,
    candidateProfile.role
  ].filter(Boolean).map(t => t.trim().toLowerCase());

  const jobTitleLower = (job.jobTitle || "").toLowerCase();
  const tradeCategoryLower = (job.tradeCategory || "").toLowerCase();

  let titleMatchScore = 0;
  candidateTitles.forEach(title => {
    if (jobTitleLower === title) {
      titleMatchScore = Math.max(titleMatchScore, 50);
    } else if (jobTitleLower.includes(title) || title.includes(jobTitleLower)) {
      titleMatchScore = Math.max(titleMatchScore, 35);
    } else {
      const jobTokens = normalizeAndTokenize(jobTitleLower);
      const titleTokens = normalizeAndTokenize(title);
      const common = jobTokens.filter(t => titleTokens.includes(t));
      if (common.length > 0) {
        titleMatchScore = Math.max(titleMatchScore, Math.min(30, common.length * 15));
      }
    }

    if (tradeCategoryLower === title) {
      titleMatchScore = Math.max(titleMatchScore, 40);
    } else if (tradeCategoryLower.includes(title)) {
      titleMatchScore = Math.max(titleMatchScore, 25);
    }
  });
  score += titleMatchScore;

  // 2. Skills Match (Max 30%)
  if (Array.isArray(candidateProfile.skills) && Array.isArray(job.skills) && candidateProfile.skills.length > 0) {
    const jobSkills = job.skills.map(s => s.toLowerCase());
    const matchedSkills = candidateProfile.skills.filter(s => jobSkills.includes(s.toLowerCase()));
    const ratio = matchedSkills.length / Math.min(candidateProfile.skills.length, 5);
    score += Math.min(30, Math.round(ratio * 30));
  }

  // 3. Location Match (Max 10%)
  const jobLoc = (job.jobLocation || "").toLowerCase();
  const candCity = (candidateProfile.city || "").toLowerCase();
  const candState = (candidateProfile.state || "").toLowerCase();
  if (candCity && jobLoc.includes(candCity)) {
    score += 10;
  } else if (candState && jobLoc.includes(candState)) {
    score += 5;
  }

  // 4. Experience Match (Max 10%)
  if (candidateProfile.totalExperienceYears !== undefined) {
    const candExp = Number(candidateProfile.totalExperienceYears) || 0;
    const jobExpText = String(job.experienceDisplay || "").toLowerCase();
    const nums = jobExpText.match(/\d+/g)?.map(Number) || [];
    if (jobExpText.includes("fresher")) {
      if (candExp <= 1) score += 10;
    } else if (nums.length > 0) {
      const min = nums[0];
      const max = nums[1] || min;
      if (candExp >= min && candExp <= max) {
        score += 10;
      } else if (candExp >= min) {
        score += 5;
      }
    } else {
      score += 5;
    }
  }

  return Math.min(99, Math.max(10, score));
};

const JobList = ({ filters = {} }) => {
  const router = useRouter();
  const [currentPage, setCurrentPage] = useState(1);
  const [allJobs, setAllJobs] = useState([]);       // full unfiltered dataset, fetched once
  const [loading, setLoading] = useState(true);
  const [showPerPage, setShowPerPage] = useState(12);
  const [sortBy, setSortBy] = useState('Best Match');
  const [viewMode, setViewMode] = useState('list');
  const [showApplyModal, setShowApplyModal] = useState(false);
  const [activeJob, setActiveJob] = useState(null);
  const [appliedJobIds, setAppliedJobIds] = useState(() => new Set());
  const [candidateProfile, setCandidateProfile] = useState(null);
  // Candidate's own trade category / preferred role — drives the "your
  // trade first" priority ordering below, independent of sortBy/filters.
  const [candidateTrade, setCandidateTrade] = useState(null);
  const [candidateRole, setCandidateRole] = useState(null);

  const requestIdRef = useRef(0);

  useEffect(() => {
    const fetchCandidateData = async () => {
      const candidateId = getCandidateId();
      if (!candidateId) return;

      try {
        const [infoRes, skillsRes, workRes] = await Promise.allSettled([
          getPersonalInfo(),
          getSkills(),
          getWorkExperience()
        ]);

        let profile = {};

        if (infoRes.status === 'fulfilled' && infoRes.value?.data?.success) {
          const info = infoRes.value.data.data || {};
          profile.trade = info.role || info.jobTitle || "";
          profile.role = info.role || "";
          profile.jobTitle = info.jobTitle || "";
          profile.city = info.currentCity || "";
          profile.state = info.currentState || "";
          profile.totalExperienceYears = info.totalExperienceYears || 0;
        }

        if (skillsRes.status === 'fulfilled' && skillsRes.value?.data?.success) {
          const skillsData = skillsRes.value.data.data || {};
          profile.skills = (skillsData.skills || []).map(s => s.skillName) || [];
        }

        if (workRes.status === 'fulfilled' && workRes.value?.data?.success) {
          profile.workHistory = (workRes.value.data.data || []).map(w => w.jobTitle) || [];
        }

        setCandidateProfile(profile);
      } catch (error) {
        console.error("Failed to load candidate profile in JobList", error);
      }
    };

    fetchCandidateData();
  }, []);

  // ---- Fetch the full job list ONCE (not on every filter/page/sort change) ----
  useEffect(() => {
    const thisRequestId = ++requestIdRef.current;
    const load = async () => {
      try {
        setLoading(true);
        const candidateId = getCandidateId();
        const response = await getAllJobs(candidateId ? { candidateId } : {});

        const jobs = response.data || [];
        if (thisRequestId !== requestIdRef.current) return; // stale response guard
        const processed = jobs.map((job) => ({
          ...job,
          salaryDisplay: job.salaryDisplay || job.salaryRange,
        }));
        setAllJobs(processed);
      } catch (error) {
        if (thisRequestId !== requestIdRef.current) return;
        console.error("Failed to load jobs", error);
        setAllJobs([]);
      } finally {
        if (thisRequestId === requestIdRef.current) setLoading(false);
      }
    };
    load();
  }, []);

  React.useEffect(() => {
    setCurrentPage(1);
  }, [filters, sortBy, showPerPage]);

  const loadAppliedJobs = async () => {
    try {
      const res = await getMyApplications();
      const ids = (res?.data?.applications || [])
        .map((a) => a.jobId)
        .filter(Boolean);
      setAppliedJobIds(new Set(ids));
    } catch (error) {
      console.log("applied jobs load skipped", error?.message || error);
    }
  };

  useEffect(() => {
    // Only logged-in candidates have applications to fetch. Calling this
    // for anonymous visitors hits an [Authorize]-protected endpoint, which
    // returns 401 and trips the global axios interceptor into redirecting
    // everyone (even anonymous browsers) to /Login.
    if (getCandidateId()) {
      loadAppliedJobs();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const loadCandidateTradeRole = async () => {
      if (!getCandidateId()) return;
      try {
        const response = await getProfileSummary();
        const data = response?.data?.data;
        setCandidateTrade(data?.primaryTrade || data?.role || null);
        setCandidateRole(data?.role || null);
      } catch (error) {
        console.log("candidate trade/role load skipped", error?.message || error);
      }
    };
    loadCandidateTradeRole();
  }, []);

  const openApplyModal = async (job) => {
    const candidateId = getCandidateId();
    if (!candidateId) {
      router.push(`/Login?redirectTo=/jobs-list`);
      return;
    }
    try {
      const response = await getJobDetails(job.jobId);
      setActiveJob(response.data);
      setShowApplyModal(true);
    } catch (error) {
      console.error("Failed to load job details", error);
    }
  };

  // ---------------- Client-side filtering (single source of truth: industryType) ----------------

  const matchesKeyword = (job) => {
    const keyword = (filters.keyword || "").trim();
    if (!keyword) return true;
    const nk = normalizeString(keyword);
    const haystack = normalizeString(
      [job.jobTitle, job.tradeCategory, job.industryType, job.companyName, job.description].join(" ")
    );
    return haystack.includes(nk);
  };

  const matchesLocationSingle = (job) => {
    const loc = (filters.locationSingle || "").trim();
    if (!loc) return true;

    // Check if the resolved country matches the search location
    const resolvedCountry = resolveCountry(job.jobLocation || job.city || job.state);
    if (resolvedCountry && normalizeString(resolvedCountry) === normalizeString(loc)) {
      return true;
    }

    const jobLoc = normalizeString(job.jobLocation || job.city);
    return jobLoc.includes(normalizeString(loc));
  };

  const matchesCity = (job) => {
    const selected = filters.cities || [];
    if (selected.length === 0) return true;
    const jobCity = normalizeString(job.jobLocation || job.city);
    return selected.some(city => jobCity.includes(normalizeString(city)));
  };

  const matchesState = (job) => {
    const selected = filters.states || [];
    if (selected.length === 0) return true;
    const jobState = normalizeString(job.jobLocation || job.state);
    return selected.some(state => jobState.includes(normalizeString(state)));
  };

  // This is the field BrowseByCategory.jsx (homepage tiles) groups/counts by.
  // Kept separate from tradeCategory below — they are different taxonomies.
  const matchesIndustryType = (job) => {
    const selected = filters.industries || [];
    if (selected.length === 0) return true;
    const jobIndustry = normalizeString(job.industryType);
    return selected.some(cat => jobIndustry === normalizeString(cat));
  };

  // This is the field Hero Search's "Trade Category" dropdown and the
  // sidebar's "Trade Category" checkboxes both use — kept as its own
  // independent AND condition rather than merged with industryType.
  const matchesTradeCategory = (job) => {
    const selected = filters.tradeCategories || [];
    if (selected.length === 0) return true;
    const jobTrade = normalizeString(job.tradeCategory);
    return selected.some(cat => jobTrade === normalizeString(cat));
  };

  const matchesRole = (job) => {
    const selected = [...(filters.roles || []), ...(filters.role || [])];
    if (selected.length === 0) return true;
    const jobRole = normalizeString(job.jobTitle || job.role);
    return selected.some(role => jobRole.includes(normalizeString(role)));
  };

  const matchesEducation = (job) => {
    const selected = filters.educationLevels || [];
    if (selected.length === 0) return true;
    const jobEdu = normalizeString(job.educationRequired);
    return selected.some(edu => jobEdu === normalizeString(edu));
  };

  const matchesEmploymentType = (job) => {
    const selected = filters.employmentTypes || [];
    if (selected.length === 0) return true;
    const jobEmpType = normalizeString(job.employmentType);
    return selected.some(type => jobEmpType === normalizeString(type));
  };

  const matchesLocationType = (job) => {
    const selected = filters.locationTypes || [];
    if (selected.length === 0) return true;
    const jobLocType = normalizeString(job.locationType);
    return selected.some(type => jobLocType === normalizeString(type));
  };

  const matchesEmploymentMode = (job) => {
    const selected = filters.employmentModes || [];
    if (selected.length === 0) return true;
    const jobEmpMode = normalizeString(job.employmentMode);
    return selected.some(mode => jobEmpMode === normalizeString(mode));
  };

  const matchesDepartment = (job) => {
    const selected = filters.departments || [];
    if (selected.length === 0) return true;
    const jobDept = normalizeString(job.department);
    return selected.some(dept => jobDept === normalizeString(dept));
  };

  const matchesSkills = (job) => {
    const selected = filters.skills || [];
    if (selected.length === 0) return true;
    if (!Array.isArray(job.skills)) return false;
    return selected.some(skill =>
      job.skills.some(jobSkill => normalizeString(jobSkill) === normalizeString(skill))
    );
  };

  // Labels are raw numbers (e.g. "₹15,000 - ₹25,000", "₹40,000+") — strip
  // commas/currency symbols before matching digits, and keep the same
  // no-multiplier convention as parseJobSalary below so both sides agree.
  const parseSalaryFilter = (label) => {
    const nums = String(label).replace(/,/g, "").match(/\d+/g)?.map(Number) || [];
    const min = nums[0] || 0;
    const max = label.includes("+") ? Infinity : (nums[1] || min);
    return { min, max };
  };

  const parseJobSalary = (salaryRange) => {
    const nums = String(salaryRange || "").replace(/,/g, "").match(/\d+/g)?.map(Number) || [];
    const min = nums[0] || 0;
    const max = nums[1] || min;
    return { min, max };
  };

  const salaryOverlap = (jobSal, filterSal) => jobSal.min <= filterSal.max && jobSal.max >= filterSal.min;

  const matchesSalary = (job) => {
    const selected = filters.salary || [];
    if (selected.length === 0) return true;
    const jobSal = parseJobSalary(job.salaryRange || job.salaryDisplay);
    return selected.some(label => salaryOverlap(jobSal, parseSalaryFilter(label)));
  };

  const parseExperienceFilter = (label) => {
    const nums = String(label).match(/\d+/g)?.map(Number) || [];
    if (label.toLowerCase().includes("fresher")) return { min: 0, max: 1 };
    const min = nums[0] || 0;
    const max = label.includes("+") ? Infinity : (nums[1] || min);
    return { min, max };
  };

  const parseJobExperience = (experienceDisplay) => {
    const text = String(experienceDisplay || "").toLowerCase();
    const nums = text.match(/\d+/g)?.map(Number) || [];
    if (text.includes("fresher")) return { min: 0, max: 1 };
    if (nums.length === 0) return { min: 0, max: Infinity };
    const min = nums[0];
    const max = nums[1] || min;
    return { min, max };
  };

  const experienceOverlap = (jobExp, filterExp) => jobExp.min <= filterExp.max && jobExp.max >= filterExp.min;

  const matchesExperience = (job) => {
    const selected = filters.experience || [];
    if (selected.length === 0) return true;
    const jobExp = parseJobExperience(job.experienceDisplay);
    return selected.some(label => experienceOverlap(jobExp, parseExperienceFilter(label)));
  };

  const getJobTime = (job) => (job.postedOn ? new Date(job.postedOn).getTime() : 0);
  const getJobMatch = (job) => {
    const matchScore = job.aiMatchPercentage ?? job.matchPercentage ?? job.aiMatch ?? job.aiMatchScore;
    return Number(matchScore) || 0;
  };

  // Inject calculated client-side AI match percentage if backend score is null and candidate profile is loaded
  const jobsWithAiMatch = useMemo(() => {
    return allJobs.map(job => {
      const existingMatch = job.aiMatchPercentage ?? job.matchPercentage ?? job.aiMatch ?? job.aiMatchScore;
      if (existingMatch != null) {
        return {
          ...job,
          aiMatchPercentage: existingMatch
        };
      }
      if (candidateProfile) {
        const clientAiMatch = computeClientAiMatchPercentage(job, candidateProfile);
        return {
          ...job,
          aiMatchPercentage: clientAiMatch
        };
      }
      return job;
    });
  }, [allJobs, candidateProfile]);

  // Candidate's trade category always wins first: every job in the
  // candidate's own trade (role-matches ranked above trade-only matches)
  // comes before any other trade — regardless of which Sort option or
  // filters are active. Works with an empty filters object too, so the
  // default (unfiltered) feed already reflects this.
  const getTradeMatchTier = (job) => {
    if (!candidateTrade) return 0;
    const jobTrade = normalizeString(job.tradeCategory);
    const jobRole = normalizeString(job.role || job.jobTitle);
    const tradeMatches = jobTrade === normalizeString(candidateTrade);
    if (!tradeMatches) return 0;
    const roleMatches =
      !!candidateRole && jobRole === normalizeString(candidateRole);
    return roleMatches ? 2 : 1;
  };

  // All filtering + sorting happens here, in memory, against the single
  // `allJobs` array fetched once above — no API round-trip per filter change.
  const sortedFilteredJobs = useMemo(() => {
    const filtered = jobsWithAiMatch.filter(job =>
      matchesKeyword(job) &&
      matchesLocationSingle(job) &&
      matchesCity(job) &&
      matchesState(job) &&
      matchesIndustryType(job) &&
      matchesTradeCategory(job) &&
      matchesRole(job) &&
      matchesEducation(job) &&
      matchesEmploymentType(job) &&
      matchesLocationType(job) &&
      matchesEmploymentMode(job) &&
      matchesDepartment(job) &&
      matchesSkills(job) &&
      matchesSalary(job) &&
      matchesExperience(job)
    );

    return [...filtered].sort((a, b) => {
      const tradeDiff = getTradeMatchTier(b) - getTradeMatchTier(a);
      if (tradeDiff !== 0) return tradeDiff;

      if (sortBy === 'Newest Post') return getJobTime(b) - getJobTime(a);
      if (sortBy === 'Oldest Post') return getJobTime(a) - getJobTime(b);
      if (sortBy === 'Best Match') {
        const matchA = computeCandidateMatchScore(a, candidateProfile);
        const matchB = computeCandidateMatchScore(b, candidateProfile);
        
        if (matchB !== matchA) {
          return matchB - matchA; // prioritize profile matches at the top
        }

        const aiA = getJobMatch(a);
        const aiB = getJobMatch(b);
        if (aiB !== aiA) {
          return aiB - aiA; // sort by AI Match score
        }

        return getJobTime(b) - getJobTime(a); // tie-breaker: newest first
      }
      return 0;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [jobsWithAiMatch, filters, sortBy, candidateProfile, candidateTrade, candidateRole]);

  const totalFilteredCount = sortedFilteredJobs.length;
  const totalPages = Math.max(1, Math.ceil(totalFilteredCount / showPerPage));
  const showingFrom = totalFilteredCount === 0 ? 0 : (currentPage - 1) * showPerPage + 1;
  const showingTo = totalFilteredCount === 0 ? 0 : Math.min(currentPage * showPerPage, totalFilteredCount);
  const filteredJobs = sortedFilteredJobs.slice((currentPage - 1) * showPerPage, currentPage * showPerPage);

  return (
    <div className="content-page">
      <div className="box-filters-job">
        <div className="row">
          <div className="col-xl-6 col-lg-5">
            <span className="text-small text-showing">
              Showing <strong>{showingFrom}-{showingTo} </strong>of <strong>{totalFilteredCount} </strong>jobs
            </span>
          </div>
          <div className="col-xl-6 col-lg-7 text-lg-end mt-sm-15">
            <div className="display-flex2">
              <div className="box-border mr-10">
                <span className="text-sortby">Show:</span>
                <div className="dropdown dropdown-sort">
                  <button className="btn dropdown-toggle" data-bs-toggle="dropdown">
                    <span>{showPerPage}</span><i className="fi-rr-angle-small-down"></i>
                  </button>
                  <ul className="dropdown-menu">
                    <li><a className="dropdown-item" href="#" onClick={(e) => { e.preventDefault(); setShowPerPage(10); }}>10</a></li>
                    <li><a className="dropdown-item" href="#" onClick={(e) => { e.preventDefault(); setShowPerPage(12); }}>12</a></li>
                    <li><a className="dropdown-item" href="#" onClick={(e) => { e.preventDefault(); setShowPerPage(20); }}>20</a></li>
                  </ul>
                </div>
              </div>

              <div className="box-border">
                <span className="text-sortby">Sort by:</span>
                <div className="dropdown dropdown-sort">
                  <button className="btn dropdown-toggle" data-bs-toggle="dropdown">
                    <span>{sortBy}</span><i className="fi-rr-angle-small-down"></i>
                  </button>
                  <ul className="dropdown-menu">
                    <li><a className={`dropdown-item${sortBy === 'Best Match' ? ' active' : ''}`} href="#" onClick={(e) => { e.preventDefault(); setSortBy('Best Match'); }}>Best Match</a></li>
                    <li><a className={`dropdown-item${sortBy === 'Newest Post' ? ' active' : ''}`} href="#" onClick={(e) => { e.preventDefault(); setSortBy('Newest Post'); }}>Newest Post</a></li>
                    <li><a className={`dropdown-item${sortBy === 'Oldest Post' ? ' active' : ''}`} href="#" onClick={(e) => { e.preventDefault(); setSortBy('Oldest Post'); }}>Oldest Post</a></li>
                  </ul>
                </div>
              </div>

              <div className="box-view-type">
                <a
                  className={`view-type ${viewMode === 'list' ? 'active' : ''}`}
                  href="#"
                  onClick={(e) => { e.preventDefault(); setViewMode('list'); }}
                >
                  <img
                    src="/assets/imgs/template/icons/icon-list.svg"
                    alt="List"
                    style={{ opacity: viewMode === 'list' ? 1 : 0.4 }}
                  />
                </a>
                <a
                  className={`view-type ${viewMode === 'grid' ? 'active' : ''}`}
                  href="#"
                  onClick={(e) => { e.preventDefault(); setViewMode('grid'); }}
                >
                  <img
                    src={
                      viewMode === 'grid'
                        ? "/assets/imgs/template/icons/icon-grid-hover.svg"
                        : "/assets/imgs/template/icons/icon-grid.svg"
                    }
                    alt="Grid"
                    style={{ opacity: viewMode === 'grid' ? 1 : 0.4 }}
                  />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '300px', width: '100%' }}>
          <img
            src="/assets/imgs/template/loading.gif"
            alt="Loading..."
            style={{ maxWidth: '120px', filter: 'hue-rotate(195deg)' }}
          />
        </div>
      ) : filteredJobs.length === 0 ? (
        <div className="text-center" style={{ padding: '60px 0', width: '100%' }}>
          <img src="/assets/imgs/template/icons/empty.svg" alt="No jobs" style={{ maxWidth: '120px', marginBottom: '20px', opacity: 0.6 }} onError={(e) => { e.target.style.display = 'none'; }} />
          <h4 style={{ color: 'var(--text-dark)', marginBottom: '8px' }}>No Jobs Found</h4>
          <p style={{ color: 'var(--text-muted, #7c8493)', fontSize: '15px' }}>Try adjusting your filters or search terms to find matching roles.</p>
        </div>
      ) : (
        <div className={`row display-${viewMode}`}>
          {filteredJobs.map((job) => (
            <div
              key={job.jobId}
              className={viewMode === 'grid' ? 'col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12 mb-30' : 'col-xl-12 col-12'}
              style={{ display: viewMode === 'grid' ? 'flex' : 'block' }}
            >
              <JobCardList
                job={job}
                viewMode={viewMode}
                onApplyNow={openApplyModal}
                isApplied={appliedJobIds.has(job.jobId)}
              />
            </div>
          ))}
        </div>
      )}
      {totalPages > 1 ? (
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={setCurrentPage}
          loading={loading}
        />
      ) : null}
      <ApplyJobModal
        showModal={showApplyModal}
        setShowModal={(v) => { setShowApplyModal(v); if (!v) loadAppliedJobs(); }}
        job={activeJob}
      />
    </div>
  );
};

export default JobList;