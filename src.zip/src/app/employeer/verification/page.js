"use client";

import { useEffect, useRef, useState } from "react";
import SubUserViewOnlyGuard from "@/components/SubUserViewOnlyGuard.js";
import {
  getVerification,
  uploadDocument,
  getDocumentTypes,
} from "@/services/recruiter/recruiterVerificationService";

/* ── Icon mapping (backend does not send icons) ───────────────────────────── */
const BADGE_ICONS = {
  GST: "fi fi-rr-check",
  PAN: "fi fi-rr-id-badge",
  "POE Licensed": "fi fi-rr-shield-check",
  "RPSL Licensed": "fi fi-rr-diploma",
};

/* Statuses the backend treats as "positive/done" */
const POSITIVE_STATUSES = ["Approved", "Uploaded", "Available", "Verified"];

/* ── Helpers ──────────────────────────────────────────────────────────────── */
const isPositive = (status) => POSITIVE_STATUSES.includes(status);

const badgeColors = (status) => {
  if (status === "Approved")
    return { bg: "#ecfdf3", color: "#0BAB7C" };
  if (status === "Uploaded")
    return { bg: "#eaf4ff", color: "#1d4ed8" };
  if (status === "Rejected")
    return { bg: "#fef2f2", color: "#b91c1c" };
  return { bg: "#f4f5f7", color: "#66789c" };
};

const formatDate = (value) => {
  if (!value) return "—";
  try {
    return new Date(value).toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  } catch {
    return "—";
  }
};

const EmployerVerificationPage = () => {
  const [badges, setBadges] = useState([]);
  const [documents, setDocuments] = useState([]);
  const [allDocumentTypes, setAllDocumentTypes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [uploadType, setUploadType] = useState("");
  const [uploadRequestId, setUploadRequestId] = useState(null);
  const [customDocName, setCustomDocName] = useState("");
  const [uploading, setUploading] = useState(false);
  const [uploadMsg, setUploadMsg] = useState(null);
  const fileInputRef = useRef(null);

  /* ── Load dashboard ─────────────────────────────────────────────────────── */
  const loadVerification = async () => {
    try {
      setLoading(true);
      setError(null);
      const [verificationData, docTypesData] = await Promise.all([
        getVerification(),
        getDocumentTypes()
      ]);
      setBadges(verificationData?.badges ?? []);
      const apiDocs = verificationData?.documents ?? [];
      setDocuments(apiDocs);

      const fetchedTypes = docTypesData?.data ?? [];
      setAllDocumentTypes(fetchedTypes);

      if (fetchedTypes.length > 0) {
        setUploadType((prev) => prev && (fetchedTypes.some(t => t.documentTypeId === prev) || prev === "OTHER") ? prev : fetchedTypes[0].documentTypeId);
      } else {
        setUploadType("OTHER");
      }
    } catch (err) {
      console.error("loadVerification error:", err);
      setError("Could not load verification details. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadVerification();
  }, []);

  /* ── Upload flow ────────────────────────────────────────────────────────── */
  const handleDirectUpload = (uploadTypeVal) => {
    setUploadType(uploadTypeVal);
    setUploadRequestId(null);
    setUploadMsg(null);
    fileInputRef.current?.click();
  };

  const handleRequestUpload = (uploadTypeVal, requestId) => {
    setUploadType(uploadTypeVal || "OTHER");
    setUploadRequestId(requestId);
    setUploadMsg(null);
    fileInputRef.current?.click();
  };

  const handleBrowseClick = () => {
    setUploadMsg(null);
    fileInputRef.current?.click();
  };

  const handleFileSelected = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Basic client-side guard (max 5 MB, pdf/jpg/png)
    const maxBytes = 5 * 1024 * 1024;
    const okTypes = ["application/pdf", "image/jpeg", "image/png"];
    if (file.size > maxBytes) {
      setUploadMsg({ type: "error", text: "File exceeds 5 MB limit." });
      e.target.value = "";
      return;
    }
    if (!okTypes.includes(file.type)) {
      setUploadMsg({ type: "error", text: "Only PDF, JPG, or PNG allowed." });
      e.target.value = "";
      return;
    }

    try {
      setUploading(true);
      setUploadMsg(null);
      
      if (uploadType === "OTHER") {
        await uploadDocument("OTHER", customDocName.trim() || "Other Document", file, uploadRequestId);
      } else {
        await uploadDocument(uploadType, "", file, uploadRequestId);
      }
      setUploadMsg({ type: "success", text: "Document uploaded successfully." });

      // Reflect the upload immediately rather than waiting on the refetch
      const matchedType = allDocumentTypes.find(t => t.documentTypeId === uploadType);
      const docName = uploadType === "OTHER" ? (customDocName.trim() || "Other Document") : (matchedType ? matchedType.documentName : "");
      
      const newDoc = {
        documentTypeId: uploadType !== "OTHER" ? uploadType : null,
        documentType: docName,
        status: "Uploaded",
        uploadedAt: new Date().toISOString(),
        fileUrl: null,
      };

      setDocuments((prev) => {
        const index = prev.findIndex((d) => 
          (uploadType !== "OTHER" && d.documentTypeId === uploadType) ||
          d.documentType === docName
        );
        if (index > -1) {
          const next = [...prev];
          next[index] = { ...next[index], ...newDoc };
          return next;
        } else {
          return [...prev, newDoc];
        }
      });

      if (uploadType === "OTHER") {
        setCustomDocName("");
      }
      setUploadRequestId(null);

      await loadVerification();
    } catch (err) {
      console.error("uploadDocument error:", err);
      setUploadMsg({ type: "error", text: "Upload failed. Please try again." });
    } finally {
      setUploading(false);
      e.target.value = "";
    }
  };

  const handleView = (doc) => {
    if (doc.fileUrl) {
      window.open(doc.fileUrl, "_blank", "noopener,noreferrer");
    }
  };

  const handleUploadClick = (doc) => {
    setUploadType(doc.documentTypeId || "OTHER");
    setUploadRequestId(doc.requestId || null);
    setUploadMsg(null);
    fileInputRef.current?.click();
  };

  // Grouping the documents dynamically based on the category attribute returned in verification API.
  const requiredDocsList = [];
  const requestedDocsList = [];
  const optionalDocsList = [];
  const otherDocsList = [];

  // Deduplicate and merge documents having the same requestId (admin request vs uploaded file)
  const uniqueDocsMap = new Map();
  documents.forEach((d) => {
    if (d.requestId) {
      if (uniqueDocsMap.has(d.requestId)) {
        const existing = uniqueDocsMap.get(d.requestId);
        uniqueDocsMap.set(d.requestId, {
          ...existing,
          ...d,
          category: (existing.category === "RequestedAdditional" || d.category === "RequestedAdditional") ? "RequestedAdditional" : existing.category,
          message: existing.message || d.message || "",
          fileUrl: existing.fileUrl || d.fileUrl,
          uploadedAt: existing.uploadedAt || d.uploadedAt,
          status: (existing.status && existing.status !== "Not Uploaded") ? existing.status : d.status,
          reason: existing.reason || d.reason || null,
        });
      } else {
        uniqueDocsMap.set(d.requestId, { ...d });
      }
    }
  });

  const processedDocs = [];
  documents.forEach((d) => {
    if (d.requestId) {
      if (uniqueDocsMap.has(d.requestId)) {
        processedDocs.push(uniqueDocsMap.get(d.requestId));
        uniqueDocsMap.delete(d.requestId); // add only once
      }
    } else {
      processedDocs.push(d);
    }
  });

  // Group existing documents from verification response
  processedDocs.forEach((d) => {
    if (d.category === "Mandatory") {
      requiredDocsList.push(d);
    } else if (d.category === "RequestedAdditional" || d.requestId) {
      requestedDocsList.push(d);
    } else if (d.category === "Optional") {
      optionalDocsList.push(d);
    } else {
      otherDocsList.push(d);
    }
  });

  // Supplement with placeholders from getDocumentTypes() for document types not yet represented
  allDocumentTypes.forEach((t) => {
    const isRepresented =
      requiredDocsList.some((d) => d.documentTypeId === t.documentTypeId || d.documentName === t.documentName) ||
      requestedDocsList.some((d) => d.documentTypeId === t.documentTypeId || d.documentName === t.documentName) ||
      optionalDocsList.some((d) => d.documentTypeId === t.documentTypeId || d.documentName === t.documentName);

    if (!isRepresented) {
      const placeholder = {
        documentTypeId: t.documentTypeId,
        documentName: t.documentName,
        category: t.isMandatory ? "Mandatory" : "Optional",
        status: "Not Uploaded",
        fileUrl: null,
        uploadedAt: null,
        requestId: null,
      };
      if (t.isMandatory) {
        requiredDocsList.push(placeholder);
      } else {
        optionalDocsList.push(placeholder);
      }
    }
  });

  return (
    <SubUserViewOnlyGuard>
      <main className="main">
        <section className="section-box mt-50 mb-50">
          <div className="container">
            <div className="content-page">
              {/* Header */}
              <div className="mb-30">
                <h3
                  style={{ color: "#122359", fontWeight: 800, marginBottom: "6px" }}
                >
                  Verification &amp; Badges
                </h3>
                <span className="font-sm color-text-paragraph-2">
                  Build trust with candidates — verified employers get more
                  applicants.
                </span>
              </div>

              {/* Error banner */}
              {error && (
                <div
                  style={{
                    background: "#fef2f2",
                    border: "1px solid #fca5a5",
                    color: "#b91c1c",
                    borderRadius: "14px",
                    padding: "14px 18px",
                    marginBottom: "24px",
                    fontWeight: 600,
                    fontSize: "14px",
                  }}
                >
                  {error}
                </div>
              )}

              {/* Trust Badges */}
              <div
                style={{
                  background: "#ffffff",
                  borderRadius: "24px",
                  border: "1px solid rgba(18,35,89,0.06)",
                  boxShadow: "0 4px 14px rgba(18,35,89,0.04)",
                  padding: "28px",
                  marginBottom: "30px",
                }}
              >
                <h5
                  style={{ color: "#122359", fontWeight: 800, marginBottom: "24px" }}
                >
                  Trust Badges
                </h5>

                {loading ? (
                  <p style={{ color: "#66789c", margin: 0 }}>Loading badges…</p>
                ) : badges.length === 0 ? (
                  <p style={{ color: "#66789c", margin: 0 }}>
                    No badges available yet.
                  </p>
                ) : (
                  <div className="row">
                    {badges.map((item) => {
                      const colors = badgeColors(item.status);
                      return (
                        <div
                          className="col-lg-4 col-md-6 col-12 mb-20"
                          key={item.badgeName}
                        >
                          <div
                            style={{
                              borderRadius: "22px",
                              padding: "22px",
                              border: "1px solid rgba(18,35,89,0.08)",
                              background: "#ffffff",
                              transition: "all .35s ease",
                              boxShadow: "0 4px 14px rgba(18,35,89,0.04)",
                              height: "100%",
                            }}
                            onMouseEnter={(e) => {
                              e.currentTarget.style.transform = "translateY(-8px)";
                              e.currentTarget.style.borderColor =
                                "rgba(255,153,0,0.32)";
                              e.currentTarget.style.boxShadow =
                                "0 0 0 1px rgba(255,153,0,0.18), 0 20px 40px rgba(255,153,0,0.12)";
                            }}
                            onMouseLeave={(e) => {
                              e.currentTarget.style.transform = "translateY(0px)";
                              e.currentTarget.style.borderColor =
                                "rgba(18,35,89,0.08)";
                              e.currentTarget.style.boxShadow =
                                "0 4px 14px rgba(18,35,89,0.04)";
                            }}
                          >
                            <div
                              style={{
                                display: "flex",
                                alignItems: "flex-start",
                                gap: "14px",
                                marginBottom: "16px",
                              }}
                            >
                              <div
                                style={{
                                  width: "52px",
                                  height: "52px",
                                  borderRadius: "16px",
                                  background: "#fff7ea",
                                  display: "flex",
                                  alignItems: "center",
                                  justifyContent: "center",
                                  color: "#ff9900",
                                  fontSize: "20px",
                                  flexShrink: 0,
                                }}
                              >
                                <i
                                  className={
                                    BADGE_ICONS[item.badgeName] ||
                                    "fi fi-rr-badge"
                                  }
                                />
                              </div>

                              <div style={{ flex: 1 }}>
                                <div
                                  style={{
                                    fontWeight: 700,
                                    color: "#122359",
                                    marginBottom: "8px",
                                    fontSize: "16px",
                                  }}
                                >
                                  {item.badgeName}
                                </div>

                                <span
                                  style={{
                                    display: "inline-flex",
                                    alignItems: "center",
                                    padding: "6px 12px",
                                    borderRadius: "999px",
                                    background: colors.bg,
                                    color: colors.color,
                                    fontSize: "11px",
                                    fontWeight: 700,
                                  }}
                                >
                                  {item.status}
                                </span>
                              </div>
                            </div>

                            <p
                              style={{
                                margin: 0,
                                color: "#66789c",
                                fontSize: "13px",
                                lineHeight: 1.7,
                              }}
                            >
                              {item.description}
                            </p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Uploaded Documents */}
              <div
                style={{
                  background: "#ffffff",
                  borderRadius: "24px",
                  border: "1px solid rgba(18,35,89,0.06)",
                  boxShadow: "0 4px 14px rgba(18,35,89,0.04)",
                  padding: "28px",
                  marginBottom: "30px",
                }}
              >
                <h5
                  style={{
                    margin: "0 0 24px",
                    color: "#122359",
                    fontWeight: 800,
                  }}
                >
                  Verification Documents
                </h5>

                {loading ? (
                  <p style={{ color: "#66789c", margin: 0 }}>Loading documents…</p>
                ) : (
                  <div>
                    {/* Required Documents */}
                    {requiredDocsList.length > 0 && (
                      <div style={{ marginBottom: "24px" }}>
                        <h6
                          style={{
                            color: "#122359",
                            fontWeight: 700,
                            marginBottom: "14px",
                            fontSize: "15px",
                          }}
                        >
                          Required Documents
                        </h6>
                        <div
                          style={{
                            display: "flex",
                            flexDirection: "column",
                            gap: "14px",
                          }}
                        >
                          {requiredDocsList.map((doc) => {
                            const positive = isPositive(doc.status);
                            const hasFile = !!doc.fileUrl;

                            return (
                              <div
                                key={doc.documentTypeId || doc.documentName}
                                style={{
                                  display: "flex",
                                  alignItems: "center",
                                  justifyContent: "space-between",
                                  flexWrap: "wrap",
                                  gap: "14px",
                                  padding: "18px 22px",
                                  borderRadius: "18px",
                                  border: "1px solid rgba(18,35,89,0.08)",
                                  background: "#ffffff",
                                  transition: "all .35s ease",
                                }}
                                onMouseEnter={(e) => {
                                  e.currentTarget.style.transform = "translateY(-4px)";
                                  e.currentTarget.style.borderColor = "rgba(255,153,0,0.32)";
                                  e.currentTarget.style.boxShadow = "0 12px 28px rgba(255,163,0,0.10)";
                                }}
                                onMouseLeave={(e) => {
                                  e.currentTarget.style.transform = "translateY(0px)";
                                  e.currentTarget.style.borderColor = "rgba(18,35,89,0.08)";
                                  e.currentTarget.style.boxShadow = "none";
                                }}
                              >
                                <div>
                                  <div
                                    style={{
                                      fontWeight: 700,
                                      color: "#122359",
                                      marginBottom: "4px",
                                    }}
                                  >
                                    {doc.documentName}
                                    <span
                                      style={{
                                        marginLeft: "8px",
                                        fontSize: "9px",
                                        color: "#b91c1c",
                                        background: "#fef2f2",
                                        border: "1px solid #fca5a5",
                                        padding: "2px 6px",
                                        borderRadius: "6px",
                                        fontWeight: 700,
                                        textTransform: "uppercase",
                                      }}
                                    >
                                      Required
                                    </span>
                                  </div>
                                  {doc.status === "Rejected" && doc.reason && (
                                    <div
                                      style={{
                                        fontSize: "13px",
                                        color: "#66789c",
                                        marginBottom: "6px",
                                      }}
                                    >
                                      Reason: {doc.reason}
                                    </div>
                                  )}
                                  <div style={{ fontSize: "13px", color: "#66789c" }}>
                                    {doc.uploadedAt
                                      ? `Updated: ${formatDate(doc.uploadedAt)}`
                                      : "Not uploaded yet"}
                                  </div>
                                </div>

                                <div
                                  style={{
                                    display: "flex",
                                    alignItems: "center",
                                    gap: "10px",
                                  }}
                                >
                                  <span
                                    style={{
                                      display: "inline-flex",
                                      alignItems: "center",
                                      padding: "6px 12px",
                                      borderRadius: "999px",
                                      background: doc.status === "Rejected" ? "#fef2f2" : positive ? "#ecfdf3" : "#fff7ea",
                                      color: doc.status === "Rejected" ? "#b91c1c" : positive ? "#0BAB7C" : "#ff9900",
                                      fontSize: "11px",
                                      fontWeight: 700,
                                    }}
                                  >
                                    {doc.status}
                                  </span>

                                  {hasFile ? (
                                    <button
                                      className="btn btn-border btn-sm"
                                      style={{
                                        borderRadius: "10px",
                                        fontWeight: 700,
                                        cursor: "pointer",
                                      }}
                                      type="button"
                                      onClick={() => handleView(doc)}
                                    >
                                      <i
                                        className="fi fi-rr-eye"
                                        style={{ marginRight: "5px" }}
                                      />
                                      View
                                    </button>
                                  ) : (
                                    <button
                                      className="btn btn-default btn-sm"
                                      style={{
                                        borderRadius: "10px",
                                        fontWeight: 700,
                                        cursor: uploading ? "wait" : "pointer",
                                        background: "#ff9900",
                                        borderColor: "#ff9900",
                                        color: "#ffffff",
                                        padding: "8px 14px",
                                      }}
                                      type="button"
                                      disabled={uploading}
                                      onClick={() => handleUploadClick(doc)}
                                    >
                                      <i
                                        className="fi fi-rr-upload"
                                        style={{ marginRight: "5px" }}
                                      />
                                      {uploading && uploadType === doc.documentTypeId && uploadRequestId === doc.requestId ? "Uploading…" : "Upload"}
                                    </button>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* Additional Requested Documents */}
                    {requestedDocsList.length > 0 && (
                      <div style={{ marginBottom: "24px", marginTop: "24px" }}>
                        <h6
                          style={{
                            color: "#122359",
                            fontWeight: 700,
                            marginBottom: "14px",
                            fontSize: "15px",
                          }}
                        >
                          Additional Requested Documents
                        </h6>
                        <div
                          style={{
                            display: "flex",
                            flexDirection: "column",
                            gap: "14px",
                          }}
                        >
                          {requestedDocsList.map((doc) => {
                            const positive = isPositive(doc.status);
                            const hasFile = !!doc.fileUrl;

                            return (
                              <div
                                key={doc.requestId || doc.documentTypeId || doc.documentName}
                                style={{
                                  display: "flex",
                                  alignItems: "center",
                                  justifyContent: "space-between",
                                  flexWrap: "wrap",
                                  gap: "14px",
                                  padding: "18px 22px",
                                  borderRadius: "18px",
                                  border: "1px solid rgba(18,35,89,0.08)",
                                  background: "#ffffff",
                                  transition: "all .35s ease",
                                }}
                                onMouseEnter={(e) => {
                                  e.currentTarget.style.transform = "translateY(-4px)";
                                  e.currentTarget.style.borderColor = "rgba(255,153,0,0.32)";
                                  e.currentTarget.style.boxShadow = "0 12px 28px rgba(255,163,0,0.10)";
                                }}
                                onMouseLeave={(e) => {
                                  e.currentTarget.style.transform = "translateY(0px)";
                                  e.currentTarget.style.borderColor = "rgba(18,35,89,0.08)";
                                  e.currentTarget.style.boxShadow = "none";
                                }}
                              >
                                <div>
                                  <div
                                    style={{
                                      fontWeight: 700,
                                      color: "#122359",
                                      marginBottom: "4px",
                                    }}
                                  >
                                    {doc.documentName || doc.documentType}
                                  </div>
                                  {doc.message && (
                                    <div
                                      style={{
                                        fontSize: "13px",
                                        color: "#66789c",
                                        marginBottom: "6px",
                                      }}
                                    >
                                      {doc.message}
                                    </div>
                                  )}
                                  {doc.status === "Rejected" && doc.reason && (
                                    <div
                                      style={{
                                        fontSize: "13px",
                                        color: "#66789c",
                                        marginBottom: "6px",
                                      }}
                                    >
                                      Reason: {doc.reason}
                                    </div>
                                  )}
                                  <div style={{ fontSize: "13px", color: "#66789c" }}>
                                    {doc.uploadedAt
                                      ? `Updated: ${formatDate(doc.uploadedAt)}`
                                      : "Requested by Admin"}
                                  </div>
                                </div>

                                <div
                                  style={{
                                    display: "flex",
                                    alignItems: "center",
                                    gap: "10px",
                                  }}
                                >
                                  <span
                                    style={{
                                      display: "inline-flex",
                                      alignItems: "center",
                                      padding: "6px 12px",
                                      borderRadius: "999px",
                                      background: doc.status === "Rejected" ? "#fef2f2" : positive ? "#ecfdf3" : "#fff7ea",
                                      color: doc.status === "Rejected" ? "#b91c1c" : positive ? "#0BAB7C" : "#ff9900",
                                      fontSize: "11px",
                                      fontWeight: 700,
                                    }}
                                  >
                                    {doc.status}
                                  </span>

                                  {hasFile ? (
                                    <button
                                      className="btn btn-border btn-sm"
                                      style={{
                                        borderRadius: "10px",
                                        fontWeight: 700,
                                        cursor: "pointer",
                                      }}
                                      type="button"
                                      onClick={() => handleView(doc)}
                                    >
                                      <i
                                        className="fi fi-rr-eye"
                                        style={{ marginRight: "5px" }}
                                      />
                                      View
                                    </button>
                                  ) : (
                                    <button
                                      className="btn btn-default btn-sm"
                                      style={{
                                        borderRadius: "10px",
                                        fontWeight: 700,
                                        cursor: uploading ? "wait" : "pointer",
                                        background: "#ff9900",
                                        borderColor: "#ff9900",
                                        color: "#ffffff",
                                        padding: "8px 14px",
                                      }}
                                      type="button"
                                      disabled={uploading}
                                      onClick={() => handleUploadClick(doc)}
                                    >
                                      <i
                                        className="fi fi-rr-upload"
                                        style={{ marginRight: "5px" }}
                                      />
                                      {uploading && uploadType === doc.documentTypeId && uploadRequestId === doc.requestId ? "Uploading…" : "Upload"}
                                    </button>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* Optional Documents */}
                    {optionalDocsList.length > 0 && (
                      <div style={{ marginBottom: "24px", marginTop: "24px" }}>
                        <h6
                          style={{
                            color: "#122359",
                            fontWeight: 700,
                            marginBottom: "14px",
                            fontSize: "15px",
                          }}
                        >
                          Optional Documents
                        </h6>
                        <div
                          style={{
                            display: "flex",
                            flexDirection: "column",
                            gap: "14px",
                          }}
                        >
                          {optionalDocsList.map((doc) => {
                            const positive = isPositive(doc.status);
                            const hasFile = !!doc.fileUrl;

                            return (
                              <div
                                key={doc.documentTypeId || doc.documentName}
                                style={{
                                  display: "flex",
                                  alignItems: "center",
                                  justifyContent: "space-between",
                                  flexWrap: "wrap",
                                  gap: "14px",
                                  padding: "18px 22px",
                                  borderRadius: "18px",
                                  border: "1px solid rgba(18,35,89,0.08)",
                                  background: "#ffffff",
                                  transition: "all .35s ease",
                                }}
                                onMouseEnter={(e) => {
                                  e.currentTarget.style.transform = "translateY(-4px)";
                                  e.currentTarget.style.borderColor = "rgba(255,153,0,0.32)";
                                  e.currentTarget.style.boxShadow = "0 12px 28px rgba(255,163,0,0.10)";
                                }}
                                onMouseLeave={(e) => {
                                  e.currentTarget.style.transform = "translateY(0px)";
                                  e.currentTarget.style.borderColor = "rgba(18,35,89,0.08)";
                                  e.currentTarget.style.boxShadow = "none";
                                }}
                              >
                                <div>
                                  <div
                                    style={{
                                      fontWeight: 700,
                                      color: "#122359",
                                      marginBottom: "4px",
                                    }}
                                  >
                                    {doc.documentName}
                                  </div>
                                  {doc.status === "Rejected" && doc.reason && (
                                    <div
                                      style={{
                                        fontSize: "13px",
                                        color: "#66789c",
                                        marginBottom: "6px",
                                      }}
                                    >
                                      Reason: {doc.reason}
                                    </div>
                                  )}
                                  <div style={{ fontSize: "13px", color: "#66789c" }}>
                                    {doc.uploadedAt
                                      ? `Updated: ${formatDate(doc.uploadedAt)}`
                                      : "Not uploaded yet"}
                                  </div>
                                </div>

                                <div
                                  style={{
                                    display: "flex",
                                    alignItems: "center",
                                    gap: "10px",
                                  }}
                                >
                                  <span
                                    style={{
                                      display: "inline-flex",
                                      alignItems: "center",
                                      padding: "6px 12px",
                                      borderRadius: "999px",
                                      background: doc.status === "Rejected" ? "#fef2f2" : positive ? "#ecfdf3" : "#fff7ea",
                                      color: doc.status === "Rejected" ? "#b91c1c" : positive ? "#0BAB7C" : "#ff9900",
                                      fontSize: "11px",
                                      fontWeight: 700,
                                    }}
                                  >
                                    {doc.status}
                                  </span>

                                  {hasFile ? (
                                    <button
                                      className="btn btn-border btn-sm"
                                      style={{
                                        borderRadius: "10px",
                                        fontWeight: 700,
                                        cursor: "pointer",
                                      }}
                                      type="button"
                                      onClick={() => handleView(doc)}
                                    >
                                      <i
                                        className="fi fi-rr-eye"
                                        style={{ marginRight: "5px" }}
                                      />
                                      View
                                    </button>
                                  ) : (
                                    <button
                                      className="btn btn-default btn-sm"
                                      style={{
                                        borderRadius: "10px",
                                        fontWeight: 700,
                                        cursor: uploading ? "wait" : "pointer",
                                        background: "#ff9900",
                                        borderColor: "#ff9900",
                                        color: "#ffffff",
                                        padding: "8px 14px",
                                      }}
                                      type="button"
                                      disabled={uploading}
                                      onClick={() => handleUploadClick(doc)}
                                    >
                                      <i
                                        className="fi fi-rr-upload"
                                        style={{ marginRight: "5px" }}
                                      />
                                      {uploading && uploadType === doc.documentTypeId && uploadRequestId === doc.requestId ? "Uploading…" : "Upload"}
                                    </button>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* Other Uploaded Documents */}
                    {otherDocsList.length > 0 && (
                      <div style={{ marginTop: "24px" }}>
                        <h6
                          style={{
                            color: "#122359",
                            fontWeight: 700,
                            marginBottom: "14px",
                            fontSize: "15px",
                          }}
                        >
                          Other Uploaded Documents
                        </h6>
                        <div
                          style={{
                            display: "flex",
                            flexDirection: "column",
                            gap: "14px",
                          }}
                        >
                          {otherDocsList.map((doc) => {
                            const positive = isPositive(doc.status);
                            return (
                              <div
                                key={doc.documentTypeId || doc.documentType}
                                style={{
                                  display: "flex",
                                  alignItems: "center",
                                  justifyContent: "space-between",
                                  flexWrap: "wrap",
                                  gap: "14px",
                                  padding: "18px 22px",
                                  borderRadius: "18px",
                                  border: "1px solid rgba(18,35,89,0.08)",
                                  background: "#ffffff",
                                  transition: "all .35s ease",
                                }}
                                onMouseEnter={(e) => {
                                  e.currentTarget.style.transform = "translateY(-4px)";
                                  e.currentTarget.style.borderColor = "rgba(255,153,0,0.32)";
                                  e.currentTarget.style.boxShadow = "0 12px 28px rgba(255,163,0,0.10)";
                                }}
                                onMouseLeave={(e) => {
                                  e.currentTarget.style.transform = "translateY(0px)";
                                  e.currentTarget.style.borderColor = "rgba(18,35,89,0.08)";
                                  e.currentTarget.style.boxShadow = "none";
                                }}
                              >
                                <div>
                                  <div
                                    style={{
                                      fontWeight: 700,
                                      color: "#122359",
                                      marginBottom: "4px",
                                    }}
                                  >
                                    {doc.documentType || doc.documentName}
                                  </div>
                                  {doc.status === "Rejected" && doc.reason && (
                                    <div
                                      style={{
                                        fontSize: "13px",
                                        color: "#66789c",
                                        marginBottom: "6px",
                                      }}
                                    >
                                      Reason: {doc.reason}
                                    </div>
                                  )}
                                  <div style={{ fontSize: "13px", color: "#66789c" }}>
                                    {doc.uploadedAt
                                      ? `Updated: ${formatDate(doc.uploadedAt)}`
                                      : "Not uploaded yet"}
                                  </div>
                                </div>

                                <div
                                  style={{
                                    display: "flex",
                                    alignItems: "center",
                                    gap: "10px",
                                  }}
                                >
                                  <span
                                    style={{
                                      display: "inline-flex",
                                      alignItems: "center",
                                      padding: "6px 12px",
                                      borderRadius: "999px",
                                      background: doc.status === "Rejected" ? "#fef2f2" : positive ? "#ecfdf3" : "#fff7ea",
                                      color: doc.status === "Rejected" ? "#b91c1c" : positive ? "#0BAB7C" : "#ff9900",
                                      fontSize: "11px",
                                      fontWeight: 700,
                                    }}
                                  >
                                    {doc.status}
                                  </span>

                                  {doc.fileUrl && (
                                    <button
                                      className="btn btn-border btn-sm"
                                      style={{
                                        borderRadius: "10px",
                                        fontWeight: 700,
                                        cursor: "pointer",
                                      }}
                                      type="button"
                                      onClick={() => handleView(doc)}
                                    >
                                      <i
                                        className="fi fi-rr-eye"
                                        style={{ marginRight: "5px" }}
                                      />
                                      View
                                    </button>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Upload Area */}
              <div
                style={{
                  background: "#ffffff",
                  borderRadius: "24px",
                  border: "1px solid rgba(18,35,89,0.06)",
                  boxShadow: "0 4px 14px rgba(18,35,89,0.04)",
                  padding: "28px",
                }}
              >
                <h5
                  style={{ color: "#122359", fontWeight: 800, marginBottom: "22px" }}
                >
                  Upload New Document
                </h5>

                {/* Document type selector */}
                <div style={{ marginBottom: "18px", maxWidth: "320px" }}>
                  <label
                    style={{
                      display: "block",
                      fontSize: "13px",
                      fontWeight: 700,
                      color: "#122359",
                      marginBottom: "8px",
                    }}
                  >
                    Document type
                  </label>
                  <div style={{ position: "relative" }}>
                    <select
                      value={uploadType}
                      onChange={(e) => setUploadType(e.target.value)}
                      className="form-control"
                      style={{
                        borderRadius: "12px",
                        border: "1px solid rgba(18,35,89,0.15)",
                        padding: "10px 40px 10px 14px",
                        fontWeight: 600,
                        color: "#122359",
                        width: "100%",
                        appearance: "none",
                        WebkitAppearance: "none",
                        MozAppearance: "none",
                      }}
                    >
                      {allDocumentTypes.map((t) => (
                        <option key={t.documentTypeId} value={t.documentTypeId}>
                          {t.documentName}
                        </option>
                      ))}
                      <option value="OTHER">Other</option>
                    </select>
                    <i
                      className="fi-rr-angle-small-down"
                      style={{
                        position: "absolute",
                        right: "14px",
                        top: "50%",
                        transform: "translateY(-50%)",
                        color: "#122359",
                        fontSize: "16px",
                        pointerEvents: "none",
                      }}
                    />
                  </div>
                </div>

                {/* Conditional Document Name Input */}
                {uploadType === "OTHER" && (
                  <div style={{ marginBottom: "18px", maxWidth: "320px" }}>
                    <label
                      style={{
                        display: "block",
                        fontSize: "13px",
                        fontWeight: 700,
                        color: "#122359",
                        marginBottom: "8px",
                      }}
                    >
                      Document name
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Enter document name"
                      value={customDocName}
                      onChange={(e) => setCustomDocName(e.target.value)}
                      style={{
                        borderRadius: "12px",
                        border: "1px solid rgba(18,35,89,0.15)",
                        padding: "10px 14px",
                        fontWeight: 600,
                        color: "#122359",
                        width: "100%",
                      }}
                    />
                  </div>
                )}

                {/* Hidden file input */}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".pdf,.jpg,.jpeg,.png"
                  style={{ display: "none" }}
                  onChange={handleFileSelected}
                />

                <div
                  style={{
                    border: "2px dashed rgba(255,163,0,0.35)",
                    borderRadius: "24px",
                    padding: "50px 30px",
                    textAlign: "center",
                    background: "#fffdf9",
                    cursor: uploading ? "wait" : "pointer",
                    transition: "all .35s ease",
                  }}
                  onClick={uploading ? undefined : handleBrowseClick}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.borderColor = "#ffa300";
                    e.currentTarget.style.background = "#fff7ea";
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.borderColor = "rgba(255,163,0,0.35)";
                    e.currentTarget.style.background = "#fffdf9";
                  }}
                >
                  <div
                    style={{
                      width: "72px",
                      height: "72px",
                      borderRadius: "22px",
                      background: "#fff7ea",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      margin: "0 auto 18px",
                      color: "#ff9900",
                      fontSize: "28px",
                    }}
                  >
                    <i className="fi fi-rr-cloud-upload" />
                  </div>

                  <p
                    style={{
                      fontSize: "15px",
                      color: "#122359",
                      fontWeight: 700,
                      marginBottom: "8px",
                    }}
                  >
                    {uploading ? "Uploading…" : "Click to select a document"}
                  </p>

                  <p
                    style={{
                      fontSize: "13px",
                      color: "#66789c",
                      marginBottom: "20px",
                    }}
                  >
                    Accepted: PDF, JPG, PNG — Max 5 MB
                  </p>

                  <div
                    style={{
                      display: "inline-flex",
                      alignItems: "center",
                      gap: "8px",
                      padding: "8px 12px",
                      borderRadius: "12px",
                      background: "#fff7ea",
                      border: "1px solid rgba(255,163,0,0.28)",
                      color: "#8a5a00",
                      fontSize: "12px",
                      fontWeight: 600,
                      marginBottom: "18px",
                    }}
                  >
                    <i className="fi fi-rr-lock" />
                    Documents uploaded here are private and are not shared with
                    candidates.
                  </div>

                  <div>
                    <button
                      className="btn btn-border btn-sm"
                      style={{
                        borderRadius: "12px",
                        padding: "10px 18px",
                        fontWeight: 700,
                      }}
                      type="button"
                      disabled={uploading}
                    >
                      {uploading ? "Please wait…" : "Browse Files"}
                    </button>
                  </div>
                </div>

                {/* Upload status message */}
                {uploadMsg && (
                  <p
                    style={{
                      marginTop: "16px",
                      marginBottom: 0,
                      fontWeight: 600,
                      fontSize: "14px",
                      color:
                        uploadMsg.type === "success" ? "#0BAB7C" : "#b91c1c",
                    }}
                  >
                    {uploadMsg.text}
                  </p>
                )}
              </div>
            </div>
          </div>
        </section>
      </main>
    </SubUserViewOnlyGuard>
  );
};

export default EmployerVerificationPage;