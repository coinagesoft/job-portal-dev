'use client';
import React from 'react';

const Newsletter = () => {
  return (
    <section className="section-box mt-50 mb-20">
      <div className="container">
        <div
          className="box-newsletter"
          style={{
            background: 'linear-gradient(135deg, #ff9900 0%, #ffb733 60%, #ffa300 100%)',
            boxShadow: '0 20px 60px rgba(255,153,0,0.28)',
          }}
        >
          <div className="row">
            <div className="col-xl-3 col-12 text-center d-none d-xl-block">
              <img src="/assets/imgs/template/newsletter-left.png" alt="jobBox" />
            </div>
            <div className="col-lg-12 col-xl-6 col-12">
              <h2 className="text-md-newsletter text-center">
                New Things Will Always<br /> Update Regularly
              </h2>
              <div className="box-form-newsletter mt-40">
                <form className="form-newsletter">
                  <input
                    className="input-newsletter"
                    type="text"
                    placeholder="Enter your email here"
                  />
                  <button className="btn btn-default font-heading icon-send-letter">
                    Subscribe
                  </button>
                </form>
              </div>
            </div>
            <div className="col-xl-3 col-12 text-center d-none d-xl-block">
              <img src="/assets/imgs/template/newsletter-right.png" alt="jobBox" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Newsletter;