"use client";
import { useState, useRef, Suspense, useEffect, useMemo } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import Script from "next/script";
import { useToast } from "@/components/Toast";
import { Country, State, City } from "country-state-city";
import {
  CountrySelector,
  DialCodePreview,
  defaultCountries,
  parseCountry,
} from "react-international-phone";
import "react-international-phone/style.css";
import {
  registerCandidate,
  sendOtp,
  verifyOtp,
  createCandidateOrder,
  createCandidatePayPalOrder,
  captureCandidatePayPal,
  googleLogin,
  linkedInLogin,
  validateCandidateCoupon,
  getCandidatePlan,
} from "@/services/candidate/candidateAuthService";
import {
  registerWithGoogle,
  registerWithLinkedIn,
  verifyWithGoogle,
  verifyWithLinkedIn
} from "@/services/candidate/registrationService";
import {
  gstCheck,
  saveCompanyDetails,
  saveContactDetails,
  sendMobileOtp,
  verifyMobileOtp,
  resendMobileOtp,
  sendEmailOtp,
  verifyEmailOtp,
  resendEmailOtp,
  getDocumentTypes,
  uploadDocuments,
  submitRegistration,
  resumeRegistration,
  getRecruiterPlan,
  createMembershipOrder,
  getPaymentRegion,
  createPayPalMembershipOrder,
  capturePayPalMembership,
  getIndustries,
  submitIndustrySuggestion,
} from "@/services/recruiter/recruiterRegistrationService";
import { sendOtp as sendLoginOtp } from "@/services/recruiter/authService";
import { getHomepageData } from "@/services/candidate/homepageService";
// ─────────────────────────────────────────────
// Shared helpers
// ─────────────────────────────────────────────
// Built from react-international-phone's full country dataset (~218
// countries) instead of a hand-picked list of 4. Expected digit-length is
// derived from each country's format mask (each "." is one digit) so
// validation still works per-country without hardcoding it.
const PHONE_COUNTRIES = defaultCountries.map((c) => {
  const parsed = parseCountry(c);
  const masks =
    typeof parsed.format === "string"
      ? [parsed.format]
      : parsed.format && typeof parsed.format === "object"
        ? Object.values(parsed.format)
        : [];
  const dotCounts = masks
    .map((m) => (typeof m === "string" ? (m.match(/\./g) || []).length : 0))
    .filter((n) => n > 0);
  return {
    iso2: parsed.iso2,
    name: parsed.name,
    code: `+${parsed.dialCode}`,
    dialCode: parsed.dialCode,
    minLen: dotCounts.length ? Math.min(...dotCounts) : 6,
    maxLen: dotCounts.length ? Math.max(...dotCounts) : 14,
  };
});

const INDUSTRIES = [
  "Recruitment agency",
  "Construction & Infrastructure",
  "Marine & Shipping",
  "Oil & Gas",
  "Manufacturing",
  "Logistics & Transportation",
  "Warehousing & Supply Chain",
  "Hospitality & Facilities",
  "Ports & Terminals",
  "Mining",
  "Aviation",
  "Renewable Energy",
  "Engineering Services",
  "Healthcare",
  "IT & Technology",
  "Retail",
  "Other",
];

const BUSINESS_TYPES = [
  { value: "Private_Ltd", label: "Private Limited" },
  { value: "Public_Ltd", label: "Public Limited" },
  { value: "LLP", label: "Limited Liability Partnership (LLP)" },
  { value: "Partnership", label: "Partnership" },
  { value: "Proprietorship", label: "Sole Proprietorship" },
  { value: "OPC", label: "One Person Company (OPC)" },
  { value: "Section8", label: "Section 8 Company (Non-Profit)" },
  { value: "Trust", label: "Trust" },
  { value: "Society", label: "Society" },
  { value: "Cooperative", label: "Cooperative Society" },
  { value: "PSU", label: "Public Sector Undertaking (PSU)" },
  { value: "Government", label: "Government Entity" },
  { value: "Branch_Office", label: "Branch Office" },
  { value: "Liaison_Office", label: "Liaison Office" },
  { value: "Joint_Venture", label: "Joint Venture" },
  { value: "Other", label: "Other" },
];

// Drives which licence uploads are shown as required on the Licences step.
// "RecruitmentAgency" always needs the recruitment license on top of the
// incorporation certificate every company needs; the international
// placement question (and its POE/RPSL requirement) applies to both.
const NATURE_OF_COMPANY_OPTIONS = [
  { value: "RecruitmentAgency", label: "Recruitment Agency" },
  { value: "Employer", label: "Employer" },
];

// Document names must match exactly what Admin has configured under
// Admin > Recruiters > Document Types, since matching happens by name
// (see requiredDocumentNames in EmployerForm).
const DOC_NAME_INCORPORATION = "Certificate of Incorporation";
const DOC_NAME_RECRUITMENT_LICENSE = "Recruitment License";
const DOC_NAME_POE_LICENSE = "POE License";
const DOC_NAME_RPSL_LICENSE = "RPSL License";
const DOC_NAME_REGISTRATION_CERTIFICATE = "Registration Certificate";

// Licence rule by company location (Step 2):
//   Onshore + country outside India -> POE License is REQUIRED, RPSL not applicable
//   Offshore                        -> RPSL License OR Registration Certificate
//                                      is REQUIRED, POE not applicable
//   Onshore + India                 -> neither is required (both optional)
// "country" defaults to India when empty, same as the API does on save.
const getLicenceRule = (companyLocationType, country) => {
  const locationType = (companyLocationType || "").trim().toLowerCase();
  const isIndia = ((country || "India").trim().toLowerCase()) === "india";
  if (locationType === "offshore") return "offshore";
  if (locationType === "onshore" && !isIndia) return "onshoreAbroad";
  return "default";
};

const COMPANY_SIZES = [
  { value: "Size_1_10", label: "1-10 employees" },
  { value: "Size_11_50", label: "11-50 employees" },
  { value: "Size_51_200", label: "51-200 employees" },
  { value: "Size_201_500", label: "201-500 employees" },
  { value: "Size_500_Plus", label: "500+ employees" },
];

const COMPANY_TYPES = [
  { value: "startup", label: "Startup" },
  { value: "mid-size", label: "Mid-size" },
  { value: "enterprise", label: "Enterprise" },
  { value: "government", label: "Government" },
  { value: "non-profit", label: "Non-profit" },
  { value: "product-based", label: "Product-based" },
  { value: "service-based", label: "Service-based" },
  { value: "consulting", label: "Consulting" },
  { value: "manufacturing", label: "Manufacturing" },
  { value: "trading-distribution", label: "Trading / Distribution" },
  { value: "agency", label: "Agency" },
  { value: "outsourcing-bpo", label: "Outsourcing / BPO" },
];

const labelFor = (list, value) =>
  list.find((o) => o.value === value)?.label || value;

const GSTIN_REGEX = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[A-Z0-9]{1}[Z]{1}[A-Z0-9]{1}$/;
const PIN_REGEX = /^[0-9]{6}$/;

// Full country list for the Registered Address section — replaces the old
// India-only STATES constant. State and City options now cascade from
// whichever country/state the employer actually picks, instead of always
// assuming India.
const ALL_COUNTRIES = Country.getAllCountries();
const COUNTRY_NAMES = ALL_COUNTRIES.map((c) => c.name);

const getCountryIso = (countryName) =>
  ALL_COUNTRIES.find((c) => c.name === countryName)?.isoCode || "";

const getStateNamesForCountry = (countryIso) =>
  countryIso ? State.getStatesOfCountry(countryIso).map((s) => s.name) : [];

const getStateIso = (countryIso, stateName) =>
  countryIso
    ? State.getStatesOfCountry(countryIso).find((s) => s.name === stateName)
      ?.isoCode || ""
    : "";

const getCityNamesForState = (countryIso, stateIso) =>
  countryIso && stateIso
    ? City.getCitiesOfState(countryIso, stateIso).map((c) => c.name)
    : [];

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const isValidEmail = (email) => EMAIL_REGEX.test(email.trim());

const getCountryMeta = (code) =>
  PHONE_COUNTRIES.find((c) => c.code === code) ||
  PHONE_COUNTRIES.find((c) => c.code === "+91") ||
  PHONE_COUNTRIES[0];

const isValidMobile = (mobile, countryCode) => {
  const digits = mobile.replace(/\D/g, "");
  const meta = getCountryMeta(countryCode);
  return digits.length >= meta.minLen && digits.length <= meta.maxLen;
};

const TOTAL_EMP_STEPS = 5;
const EMPLOYER_UI_PREVIEW_MODE = false;
// ─────────────────────────────────────────────
// Sub-components
// ─────────────────────────────────────────────

function StepBar({ current, total, labels }) {
  return (
    <div style={{ display: "flex", alignItems: "center", marginBottom: 28 }}>
      {Array.from({ length: total }).map((_, i) => {
        const n = i + 1;
        const done = n < current;
        const active = n === current;
        return (
          <div
            key={n}
            style={{
              display: "flex",
              alignItems: "center",
              flex: i < total - 1 ? 1 : undefined,
            }}
          >
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: 4,
              }}
            >
              <div
                style={{
                  width: 28,
                  height: 28,
                  borderRadius: "50%",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: "var(--font-xs)",
                  fontWeight: 600,
                  flexShrink: 0,
                  background: done
                    ? "#ff9900"
                    : active
                      ? "#ff9900"
                      : "var(--color-background-secondary)",
                  color: done || active ? "#fff" : "var(--color-text-tertiary)",
                  border: active ? "3px solid #ffc151" : "none",
                  boxSizing: "border-box",
                }}
              >
                {done ? "✓" : n}
              </div>
              {labels && (
                <span
                  style={{
                    fontSize: "var(--font-xxs)",
                    color: active ? "#ff9900" : "var(--color-text-tertiary)",
                    whiteSpace: "nowrap",
                    fontWeight: active ? 600 : 400,
                  }}
                >
                  {labels[i]}
                </span>
              )}
            </div>
            {i < total - 1 && (
              <div
                style={{
                  flex: 1,
                  height: 2,
                  margin: "0 4px",
                  marginBottom: labels ? 20 : 0,
                  background: done ? "#ff9900" : "var(--color-border-tertiary)",
                }}
              />
            )}
          </div>
        );
      })}
    </div>
  );
}

function Field({ label, hint, required, error, children }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <label
        style={{
          display: "block",
          fontSize: "var(--font-xs)",
          fontWeight: 600,
          color: "var(--color-text-secondary)",
          marginBottom: 5,
        }}
      >
        {label}
        {required && <span style={{ color: "#E24B4A", marginLeft: 2 }}>*</span>}
      </label>
      {children}
      {error ? (
        <p
          style={{
            fontSize: "var(--font-xs)",
            color: "#E24B4A",
            marginTop: 4,
            fontWeight: 500,
          }}
        >
          {error}
        </p>
      ) : (
        hint && (
          <p
            style={{
              fontSize: "var(--font-xs)",
              color: "var(--color-text-tertiary)",
              marginTop: 4,
            }}
          >
            {hint}
          </p>
        )
      )}
    </div>
  );
}

function Input({ className = "", style = {}, error, onFocus, onBlur, ...props }) {
  return (
    <input
      {...props}
      className={`form-control ${className}`.trim()}
      style={{
        height: 53,
        border: error
          ? "1px solid #E24B4A"
          : "1px solid var(--color-border-secondary, #C7D2E0)",
        backgroundColor: error ? "#FFF5F5" : undefined,
        outline: "none",
        boxSizing: "border-box",
        ...style,
      }}
      onFocus={(e) => {
        if (!error) e.currentTarget.style.border = "1px solid #ff9900";
        onFocus?.(e);
      }}
      onBlur={(e) => {
        if (!error) e.currentTarget.style.border = "1px solid var(--color-border-secondary, #C7D2E0)";
        onBlur?.(e);
      }}
    />
  );
}

function Select({ children, className = "", style = {}, error, onFocus, onBlur, ...props }) {
  return (
    <select
      {...props}
      className={`form-control ${className}`.trim()}
      style={{
        height: 53,
        paddingRight: 34,
        backgroundImage: "url('/assets/imgs/template/icons/arrow-down.svg')",
        backgroundRepeat: "no-repeat",
        backgroundPosition: "right 12px center",
        appearance: "none",
        WebkitAppearance: "none",
        MozAppearance: "none",
        border: error
          ? "1px solid #E24B4A"
          : "1px solid var(--color-border-secondary, #C7D2E0)",
        backgroundColor: error ? "#FFF5F5" : undefined,
        outline: "none",
        boxSizing: "border-box",
        ...style,
      }}
      onFocus={(e) => {
        if (!error) e.currentTarget.style.border = "1px solid #ff9900";
        onFocus?.(e);
      }}
      onBlur={(e) => {
        if (!error) e.currentTarget.style.border = "1px solid var(--color-border-secondary, #C7D2E0)";
        onBlur?.(e);
      }}
    >
      {children}
    </select>
  );
}

// ── Combobox: type-to-search dropdown, select-only ───────────────────────
// Accepts either a plain string[] or a {value,label}[] options array.
// Typing only filters the list below — it never sets the field's value on
// its own. The value only changes when an option is actually picked (click,
// or pressing Enter on an exact/singular match). Typing something that
// matches nothing and clicking away snaps the text back to whatever is
// actually selected, so nothing gets silently saved.
function Combobox({ value, onChange, options, placeholder, error, disabled }) {
  const normalized = (options || []).map((o) =>
    typeof o === "string" ? { value: o, label: o } : o
  );
  const [open, setOpen] = useState(false);
  const wrapRef = useRef(null);
  const justSelectedRef = useRef(false);

  const matched = normalized.find((o) => o.value === value);
  const [query, setQuery] = useState(matched ? matched.label : value || "");

  useEffect(() => {
    const m = normalized.find((o) => o.value === value);
    setQuery(m ? m.label : value || "");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);

  const revertIfUnmatched = () => {
    const m = normalized.find((o) => o.value === value);
    setQuery(m ? m.label : value || "");
  };

  useEffect(() => {
    const onClickOutside = (e) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) {
        setOpen(false);
        revertIfUnmatched();
      }
    };
    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value, options]);
  const filtered = query
    ? (() => {
      const q = query.toLowerCase().trim();
      const starts = [];
      const contains = [];
      for (const o of normalized) {
        const label = o.label.toLowerCase();
        if (label.startsWith(q)) starts.push(o);
        else if (label.includes(q)) contains.push(o);
      }
      starts.sort((a, b) => a.label.localeCompare(b.label));
      contains.sort((a, b) => a.label.localeCompare(b.label));
      return [...starts, ...contains];
    })()
    : normalized;

  const selectOption = (opt) => {
    justSelectedRef.current = true;
    onChange(opt.value);
    setQuery(opt.label);
    setOpen(false);
  };

  return (
    <div ref={wrapRef} style={{ position: "relative" }}>
      <Input
        value={query}
        disabled={disabled}
        error={error}
        placeholder={placeholder || "Type to search…"}
        autoComplete="off"
        onChange={(e) => {
          setQuery(e.target.value);
          setOpen(true);
        }}
        onFocus={() => setOpen(true)}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            e.preventDefault();
            if (filtered.length === 1) {
              selectOption(filtered[0]);
            } else {
              const exact = normalized.find(
                (o) => o.label.toLowerCase() === query.trim().toLowerCase()
              );
              if (exact) selectOption(exact);
              else revertIfUnmatched();
            }
            setOpen(false);
          } else if (e.key === "Escape") {
            setOpen(false);
            revertIfUnmatched();
          }
        }}
        onBlur={() => {
          // Give a just-clicked option (onMouseDown, which fires first) a
          // chance to register before deciding whether to revert.
          window.setTimeout(() => {
            if (justSelectedRef.current) {
              justSelectedRef.current = false;
              return;
            }
            setOpen(false);
            revertIfUnmatched();
          }, 0);
        }}
      />
      {open && filtered.length > 0 && (
        <div
          style={{
            position: "absolute",
            top: "calc(100% + 4px)",
            left: 0,
            right: 0,
            zIndex: 40,
            background: "#fff",
            border: "0.5px solid var(--color-border-secondary)",
            borderRadius: 8,
            boxShadow: "0 12px 28px rgba(18,35,89,0.14)",
            maxHeight: 220,
            overflowY: "auto",
          }}
        >
          {filtered.map((opt) => (
            <div
              key={opt.value}
              onMouseDown={() => selectOption(opt)}
              style={{
                padding: "9px 14px",
                fontSize: "var(--font-sm)",
                cursor: "pointer",
                color: "var(--color-text-primary)",
                background: opt.label === query ? "#FFF4E0" : "transparent",
              }}
              onMouseEnter={(e) => (e.currentTarget.style.background = "#FFF4E0")}
              onMouseLeave={(e) =>
              (e.currentTarget.style.background =
                opt.label === query ? "#FFF4E0" : "transparent")
              }
            >
              {opt.label}
            </div>
          ))}
        </div>
      )}
      {open && filtered.length === 0 && (
        <div
          style={{
            position: "absolute",
            top: "calc(100% + 4px)",
            left: 0,
            right: 0,
            zIndex: 40,
            background: "#fff",
            border: "0.5px solid var(--color-border-secondary)",
            borderRadius: 8,
            boxShadow: "0 12px 28px rgba(18,35,89,0.14)",
            padding: "9px 14px",
            fontSize: "var(--font-xs)",
            color: "var(--color-text-tertiary)",
          }}
        >
          No matches — pick from the list
        </div>
      )}
    </div>
  );
}

function Btn({ children, variant = "primary", disabled, onClick, style = {} }) {
  const base = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    padding: "9px 20px",
    borderRadius: 8,
    fontSize: "var(--font-sm)",
    fontWeight: 600,
    cursor: disabled ? "not-allowed" : "pointer",
    border: "none",
    opacity: disabled ? 0.5 : 1,
    transition: "opacity .15s",
    ...style,
  };
  const vars = {
    primary: { background: "#ff9900", color: "#fff" },
    outline: {
      background: "transparent",
      border: "0.5px solid var(--color-border-secondary)",
      color: "var(--color-text-secondary)",
    },
    success: { background: "#3B6D11", color: "#fff" },
    danger: { background: "#A32D2D", color: "#fff" },
    ghost: {
      background: "var(--color-background-secondary)",
      color: "var(--color-text-secondary)",
      border: "0.5px solid var(--color-border-secondary)",
    },
  };
  return (
    <button
      style={{ ...base, ...vars[variant] }}
      disabled={disabled}
      onClick={onClick}
    >
      {children}
    </button>
  );
}

function Alert({ type = "info", children }) {
  const colors = {
    info: { bg: "#ffffff", color: "#ff9900", border: "#ffc151" },
    success: { bg: "#EAF3DE", color: "#3B6D11", border: "#C0DD97" },
    warning: { bg: "#FAEEDA", color: "#854F0B", border: "#FAC775" },
    error: { bg: "#FCEBEB", color: "#A32D2D", border: "#F7C1C1" },
  };
  const c = colors[type];
  return (
    <div
      style={{
        padding: "10px 14px",
        borderRadius: 8,
        fontSize: "var(--font-xs)",
        background: c.bg,
        color: c.color,
        border: `0.5px solid ${c.border}`,
        marginBottom: 14,
        lineHeight: 1.5,
      }}
    >
      {children}
    </div>
  );
}

// ── Country code selector backed by react-international-phone's full list ──
function CountryCodeSelect({ value, onChange, disabled, verified }) {
  const meta = getCountryMeta(value);

  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        height: 53,
        borderRadius: 8,
        border: verified ? "1px solid #3B6D11" : "0.5px solid var(--color-border-secondary)",
        background: verified ? "#f4f9f1" : disabled ? "var(--color-background-secondary)" : "#fff",
        paddingLeft: 2,
        paddingRight: 10,
        gap: 2,
        flexShrink: 0,
      }}
    >
      <CountrySelector
        selectedCountry={meta.iso2}
        onSelect={(country) => onChange(`+${country.dialCode}`)}
        disabled={disabled}
        buttonStyle={{
          border: "none",
          background: "transparent",
          height: 44,
          padding: "0 6px",
        }}
      />
      <DialCodePreview
        dialCode={meta.dialCode}
        prefix="+"
        style={{
          fontWeight: 600,
          fontSize: "var(--font-sm)",
          color: "var(--color-text-primary)",
        }}
      />
    </div>
  );
}

// ── 6-box OTP input: auto-advances focus, supports backspace and paste ──
function OtpDigitsInput({ value, onChange, length = 6, disabled, autoFocus }) {
  const inputsRef = useRef([]);
  const digits = (value || "")
    .split("")
    .concat(Array(length).fill(""))
    .slice(0, length);

  const focusInput = (idx) => inputsRef.current[idx]?.focus();

  const handleChange = (idx, raw) => {
    const char = raw.replace(/\D/g, "").slice(-1);
    const next = [...digits];
    next[idx] = char;
    onChange(next.join("").slice(0, length));
    if (char && idx < length - 1) focusInput(idx + 1);
  };

  const handleKeyDown = (idx, e) => {
    if (e.key === "Backspace" && !digits[idx] && idx > 0) focusInput(idx - 1);
  };

  const handlePaste = (e) => {
    const pasted = e.clipboardData
      .getData("text")
      .replace(/\D/g, "")
      .slice(0, length);
    if (pasted) {
      e.preventDefault();
      onChange(pasted);
      focusInput(Math.min(pasted.length, length - 1));
    }
  };

  return (
    <div style={{ display: "flex", gap: 8 }} onPaste={handlePaste}>
      {digits.map((d, i) => (
        <input
          key={i}
          ref={(el) => (inputsRef.current[i] = el)}
          type="text"
          inputMode="numeric"
          autoComplete="one-time-code"
          maxLength={1}
          value={d}
          disabled={disabled}
          autoFocus={autoFocus && i === 0}
          onChange={(e) => handleChange(i, e.target.value)}
          onKeyDown={(e) => handleKeyDown(i, e)}
          className="form-control"
          style={{
            width: 42,
            height: 48,
            padding: 0,
            textAlign: "center",
            fontSize: 18,
            fontWeight: 700,
          }}
        />
      ))}
    </div>
  );
}

// Small resend-cooldown timer shared by both OTP blocks below.
function useResendCooldown(seconds = 30) {
  const [remaining, setRemaining] = useState(0);
  useEffect(() => {
    if (remaining <= 0) return;
    const t = setInterval(() => setRemaining((r) => Math.max(0, r - 1)), 1000);
    return () => clearInterval(t);
  }, [remaining]);
  return [remaining, () => setRemaining(seconds)];
}

// ── Mobile OTP block: country selector + number + boxed OTP entry ──────────
function MobileOtpField({
  countryCode,
  onCountryCodeChange,
  mobile,
  onMobileChange,
  otp,
  onOtpStateChange,
  sendMobileOtp,
  verifyMobileOtp,
  resendMobileOtp,
  skipOtp,
}) {
  const { sent, verified, userVal } = otp;
  const meta = getCountryMeta(countryCode);
  const digitsOnly = mobile.replace(/\D/g, "");
  const touched = digitsOnly.length > 0;
  const mobileValid = isValidMobile(mobile, countryCode);
  const showMobileError = touched && !verified && !mobileValid;
  const [cooldown, startCooldown] = useResendCooldown(30);

  const handleSend = () => {
    sent ? resendMobileOtp() : sendMobileOtp();
    startCooldown();
  };

  return (
    <div>
      <div style={{ display: "flex", gap: 8 }}>
        <CountryCodeSelect
          value={countryCode}
          disabled={verified}
          verified={verified}
          onChange={(v) => {
            onCountryCodeChange(v);
            // re-trim number to new country's max length
            const newMeta = getCountryMeta(v);
            onMobileChange(digitsOnly.slice(0, newMeta.maxLen));
          }}
        />
        <div style={{ position: "relative", flex: 1 }}>
          <Input
            type="tel"
            maxLength={meta.maxLen}
            placeholder={`${meta.minLen}-digit number`}
            value={mobile}
            disabled={verified}
            error={showMobileError}
            onChange={(e) =>
              onMobileChange(
                e.target.value.replace(/\D/g, "").slice(0, meta.maxLen)
              )
            }
            style={{
              paddingRight: verified ? 40 : undefined,
              borderColor: verified ? "#3B6D11" : undefined,
              backgroundColor: verified ? "#f4f9f1" : undefined,
              color: verified ? "#2b4e0c" : undefined,
              border: verified ? "1px solid #3B6D11" : undefined,
            }}
          />
          {verified && (
            <span
              style={{
                position: "absolute",
                right: 12,
                top: "50%",
                transform: "translateY(-50%)",
                width: 22,
                height: 22,
                borderRadius: "50%",
                background: "#3B6D11",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "#fff",
                fontSize: "var(--font-sm)",
                fontWeight: 700,
                flexShrink: 0,
              }}
            >
              ✓
            </span>
          )}
        </div>
      </div>

      {showMobileError && (
        <p style={{ fontSize: "var(--font-xs)", color: "#E24B4A", marginTop: 4 }}>
          Enter a valid {meta.minLen === meta.maxLen ? meta.minLen : `${meta.minLen}-${meta.maxLen}`}-digit number for {meta.code}
        </p>
      )}

      {!skipOtp && !verified && !sent && (
        <div style={{ marginTop: 8 }}>
          <Btn
            variant="ghost"
            disabled={!mobileValid}
            onClick={handleSend}
            style={{ fontSize: "var(--font-xs)", padding: "0 12px", height: 38 }}
          >
            Send OTP
          </Btn>
        </div>
      )}

      {!skipOtp && !verified && sent && (
        <div
          style={{
            marginTop: 12,
            padding: "14px 16px",
            borderRadius: 10,
            border: "0.5px solid var(--color-border-secondary)",
            background: "var(--color-background-secondary)",
          }}
        >
          <p
            style={{
              fontSize: "var(--font-xs)",
              fontWeight: 600,
              color: "var(--color-text-secondary)",
              marginBottom: 10,
            }}
          >
            Enter the 6-digit code sent to {meta.code} {mobile}
          </p>
          <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
            <OtpDigitsInput
              value={userVal}
              onChange={(v) => onOtpStateChange({ ...otp, userVal: v })}
              autoFocus
            />
            <Btn
              variant="primary"
              disabled={userVal.length !== 6}
              onClick={verifyMobileOtp}
              style={{ height: 42, padding: "0 18px" }}
            >
              Verify
            </Btn>
          </div>
          <div style={{ marginTop: 10 }}>
            <button
              type="button"
              onClick={handleSend}
              disabled={cooldown > 0}
              style={{
                background: "none",
                border: "none",
                padding: 0,
                fontSize: "var(--font-xs)",
                fontWeight: 600,
                color: cooldown > 0 ? "var(--color-text-tertiary)" : "#ff9900",
                cursor: cooldown > 0 ? "not-allowed" : "pointer",
              }}
            >
              {cooldown > 0 ? `Resend OTP in ${cooldown}s` : "Resend OTP"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// Standard OTP block for email — same boxed-input treatment as mobile above.
function OtpBlock({
  target,
  sent,
  verified,
  onSend,
  onResend,
  onVerify,
  otpVal,
  setOtpVal,
  disabled,
}) {
  const [cooldown, startCooldown] = useResendCooldown(30);

  const handleSend = () => {
    sent ? onResend() : onSend();
    startCooldown();
  };

  if (verified) {
    return (
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 8,
          padding: "10px 14px",
          borderRadius: 8,
          background: "#EAF3DE",
          border: "0.5px solid #C0DD97",
        }}
      >
        <span
          style={{
            width: 20,
            height: 20,
            borderRadius: "50%",
            background: "#3B6D11",
            color: "#fff",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: 11,
            fontWeight: 700,
            flexShrink: 0,
          }}
        >
          ✓
        </span>
        <span style={{ fontSize: "var(--font-xs)", color: "#3B6D11", fontWeight: 600 }}>
          {target} verified successfully
        </span>
      </div>
    );
  }

  if (!sent) {
    return (
      <Btn
        variant="ghost"
        disabled={disabled}
        onClick={handleSend}
        style={{ fontSize: "var(--font-xs)", padding: "0 12px", height: 38 }}
      >
        Send OTP
      </Btn>
    );
  }

  return (
    <div
      style={{
        padding: "14px 16px",
        borderRadius: 10,
        border: "0.5px solid var(--color-border-secondary)",
        background: "var(--color-background-secondary)",
      }}
    >
      <p
        style={{
          fontSize: "var(--font-xs)",
          fontWeight: 600,
          color: "var(--color-text-secondary)",
          marginBottom: 10,
        }}
      >
        Enter the 6-digit code sent to your {target}
      </p>
      <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
        <OtpDigitsInput value={otpVal} onChange={setOtpVal} autoFocus />
        <Btn
          variant="primary"
          disabled={otpVal.length !== 6}
          onClick={onVerify}
          style={{ height: 42, padding: "0 18px" }}
        >
          Verify
        </Btn>
      </div>
      <div style={{ marginTop: 10 }}>
        <button
          type="button"
          onClick={handleSend}
          disabled={cooldown > 0}
          style={{
            background: "none",
            border: "none",
            padding: 0,
            fontSize: "var(--font-xs)",
            fontWeight: 600,
            color: cooldown > 0 ? "var(--color-text-tertiary)" : "#ff9900",
            cursor: cooldown > 0 ? "not-allowed" : "pointer",
          }}
        >
          {cooldown > 0 ? `Resend OTP in ${cooldown}s` : "Resend OTP"}
        </button>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────
// CANDIDATE FORM
// ─────────────────────────────────────────────
function CandidateForm() {
  const router = useRouter();
  const showToast = useToast();
  const [socialAuth, setSocialAuth] = useState(null);

  const [attemptSubmit, setAttemptSubmit] = useState(false);
  // shape: { provider: "google" | "linkedin", accessToken }
  const [otpToken, setOtpToken] = useState("");
  const [form, setForm] = useState({
    name: "",
    countryCode: "+91",
    mobile: "",
    email: "",
  });

  const [mobileOtp, setMobileOtp] = useState({
    sent: false,
    verified: false,
    userVal: "",
  });

  const [emailOtp, setEmailOtp] = useState({
    sent: false,
    verified: false,
    userVal: "",
  });
  const [paymentData, setPaymentData] = useState({
    planId: null,
    razorpayOrderId: "",
    razorpayPaymentId: "",
    razorpaySignature: "",
    payPalOrderId: ""
  });

  // ── Payment gateway, decided by the server from the visitor's IP ──
  // India -> Razorpay (INR). Everywhere else -> PayPal (plan currency).
  // The backend enforces the same rule, this only drives what we show.
  const [visitor, setVisitor] = useState(null);
  const [visitorLoaded, setVisitorLoaded] = useState(false);
  const isPayPal = visitor?.paymentGateway === "PayPal";
  const payCurrency = isPayPal ? visitor?.currency || "USD" : "INR";
  const [payPalReady, setPayPalReady] = useState(false);
  const payPalContainerRef = useRef(null);
  const payPalCtxRef = useRef({});

  const [couponCode, setCouponCode] = useState("");
  const [couponApplied, setCouponApplied] = useState(false);
  const [couponLoading, setCouponLoading] = useState(false);
  const [couponMessage, setCouponMessage] = useState("");
  const [couponDiscount, setCouponDiscount] = useState(0);
  const [couponFinalAmount, setCouponFinalAmount] = useState(null);

  const [terms, setTerms] = useState(false);
  const [payStatus, setPayStatus] = useState("");
  const [loading, setLoading] = useState(false);
  const [paymentMessage, setPaymentMessage] = useState("");
  const [registering, setRegistering] = useState(false);
  const isSocialVerified = !!socialAuth;
  const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));

  const [candidatePlan, setCandidatePlan] = useState(null);
  const [planLoading, setPlanLoading] = useState(false);

  const fetchPlan = async () => {
    try {
      setPlanLoading(true);
      // PayPal visitors: the pricing region comes from the server's IP lookup
      // (backend region codes like "us", "gb"). India (Razorpay): the "in" plans.
      const region = isPayPal ? visitor.region : "in";
      let response = await getCandidatePlan(region);
      let list = response.data || [];
      // Fallback for India only. Never for PayPal: charging another region's
      // plan would be rejected by the server.
      if (list.length === 0 && !isPayPal) {
        response = await getCandidatePlan("");
        list = response.data || [];
      }
      if (list.length > 0) {
        const activePlan = list.find((p) => p.isActive) || list[0];
        setCandidatePlan(activePlan);
      } else {
        setCandidatePlan(null);
      }
    } catch (err) {
      console.error("Failed to fetch candidate plan:", err);
      setCandidatePlan(null);
    } finally {
      setPlanLoading(false);
    }
  };
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await getPaymentRegion();
        const d = res?.data?.data ?? res?.data;
        if (!cancelled && d?.paymentGateway) setVisitor(d);
      } catch (err) {
        console.error("Failed to detect payment region:", err);
      } finally {
        if (!cancelled) setVisitorLoaded(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  // Load the PayPal JS SDK only for visitors outside India.
  useEffect(() => {
    if (!isPayPal) return;
    const clientId = process.env.NEXT_PUBLIC_PAYPAL_CLIENT_ID;
    if (!clientId) {
      setPaymentMessage("PayPal is not configured (missing NEXT_PUBLIC_PAYPAL_CLIENT_ID).");
      return;
    }
    if (window.paypal) {
      setPayPalReady(true);
      return;
    }
    const script = document.createElement("script");
    script.src = `https://www.paypal.com/sdk/js?client-id=${encodeURIComponent(
      clientId
    )}&currency=${encodeURIComponent(payCurrency)}&intent=capture&components=buttons`;
    script.async = true;
    script.onload = () => setPayPalReady(true);
    script.onerror = () => setPaymentMessage("Could not load PayPal. Please refresh and try again.");
    document.body.appendChild(script);
  }, [isPayPal, payCurrency]);

  useEffect(() => {
    // Wait for the gateway/region so the right plan (and price) is shown.
    if (!visitorLoaded) return;
    fetchPlan();

    // Clear coupon when country/region changes
    setCouponCode("");
    setCouponApplied(false);
    setCouponMessage("");
    setCouponDiscount(0);
    setCouponFinalAmount(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [form.countryCode, visitorLoaded, isPayPal, visitor?.region]);
  useEffect(() => {
    const pending = sessionStorage.getItem("linkedinVerifiedState");
    if (pending) {
      const { accessToken, email, fullName, mobileNumber, countryCode } = JSON.parse(pending);
      setForm((p) => ({ ...p, name: fullName || p.name, email, mobile: mobileNumber || p.mobile, countryCode: countryCode || p.countryCode }));
      setEmailOtp((p) => ({ ...p, sent: true, verified: true }));
      setSocialAuth({ provider: "linkedin", accessToken });
      sessionStorage.removeItem("linkedinVerifiedState");
    }
  }, []);
  const sendMobileOtp = async () => {
    try {
      const identifier = form.mobile.replace(/\D/g, "");
      const response = await sendOtp({
        identifier,
        countryCode: form.countryCode,
      });

      if (!response.data.success) {
        showToast(response.data.message || "Failed to send OTP", "error");
        return;
      }

      // For the configured review number the API verifies the phone inside
      // send-otp and returns the one-time registration token directly, so
      // no OTP input is shown.
      if (response.data.otpSkipped) {
        if (!response.data.otpToken) {
          showToast(
            "The review number was not verified by the server. Please try again.",
            "error"
          );
          return;
        }

        setOtpToken(response.data.otpToken);
        setMobileOtp({ sent: true, verified: true, userVal: "" });
        showToast("Mobile number verified successfully", "success");
        return;
      }

      setMobileOtp((p) => ({
        ...p,
        sent: true,
        verified: false,
        userVal: "",
      }));

      showToast(response.data.message, "success");
    } catch (err) {
      showToast(
        err?.response?.data?.message || "Failed to send OTP",
        "error"
      );
    }
  };

  const verifyMobileOtp = async () => {
    try {
      const response = await verifyOtp({
        identifier: form.mobile.replace(/\D/g, ""),
        countryCode: form.countryCode,
        otpCode: mobileOtp.userVal,
      });
      if (response.data.success) {

        setOtpToken(response.data.otpToken);

        setMobileOtp((p) => ({
          ...p,
          verified: true,
        }));

        showToast("Mobile verified successfully", "success");
      }
    } catch (err) {
      showToast(
        err?.response?.data?.message || "Invalid OTP",
        "error"
      );
    }
  };

  const sendEmail = async () => {
    try {
      const response = await sendOtp({
        identifier: form.email,
      });

      if (response.data.success) {
        setEmailOtp((p) => ({
          ...p,
          sent: true,
          verified: false,
          userVal: "",
        }));

        showToast(response.data.message, "success");
      }
    } catch (err) {
      showToast(
        err?.response?.data?.message || "Failed to send OTP",
        "error"
      );
    }
  };

  const verifyEmail = async () => {
    try {
      const response = await verifyOtp({
        identifier: form.email,
        otpCode: emailOtp.userVal,
      });

      if (response.data.success) {

        setOtpToken(response.data.otpToken);

        setEmailOtp((p) => ({
          ...p,
          verified: true,
        }));

        showToast("Email verified successfully", "success");
      }
    } catch (err) {
      showToast(
        err?.response?.data?.message || "Invalid OTP",
        "error"
      );
    }
  };

  // Razorpay test payment ₹100
  const handlePay = async () => {
    try {
      setLoading(true);

      const key =
        process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID || "";

      if (typeof window === "undefined") {
        setLoading(false);
        return;
      }

      if (!window.Razorpay) {
        setLoading(false);

        setPaymentMessage(
          "Razorpay SDK missing."
        );

        return;
      }

      // Create order from backend. The pricing region is fixed server-side
      // (India), and the server refuses Razorpay for visitors outside India.
      const orderResponse =
        await createCandidateOrder({
          couponCode: couponApplied
            ? couponCode.trim().toUpperCase()
            : null,
        });

      const order = orderResponse.data;

      if (!order.success) {
        setLoading(false);

        setPaymentMessage(
          order.message || "Unable to create payment order."
        );

        return;
      }

      const activeKey = order.razorpayKeyId || key;
      if (!activeKey) {
        setLoading(false);
        setPaymentMessage("Razorpay key missing.");
        return;
      }

      const options = {
        key: activeKey,

        amount: order.finalAmountPaise,

        currency: order.currency,

        order_id: order.orderId,

        name: "Job Box",

        description: "Candidate Registration Fee",

        handler: function (response) {

          console.log("RAZORPAY RESPONSE", response);

          const paymentInfo = {
            // The backend re-validates this PlanId on submit-registration
            // (see CandidateAuthService.RegisterAsync) — without it, PlanId
            // defaults to an empty Guid and the plan lookup fails with
            // "Selected membership plan is no longer available."
            planId: order.planId,
            razorpayOrderId: response.razorpay_order_id,
            razorpayPaymentId: response.razorpay_payment_id,
            razorpaySignature: response.razorpay_signature,
          };

          setPaymentData(paymentInfo);

          setPayStatus("success");

          setPaymentMessage(
            `Payment successful. Reference: ${response.razorpay_payment_id}`
          );

          setLoading(false);

          // Payment succeeded — complete registration right away instead of
          // requiring a second click on "Create Account & Get Started".
          handleCandidateSubmit(paymentInfo);
        },

        prefill: {
          name: form.name,
          contact: form.mobile,
          email: form.email,
        },

        theme: {
          color: "#ff9900",
        },

        modal: {
          ondismiss: () => {
            setLoading(false);

            setPaymentMessage(
              "Payment window closed before completion."
            );
          },
        },
      };

      const rzp = new window.Razorpay(options);

      rzp.open();

    } catch (error) {

      console.error(
        "Razorpay initialization error",
        error
      );

      setLoading(false);

      setPaymentMessage(
        error?.response?.data?.message ||
        "Payment initialization failed."
      );

    }
  };

  // ── PayPal (outside India) ─────────────────────────────────────
  // The PayPal order is bound to the credential this registration will present:
  // the OTP token (mobile/email) or the Google/LinkedIn access token.
  // Latest values for the PayPal button callbacks, which are created once.
  payPalCtxRef.current = {
    otpToken,
    socialAuth,
    couponApplied,
    couponCode,
    terms,
    planId: candidatePlan?.planId,
  };

  const payPalCredential = () => {
    const ctx = payPalCtxRef.current;
    return ctx.socialAuth
      ? { accessToken: ctx.socialAuth.accessToken }
      : { otpToken: ctx.otpToken };
  };

  const payPalOrderMetaRef = useRef({});

  const payPalCreateOrder = async () => {
    const ctx = payPalCtxRef.current;

    const res = await createCandidatePayPalOrder({
      ...payPalCredential(),
      couponCode: ctx.couponApplied ? ctx.couponCode.trim().toUpperCase() : null,
    });

    const order = res.data;

    if (!order?.success || !order.payPalOrderId) {
      throw new Error(order?.message || "Unable to create PayPal order.");
    }

    payPalOrderMetaRef.current = { planId: order.planId };
    return order.payPalOrderId;
  };

  const payPalOnApprove = async (approval) => {
    try {
      setLoading(true);

      const res = await captureCandidatePayPal({
        ...payPalCredential(),
        payPalOrderId: approval.orderID,
      });

      if (!res.data?.success) {
        throw new Error(res.data?.message || "PayPal payment could not be confirmed.");
      }

      const paymentInfo = {
        planId: payPalOrderMetaRef.current.planId || payPalCtxRef.current.planId,
        razorpayOrderId: "",
        razorpayPaymentId: "",
        razorpaySignature: "",
        payPalOrderId: approval.orderID,
      };

      setPaymentData(paymentInfo);
      setPayStatus("success");
      setPaymentMessage(`Payment successful. Reference: ${approval.orderID}`);
      setLoading(false);

      // Payment captured — complete registration right away.
      handleCandidateSubmit(paymentInfo);
    } catch (err) {
      setLoading(false);
      const msg =
        err?.response?.data?.message ||
        err?.message ||
        "PayPal payment could not be confirmed.";
      setPaymentMessage(msg);
      showToast(msg, "error");
    }
  };

  const canShowPayment = mobileOtp.verified || emailOtp.verified;

  const showPayPalButtons =
    canShowPayment &&
    isPayPal &&
    payPalReady &&
    payStatus !== "success" &&
    !!candidatePlan?.planId;

  useEffect(() => {
    if (!showPayPalButtons || !payPalContainerRef.current || !window.paypal) return;

    const buttons = window.paypal.Buttons({
      style: { layout: "vertical", shape: "rect", label: "pay" },
      onClick: (_d, actions) => {
        if (!payPalCtxRef.current.terms) {
          showToast("Please accept the Terms of Service to continue.", "warning");
          return actions.reject();
        }
        return actions.resolve();
      },
      createOrder: payPalCreateOrder,
      onApprove: payPalOnApprove,
      onCancel: () => setPaymentMessage("Payment window closed before completion."),
      onError: (err) => {
        console.error("PayPal error", err);
        const msg =
          err?.response?.data?.message ||
          err?.message ||
          "PayPal payment failed. Please try again.";
        setPaymentMessage(msg);
        showToast(msg, "error");
      },
    });

    buttons.render(payPalContainerRef.current).catch((e) => {
      console.error("PayPal buttons render failed", e);
    });

    return () => {
      try {
        buttons.close();
      } catch (e) {
        /* already closed */
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showPayPalButtons, candidatePlan?.planId, couponApplied]);


  const canSubmit = canShowPayment && terms && payStatus === "success";

  // paymentOverride lets the Razorpay success handler pass the just-received
  // razorpayOrderId/PaymentId/Signature straight through, since React state
  // (paymentData) hasn't re-rendered yet at that point in the callback.
  const handleCandidateSubmit = async (paymentOverride) => {
    setAttemptSubmit(true);

    if (!form.name.trim()) {
      showToast("Please enter your full name.", "error");
      return;
    }

    if (!terms) {
      showToast("Please accept the Terms of Service to continue.", "error");
      return;
    }

    if (!socialAuth) {
      const hasVerifiedMobile = mobileOtp.verified;
      const hasVerifiedEmail = emailOtp.verified;

      if (!hasVerifiedMobile && !hasVerifiedEmail) {
        showToast("Please verify your mobile number or email address to continue.", "error");
        return;
      }

      // If they typed an email but never verified it, don't silently drop it —
      // ask them to finish verifying or clear the field.
      if (form.email.trim() && !emailOtp.verified) {
        showToast("Please verify your email address, or remove it to continue with mobile only.", "error");
        return;
      }
    }

    const payInfo = paymentOverride || paymentData;

    try {
      setRegistering(true);

      if (socialAuth) {
        const registerFn =
          socialAuth.provider === "google" ? registerWithGoogle : registerWithLinkedIn;

        const response = await registerFn({
          accessToken: socialAuth.accessToken,
          fullName: form.name,
          mobileNumber: form.mobile ? form.mobile.replace(/\D/g, "") : null,
          countryCode: form.mobile ? form.countryCode : null,
          termsAccepted: terms,
          planId: payInfo.planId,
          // The server re-validates the coupon and the amount that was paid.
          couponCode: couponApplied
            ? couponCode.trim().toUpperCase()
            : null,
          razorpayOrderId: payInfo.razorpayOrderId,
          razorpayPaymentId: payInfo.razorpayPaymentId,
          razorpaySignature: payInfo.razorpaySignature,
          payPalOrderId: payInfo.payPalOrderId || "",
        });

        if (response.data.success) {
          localStorage.setItem("token", response.data.token);
          showToast(response.data.message, "success");
          setTimeout(() => router.push("/Login"), 1000);
        } else {
          showToast(response.data.message, "error");
        }
        return;
      }

      // existing OTP-based path — unchanged
      const response = await registerCandidate({
        fullName: form.name,
        mobileNumber: form.mobile.replace(/\D/g, ""),
        countryCode: form.countryCode,
        email: form.email,
        otpToken,
        planId: payInfo.planId,

        // Send the coupon used for this payment
        couponCode: couponApplied
          ? couponCode.trim().toUpperCase()
          : null,

        razorpayOrderId: payInfo.razorpayOrderId,
        razorpayPaymentId: payInfo.razorpayPaymentId,
        razorpaySignature: payInfo.razorpaySignature,
        payPalOrderId: payInfo.payPalOrderId || "",
        termsAccepted: terms,
      });

      showToast(response.data.message, "success");
      setTimeout(() => router.push("/Login"), 1000);
    } catch (err) {
      console.log("REGISTER ERROR", err);
      console.log("STATUS", err?.response?.status);
      console.log("DATA", err?.response?.data);

      showToast(
        err?.response?.data?.message || "Registration failed",
        "error"
      );
    } finally {
      setRegistering(false);
    }
  };


  const handleGoogleRegister = () => {
    if (typeof window === "undefined" || !window.google) {
      showToast("Google sign-in is still loading, try again", "error");
      return;
    }

    const client = window.google.accounts.oauth2.initTokenClient({
      client_id: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID,
      scope: "openid email profile",
      callback: async (tokenResponse) => {
        if (!tokenResponse?.access_token) {
          showToast("Google sign-in failed", "error");
          return;
        }

        try {
          const response = await verifyWithGoogle({
            accessToken: tokenResponse.access_token,
          });

          if (response.data.success) {
            setForm((p) => ({
              ...p,
              name: response.data.fullName || p.name,
              email: response.data.email,
            }));
            setEmailOtp((p) => ({ ...p, sent: true, verified: true }));
            setSocialAuth({ provider: "google", accessToken: tokenResponse.access_token });
            showToast("Google account verified. Complete payment to finish.", "success");
          } else {
            showToast(response.data.message, "error");
          }
        } catch (err) {
          showToast(err?.response?.data?.message || "Verification failed", "error");
        }
      },
    });

    client.requestAccessToken();
  };

  const handleLinkedInRegister = () => {
    const redirectUri = `${window.location.origin}/linkedin/register`;
    const params = new URLSearchParams({
      response_type: "code",
      client_id: process.env.NEXT_PUBLIC_LINKEDIN_CLIENT_ID,
      redirect_uri: redirectUri,
      scope: "openid profile email",
    });

    window.location.href = `https://www.linkedin.com/oauth/v2/authorization?${params.toString()}`;
  };
  return (
    <div>
      <Alert type="info">
        Smart AI note: after CV upload, profile fields are auto-filled from AI
        parsing. You only verify and save.
      </Alert>

      <Field
        label="Full Name"
        required
        error={attemptSubmit && !form.name.trim() ? "Full name is required" : null}
      >
        <Input
          placeholder="Enter your full name (e.g. Arjun Mehta)"
          value={form.name}
          disabled={isSocialVerified}
          error={attemptSubmit && !form.name.trim()}
          onChange={(e) => set("name", e.target.value)}
        />
      </Field>

      <Field label="Mobile Number" required>
        <MobileOtpField
          countryCode={form.countryCode}
          onCountryCodeChange={(v) => set("countryCode", v)}
          mobile={form.mobile}
          onMobileChange={(v) => set("mobile", v)}
          otp={mobileOtp}
          onOtpStateChange={setMobileOtp}
          sendMobileOtp={sendMobileOtp}
          verifyMobileOtp={verifyMobileOtp}
          resendMobileOtp={sendMobileOtp}
        />
      </Field>

      <Field
        label="Email"
        hint={!form.email || isValidEmail(form.email) ? "Optional — verify to improve account security" : null}
        error={form.email && !isValidEmail(form.email) ? "Enter a complete, valid email address" : null}
      >
        <Input
          type="email"
          placeholder="Enter your email address (e.g. john@example.com)"
          value={form.email}
          error={form.email && !isValidEmail(form.email)}
          disabled={isSocialVerified || emailOtp.verified}
          onChange={(e) => {
            const val = e.target.value;
            if (val && /^\d+$/.test(val)) return;
            set("email", val);
          }}
          style={{
            borderColor: emailOtp.verified ? "#3B6D11" : undefined,
            backgroundColor: emailOtp.verified ? "#f4f9f1" : undefined,
            color: emailOtp.verified ? "#2b4e0c" : undefined,
            border: emailOtp.verified ? "1px solid #3B6D11" : undefined,
          }}
        />
        {form.email && isValidEmail(form.email) && (
          <div style={{ marginTop: 8 }}>
            <OtpBlock
              target="email"
              sent={emailOtp.sent}
              verified={emailOtp.verified}
              disabled={!isValidEmail(form.email)}
              onSend={sendEmail}
              onResend={sendEmail}
              onVerify={verifyEmail}
              otpVal={emailOtp.userVal}
              setOtpVal={(v) =>
                setEmailOtp((p) => ({
                  ...p,
                  userVal: v,
                }))
              }
            />
          </div>
        )}
      </Field>

      {canShowPayment && payStatus !== "success" && (
        <div style={{ marginBottom: 14 }}>
          <label
            style={{
              display: "flex",
              alignItems: "center",
              gap: 10,
              cursor: "pointer",
              fontSize: "var(--font-sm)",
              color: "var(--color-text-secondary)",
            }}
          >
            <input
              type="checkbox"
              checked={terms}
              onChange={(e) => setTerms(e.target.checked)}
              style={{ width: 16, height: 16 }}
            />
            I agree to the Terms of Service and Privacy Policy
          </label>
        </div>
      )}

      {canShowPayment && (
        <Field label="Coupon Code">
          <div style={{ display: "flex", gap: 8 }}>
            <Input
              placeholder="Enter coupon code"
              value={couponCode}
              disabled={couponApplied || couponLoading || loading}
              onChange={(e) => {
                setCouponCode(e.target.value.toUpperCase());
                setCouponApplied(false);
                setCouponMessage("");
                setCouponDiscount(0);
                setCouponFinalAmount(null);
              }}
              style={{
                flex: 1,
                textTransform: "uppercase",
              }}
            />

            <Btn
              variant={couponApplied ? "success" : "primary"}
              disabled={
                !couponCode.trim() ||
                couponLoading ||
                couponApplied ||
                loading
              }
              onClick={async () => {
                if (!couponCode.trim()) {
                  setCouponMessage("Please enter a coupon code.");
                  return;
                }

                if (!candidatePlan?.planId) {
                  setCouponMessage("Membership plan is not available.");
                  return;
                }

                try {
                  setCouponLoading(true);
                  setCouponMessage("");

                  // Coupons are matched against the plan's own pricing region.
                  const region =
                    candidatePlan.region ||
                    (isPayPal ? visitor?.region : "in") ||
                    "in";

                  const response = await validateCandidateCoupon({
                    code: couponCode.trim().toUpperCase(),
                    planType: "Candidate",
                    planId: candidatePlan.planId,
                    region,
                  });

                  const result = response?.data ?? response;

                  if (!result?.isValid) {
                    setCouponApplied(false);
                    setCouponDiscount(0);
                    setCouponFinalAmount(null);
                    setCouponMessage(
                      result?.message || "Invalid or expired coupon."
                    );
                    return;
                  }

                  setCouponApplied(true);
                  setCouponDiscount(Number(result.discountAmount || 0));
                  setCouponFinalAmount(Number(result.finalAmount || 0));
                  setCouponMessage(
                    result.message || "Coupon applied successfully."
                  );
                } catch (error) {
                  console.error("Coupon validation error:", error);

                  setCouponApplied(false);
                  setCouponDiscount(0);
                  setCouponFinalAmount(null);

                  setCouponMessage(
                    error?.response?.data?.message ||
                    "Unable to validate coupon. Please try again."
                  );
                } finally {
                  setCouponLoading(false);
                }
              }}
              style={{
                minWidth: 100,
              }}
            >
              {couponLoading
                ? "Checking..."
                : couponApplied
                  ? "Applied"
                  : "Apply"}
            </Btn>
          </div>

          {couponMessage && (
            <p
              style={{
                fontSize: "var(--font-xs)",
                marginTop: 8,
                color: couponApplied ? "#3B6D11" : "#A32D2D",
              }}
            >
              {couponMessage}
            </p>
          )}

          {couponApplied && couponDiscount > 0 && (
            <p
              style={{
                fontSize: "var(--font-xs)",
                marginTop: 4,
                color: "#3B6D11",
                fontWeight: 600,
              }}
            >
              Discount: {payCurrency} {couponDiscount.toFixed(2)}
            </p>
          )}
        </Field>
      )}

      {canShowPayment && (
        <Field label="Registration Fee">
          {payStatus === "success" ? (
            <Alert type="success">
              {registering
                ? "Payment successful — creating your account..."
                : `Payment successful for ${payCurrency} ${couponApplied && couponFinalAmount !== null ? couponFinalAmount.toFixed(2) : Number(candidatePlan?.price || 0).toFixed(2)}. Your receipt will be sent to your registered email.`}
            </Alert>
          ) : (
            <>
              {!visitorLoaded ? (
                <p style={{ fontSize: "var(--font-xs)", color: "var(--color-text-tertiary)" }}>
                  Detecting your region…
                </p>
              ) : isPayPal ? (
                <>
                  <p style={{ fontSize: "var(--font-sm)", fontWeight: 600, marginBottom: 8 }}>
                    Pay {payCurrency}{" "}
                    {Number(
                      couponApplied && couponFinalAmount !== null
                        ? couponFinalAmount
                        : candidatePlan?.price || 0
                    ).toFixed(2)}{" "}
                    with PayPal
                  </p>
                  {/* The PayPal SDK renders its own button here — it must be
                      PayPal's button to open the popup. */}
                  <div
                    ref={payPalContainerRef}
                    style={{
                      opacity: loading ? 0.5 : 1,
                      pointerEvents: loading ? "none" : "auto",
                    }}
                  />
                  {!payPalReady && (
                    <p style={{ fontSize: "var(--font-xs)", color: "var(--color-text-tertiary)" }}>
                      Loading PayPal…
                    </p>
                  )}
                  {!candidatePlan?.planId && !planLoading && (
                    <p style={{ fontSize: "var(--font-xs)", color: "#A32D2D" }}>
                      Membership isn&apos;t available in your region yet. Please contact support.
                    </p>
                  )}
                </>
              ) : (
              <Btn
                variant="primary"
                onClick={handlePay}
                disabled={loading || !terms}
                style={{
                  width: "100%",
                  padding: "11px 0",
                  fontSize: "var(--font-sm)",
                }}
              >
                {loading
                  ? "Processing..."
                  : `Pay INR ${couponApplied && couponFinalAmount !== null
                    ? couponFinalAmount.toFixed(2)
                    : (candidatePlan?.price || 100).toFixed(2)
                  } via Razorpay`}
              </Btn>
              )}
              {!terms && (
                <p
                  style={{
                    fontSize: "var(--font-xs)",
                    marginTop: 8,
                    color: "var(--color-text-tertiary)",
                  }}
                >
                  Please accept the Terms of Service above to continue to payment.
                </p>
              )}
            </>
          )}
          {paymentMessage && (
            <p
              style={{
                fontSize: "var(--font-xs)",
                marginTop: 8,
                color: "var(--color-text-tertiary)",
              }}
            >
              {paymentMessage}
            </p>
          )}
        </Field>
      )}
      {/* Social Register */}
      <div style={{ marginBottom: 26 }}>
        {/* Divider */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            marginBottom: 18,
            gap: 14,
          }}
        >
          <div
            style={{
              flex: 1,
              height: 1,
              background: "#ececec",
            }}
          />

          <span
            style={{
              fontSize: 14,
              color: "var(--color-text-tertiary)",
              fontWeight: 600,
            }}
          >
            OR REGISTER WITH
          </span>

          <div
            style={{
              flex: 1,
              height: 1,
              background: "#ececec",
            }}
          />
        </div>

        {/* Social Register */}
        {!socialAuth ? (
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              gap: 14,
            }}
          >
            {/* Google */}
            <button
              type="button"
              onClick={handleGoogleRegister}
              style={{
                width: "100%",
                height: 54,
                borderRadius: 10,
                border: "1px solid #ffc151",
                background: "#ffffff",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: 12,
                fontWeight: 600,
                fontSize: 15,
                color: "#122359",
                cursor: "pointer",
                transition: "all 0.25s ease",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = "#ff9900";
                e.currentTarget.style.color = "#ffffff";
                e.currentTarget.style.transform = "translateY(-2px)";
                e.currentTarget.style.boxShadow =
                  "0 8px 20px rgba(255,153,0,0.18)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = "#ffffff";
                e.currentTarget.style.color = "#122359";
                e.currentTarget.style.transform = "translateY(0px)";
                e.currentTarget.style.boxShadow = "none";
              }}
            >
              <img
                src="https://www.svgrepo.com/show/475656/google-color.svg"
                alt="google"
                width={20}
                height={20}
              />
              Register with Google
            </button>

            {/* LinkedIn */}
            <button
              type="button"
              onClick={handleLinkedInRegister}
              style={{
                width: "100%",
                height: 54,
                borderRadius: 10,
                border: "1px solid #ffc151",
                background: "#ffffff",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: 12,
                fontWeight: 600,
                fontSize: 15,
                color: "#122359",
                cursor: "pointer",
                transition: "all 0.25s ease",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = "#ff9900";
                e.currentTarget.style.color = "#ffffff";
                e.currentTarget.style.transform = "translateY(-2px)";
                e.currentTarget.style.boxShadow =
                  "0 8px 20px rgba(255,153,0,0.18)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = "#ffffff";
                e.currentTarget.style.color = "#122359";
                e.currentTarget.style.transform = "translateY(0px)";
                e.currentTarget.style.boxShadow = "none";
              }}
            >
              <img
                src="https://cdn-icons-png.flaticon.com/512/3536/3536505.png"
                alt="linkedin"
                width={18}
                height={18}
              />
              Register with LinkedIn
            </button>
          </div>
        ) : (
          <Alert type="success">
            ✓ Verified via {socialAuth.provider === "google" ? "Google" : "LinkedIn"} — complete payment below to finish registration.
          </Alert>
        )}
      </div>

      {/* Registration completes automatically once payment succeeds (see the
          Razorpay handler above). This button stays only as a manual fallback
          in case that auto-submit ever fails. */}
      {payStatus === "success" && (
        <Btn
          variant="primary"
          disabled={!canSubmit || registering}
          style={{ width: "100%", padding: "13px 0", fontSize: "var(--font-md)" }}
          onClick={() => handleCandidateSubmit()}
        >
          {registering ? "Creating your account..." : "Create Account & Get Started"}
        </Btn>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────
// EMPLOYER MULTI-STEP FORM
// ─────────────────────────────────────────────
const STEP_LABELS = [
  "GST Check",
  "Company Details",
  "Contact & OTP",
  "Licences",
  "Review",
];

function EmployerForm() {
  const router = useRouter();
  const showToast = useToast();
  const [step, setStep] = useState(1);
  const [industriesList, setIndustriesList] = useState([]);
  const [recruiterPlans, setRecruiterPlans] = useState([]);
  const [selectedPlanId, setSelectedPlanId] = useState("");

  const [couponCode, setCouponCode] = useState("");
  const [couponApplied, setCouponApplied] = useState(false);
  const [couponLoading, setCouponLoading] = useState(false);
  const [couponMessage, setCouponMessage] = useState("");

  const [couponDiscount, setCouponDiscount] = useState(0);
  const [couponFinalAmount, setCouponFinalAmount] = useState(null);
  const [data, setData] = useState({
    hasGst: null,
    industry: "",
    customIndustry: "",
    gstn: "",
    legalName: "",
    tradeName: "",
    businessType: "",
    companySize: "",
    companyType: "",
    natureOfCompany: "", // "RecruitmentAgency" | "Employer"
    companyLocationType: "",
    placesInternationally: null, // true | false | null (unanswered)
    pan: "",
    gstRegDate: "",
    cin: "",
    state: "",
    stateIso: "",
    city: "",
    country: "",
    countryIso: "",
    pincode: "",
    address: "",
    officialWebsite: "",
    companyLogo: null,
    contactName: "",
    designation: "",
    contactPersonEmail: "",
    corpEmail: "",
    countryCode: "+91",
    mobile: "",
    profileSummary: "",
    licDocs: [],
    mobileOtp: { sent: false, verified: false, userVal: "" },
    corpEmailOtp: { sent: false, verified: false, userVal: "" },
    profileStatus: "pending",
  });
  const [ocrLoading, setOcrLoading] = useState(false);
  const [loadingResume, setLoadingResume] = useState(true);
  const [attempt1, setAttempt1] = useState(false);
  const [attempt2, setAttempt2] = useState(false);
  const [attempt3, setAttempt3] = useState(false);

  const logoRef = useRef();
  const licRef = useRef();

  const [recruiterPlan, setRecruiterPlan] = useState(null);
  const [planLoading, setPlanLoading] = useState(false);
  const [payStatus, setPayStatus] = useState("");

  const [paymentData, setPaymentData] = useState({
    planId: null,
    razorpayOrderId: "",
    razorpayPaymentId: "",
    razorpaySignature: "",
    payPalOrderId: "",
  });
  const [paymentMessage, setPaymentMessage] = useState("");
  const [paying, setPaying] = useState(false);
  const [termsAccepted, setTermsAccepted] = useState(false);

  // ── Payment gateway, decided by the server from the visitor's IP ──
  // India -> Razorpay (INR). Everywhere else -> PayPal (plan currency).
  // The backend enforces the same rule, this only drives what we show.
  const [visitor, setVisitor] = useState(null);
  const [visitorLoaded, setVisitorLoaded] = useState(false);
  const isPayPal = visitor?.paymentGateway === "PayPal";
  const payCurrency = isPayPal ? visitor?.currency || "USD" : "INR";
  const currencyPrefix = payCurrency === "INR" ? "₹" : `${payCurrency} `;
  const [payPalReady, setPayPalReady] = useState(false);
  const payPalContainerRef = useRef(null);
  const payPalCtxRef = useRef({});
  const payPalOrderMetaRef = useRef({});

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await getPaymentRegion();
        const d = res?.data?.data ?? res?.data;
        if (!cancelled && d?.paymentGateway) setVisitor(d);
      } catch (err) {
        console.error("Failed to detect payment region:", err);
      } finally {
        if (!cancelled) setVisitorLoaded(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  // Load the PayPal JS SDK only for visitors outside India.
  useEffect(() => {
    if (!isPayPal) return;
    const clientId = process.env.NEXT_PUBLIC_PAYPAL_CLIENT_ID;
    if (!clientId) {
      setPaymentMessage("PayPal is not configured (missing NEXT_PUBLIC_PAYPAL_CLIENT_ID).");
      return;
    }
    if (window.paypal) {
      setPayPalReady(true);
      return;
    }
    const script = document.createElement("script");
    script.src = `https://www.paypal.com/sdk/js?client-id=${encodeURIComponent(
      clientId
    )}&currency=${encodeURIComponent(payCurrency)}&intent=capture&components=buttons`;
    script.async = true;
    script.onload = () => setPayPalReady(true);
    script.onerror = () => setPaymentMessage("Could not load PayPal. Please refresh and try again.");
    document.body.appendChild(script);
  }, [isPayPal, payCurrency]);

  const fetchRecruiterPlan = async (code) => {
    try {
      setPlanLoading(true);

      // PayPal visitors: the region comes from the server's IP lookup.
      // India (Razorpay): unchanged — region from the phone country.
      const region = isPayPal ? visitor.region : "in";

      let response = await getRecruiterPlan(region);
      let list = response.data || [];

      // Fallback if no plans are found for the selected region. Never for
      // PayPal: charging another region's plan would be rejected by the server.
      if (list.length === 0 && !isPayPal) {
        response = await getRecruiterPlan("");
        list = response.data || [];
      }

      // Keep only active plans
      const activePlans = list.filter((p) => p.isActive);

      if (activePlans.length > 0) {
        // Store all available active recruiter plans
        setRecruiterPlans(activePlans);

        // Select the first plan by default
        const defaultPlan = activePlans[0];

        setSelectedPlanId(defaultPlan.planId);

        // Keep old state synchronized for now
        setRecruiterPlan(defaultPlan);
      } else {
        setRecruiterPlans([]);
        setSelectedPlanId("");
        setRecruiterPlan(null);
      }
    } catch (err) {
      console.error("Failed to fetch recruiter plans:", err);

      setRecruiterPlans([]);
      setSelectedPlanId("");
      setRecruiterPlan(null);
    } finally {
      setPlanLoading(false);
    }
  };

  const handleApplyRecruiterCoupon = async () => {
    if (!couponCode.trim()) {
      setCouponMessage("Please enter a coupon code.");
      return;
    }

    if (!selectedPlanId) {
      setCouponMessage("Please select a membership plan first.");
      return;
    }

    try {
      setCouponLoading(true);
      setCouponMessage("");
      setCouponApplied(false);
      setCouponDiscount(0);
      setCouponFinalAmount(null);


      // Razorpay (India) plans are stored under region "in" — not the country name.
      const region = "in";

      const sessionId = localStorage.getItem("registrationSessionId");

      // We don't need a separate frontend coupon API.
      // The backend validates the coupon when creating the Razorpay order.
      // PayPal visitors validate through the PayPal order endpoint (the
      // Razorpay one refuses them). It also creates an unused PayPal order,
      // which simply expires.
      const response = isPayPal
        ? await createPayPalMembershipOrder({
          sessionId,
          planId: selectedPlanId,
          couponCode: couponCode.trim().toUpperCase(),
        })
        : await createMembershipOrder({
          sessionId,
          region,
          planId: selectedPlanId,
          couponCode: couponCode.trim().toUpperCase(),
        });

      const result = response.data;

      if (!result?.success) {
        setCouponMessage(
          result?.message || "Invalid or expired coupon."
        );
        return;
      }

      setCouponApplied(true);
      setCouponDiscount(result.discountAmount || 0);
      setCouponFinalAmount(result.finalAmount);

      setCouponMessage(
        result.discountAmount > 0
          ? `Coupon applied successfully. You save ${currencyPrefix}${result.discountAmount}.`
          : "Coupon applied successfully."
      );
    } catch (err) {
      console.error("Recruiter coupon error:", err);

      setCouponMessage(
        err?.response?.data?.message ||
        "Unable to validate coupon. Please try again."
      );
    } finally {
      setCouponLoading(false);
    }
  };

  useEffect(() => {
    // Wait for the gateway detection so plans load once, for the right region.
    if (!visitorLoaded) return;
    fetchRecruiterPlan(data.countryCode);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data.countryCode, visitorLoaded, isPayPal, visitor?.region]);


  useEffect(() => {
    const fetchIndustries = async () => {
      try {
        const res = await getIndustries();
        if (res?.success && res.industries) {
          const apiIndustries = res.industries.map((ind) => ind.name).filter(Boolean);
          setIndustriesList(apiIndustries);
        } else {
          setIndustriesList([]);
        }
      } catch (err) {
        console.error("Failed to load industries from registration API:", err);
        setIndustriesList([]);
      }
    };
    fetchIndustries();
  }, []);

  const set = (k, v) => setData((p) => ({ ...p, [k]: v }));

  // Ensure "Other" is always selectable even if the API list doesn't include it
  const industryOptions = industriesList.includes("Other")
    ? industriesList
    : [...industriesList, "Other"];

  const autoFillGst = () => {
    if (data.gstn.length < 15) {
      showToast("Enter a valid 15-character GSTN", "error");
      return;
    }
    // For demo purposes, we simulate an API call to fetch company details based on GSTN.
    setOcrLoading(true);
    setTimeout(() => {
      setData((p) => ({
        ...p,
        legalName: "Horizon Marine Services Pvt. Ltd.",
        tradeName: "Horizon Marine",
        pan: "AAPFU0939F",
        businessType: "Private Limited",
        country: "India",
        countryIso: "IN",
        state: "Maharashtra",
        stateIso: getStateIso("IN", "Maharashtra"),
        city: "Mumbai",
        pincode: "400001",
        address: "Unit 4B, Trade Tower, Ballard Estate, Mumbai",
        gstRegDate: "2018-07-01",
      }));
      setOcrLoading(false);
    }, 1500);
  };
  const handleSendMobileOtp = async () => {
    try {
      const sessionId = localStorage.getItem("registrationSessionId");

      // Verify mobile number is not already registered using login OTP endpoint
      try {
        await sendLoginOtp({
          identifier: data.mobile.replace(/\D/g, ""),
          countryCode: data.countryCode,
        });

        // If the above call succeeds (200), the mobile number is already registered!
        showToast("Mobile number already registered.", "error");
        return;
      } catch (checkErr) {
        // If it throws a 404 (No account found), the mobile is unique and we can proceed.
        // If it throws any other error (like Twilio unverified error: 400), it means the user exists in database but Twilio failed!
        if (checkErr.response?.status !== 404) {
          showToast("Mobile number already registered.", "error");
          return;
        }
      }

      await saveStep3();

      const response = await sendMobileOtp(
        {
          mobileNumber: data.mobile.replace(/\D/g, ""),
          countryCode: data.countryCode,
        },
        sessionId,
      );

      setData((p) => ({
        ...p,
        mobileOtp: {
          ...p.mobileOtp,
          sent: true,
        },
      }));

      showToast(response.data.message, "success");
    } catch (err) {
      showToast(err.response?.data?.message || "Mobile OTP verification failed.", "error");
    }
  };
  const handleVerifyMobileOtp = async () => {
    try {
      const sessionId = localStorage.getItem("registrationSessionId");

      const response = await verifyMobileOtp(
        {
          mobileNumber: data.mobile.replace(/\D/g, ""),
          countryCode: data.countryCode,
          mobileOtpCode: data.mobileOtp.userVal,
        },
        sessionId,
      );

      if (response.data.success) {
        setData((p) => ({
          ...p,
          mobileOtp: {
            ...p.mobileOtp,
            verified: true,
          },
        }));

        showToast("Mobile verified", "success");
      }
    } catch (err) {
      showToast(err.response?.data?.message, "error");
    }
  };

  const handleResendMobileOtp = async () => {
    try {
      const sessionId = localStorage.getItem("registrationSessionId");

      const response = await resendMobileOtp(sessionId);

      showToast(response.data.message, "success");
    } catch (err) {
      showToast(err.response?.data?.message, "error");
    }
  };

  const sendCorpEmailOtp = async () => {
    try {
      const sessionId = localStorage.getItem("registrationSessionId");

      const response = await sendEmailOtp(
        {
          companyEmail: data.corpEmail,
        },
        sessionId,
      );

      setData((p) => ({
        ...p,
        corpEmailOtp: {
          ...p.corpEmailOtp,
          sent: true,
        },
      }));

      showToast(response.data.message, "success");
    } catch (err) {
      showToast(err.response?.data?.message, "error");
    }
  };
  const verifyCorpEmailOtp = async () => {
    try {
      const sessionId = localStorage.getItem("registrationSessionId");

      const response = await verifyEmailOtp(
        {
          companyEmail: data.corpEmail,
          emailOtpCode: data.corpEmailOtp.userVal,
        },
        sessionId,
      );

      if (response.data.success) {
        setData((p) => ({
          ...p,
          corpEmailOtp: {
            ...p.corpEmailOtp,
            verified: true,
          },
        }));

        showToast("Email verified", "success");
      }
    } catch (err) {
      showToast(err.response?.data?.message, "error");
    }
  };

  const isGstnValid = !data.hasGst || data.gstn.trim().length === 15;
  const isStep2Valid =
    data.hasGst !== null &&
    !!data.industry &&
    (data.industry !== "Other" || !!data.customIndustry.trim());
  const isStep3Valid =
    !!data.legalName &&
    !!data.state &&
    !!data.city &&
    !!data.country &&
    PIN_REGEX.test(data.pincode) &&
    !!data.address &&
    !!data.natureOfCompany &&
    !!data.companyLocationType?.trim() &&
    data.placesInternationally !== null &&
    isGstnValid;
  const isStep4Valid =
    data.contactName &&
    data.designation &&
    isValidEmail(data.corpEmail) &&
    isValidMobile(data.mobile, data.countryCode) &&
    data.mobileOtp.verified &&
    data.corpEmailOtp.verified;
  const canGoStep2 = EMPLOYER_UI_PREVIEW_MODE || isStep2Valid;
  const canGoStep3 = EMPLOYER_UI_PREVIEW_MODE || isStep3Valid;
  const canGoStep4 = EMPLOYER_UI_PREVIEW_MODE || isStep4Valid;
  const canSubmit = EMPLOYER_UI_PREVIEW_MODE || step === 5;

  useEffect(() => {
    if (step === 4) {
      loadDocumentTypes();
    }
  }, [step]);

  useEffect(() => {
    const resume = async () => {
      const sessionId = localStorage.getItem("registrationSessionId");

      if (!sessionId) return;

      try {
        const response = await resumeRegistration(sessionId);

        if (!response.data.success) return;

        try {
          const session = response.data;
          console.log(response.data);
          // restore form values
          const step1 = session.step1Data || {};
          const step2 = session.step2Data || {};
          const step3 = session.step3Data || {};
          const step4 = session.step4Data || {};

          setData((p) => ({
            ...p,

            // STEP 1
            hasGst: step1.gstRegistered,
            industry: step1.industryType,

            // STEP 2
            legalName: step2.legalName || "",
            tradeName: step2.tradeName || "",
            companyLocationType: step2.companyLocationType || "",
            natureOfCompany: step2.natureOfCompany || "",
            placesInternationally:
              typeof step2.placesCandidatesInternationally === "boolean"
                ? step2.placesCandidatesInternationally
                : null,
            businessType: step2.businessType || "",
            companySize: step2.companySize || "",

            gstn: step2.gstn || "",
            pan: step2.pan || "",
            cin: step2.cin || "",

            state: step2.state || "",
            stateIso: getStateIso(
              getCountryIso(step2.country || ""),
              step2.state || ""
            ),
            city: step2.city || "",
            country: step2.country || "",
            countryIso: getCountryIso(step2.country || ""),
            pincode: step2.pincode || "",
            address: step2.addressLine1 || "",

            officialWebsite: step2.websiteUrl || "",

            companyLogo: step2.companyLogoUrl
              ? {
                name: step2.companyLogoUrl.split("/").pop(),
                url: step2.companyLogoUrl,
              }
              : null,

            // STEP 3
            contactName: step3.contactPersonName || "",
            designation: step3.designation || "",

            contactPersonEmail: step3.contactPersonEmail || "",

            corpEmail: step3.companyEmail || "",

            mobile: step3.mobileNumber || "",

            countryCode: step3.countryCode || "+91",

            profileSummary: step3.companyDescription || "",

            mobileOtp: {
              ...p.mobileOtp,
              sent: !!step3.mobileNumber,
              verified: step3.mobileVerified || false,
            },

            corpEmailOtp: {
              ...p.corpEmailOtp,
              sent: !!step3.companyEmail,
              verified: step3.companyEmailVerified || false,
            },
          }));
          // Restore uploaded mandatory & optional documents
          setSelectedDocuments(
            (step4.documents || [])
              .filter((d) => d.documentTypeId)
              .map((d) => ({
                documentTypeId: d.documentTypeId,
                file: {
                  name: d.documentName,
                  url: d.fileUrl,
                },
                fileUrl: d.fileUrl,
                status: d.status,
              }))
          );

          // Restore uploaded additional documents
          setAdditionalDocuments(
            (step4.documents || [])
              .filter((d) => !d.documentTypeId)
              .map((d) => ({
                file: {
                  name: d.documentName,
                  url: d.fileUrl,
                },
                fileUrl: d.fileUrl,
                status: d.status,
                documentName: d.documentName,
              }))
          );
          console.log("hasGst being set to", session.gstRegistered);
          // move to next step
          setStep(Math.min(session.stepStatus.lastCompletedStep + 1, 5));
        } finally {
          setLoadingResume(false);
        }
      } catch (err) {
        console.log("Resume failed", err);
      }
    };

    resume();
  }, []);
  const [attempt5, setAttempt5] = useState(false);
  const [mandatoryDocuments, setMandatoryDocuments] = useState([]);
  const [optionalDocuments, setOptionalDocuments] = useState([]);
  const [loadingDocuments, setLoadingDocuments] = useState(false);
  const [selectedDocuments, setSelectedDocuments] = useState([]);
  const [additionalDocuments, setAdditionalDocuments] = useState([]);
  const handleEmployerSubmit = async () => {
    setAttempt5(true);
    if (!termsAccepted) {
      showToast("Please accept the Terms of Service to continue.", "warning");
      return;
    }
    if (payStatus !== "success") {
      showToast("Please complete the registration fee payment first.", "error");
      return;
    }
    try {
      const sessionId = localStorage.getItem("registrationSessionId");

      const response = await submitRegistration({
        sessionId,
        consentGiven: termsAccepted,
        consentVersion: "1.0",
        // Required whenever the resolved plan has a price > 0 — omitting
        // these is what causes the backend to reject with "Payment
        // verification failed.", even though Razorpay itself succeeded.
        planId: paymentData.planId,
        razorpayOrderId: paymentData.razorpayOrderId,
        razorpayPaymentId: paymentData.razorpayPaymentId,
        razorpaySignature: paymentData.razorpaySignature,
        payPalOrderId: paymentData.payPalOrderId || null,
        region: isPayPal ? visitor.region : undefined,
        couponCode: couponApplied ? couponCode.trim().toUpperCase() : null,
      });

      if (response.data.success) {
        showToast("Registration completed", "success");

        router.push("/Login");
      } else {
        showToast(response.data.message || "Registration failed", "error");
      }
    } catch (err) {
      showToast(err.response?.data?.message || "Registration failed", "error");
    }
  };
  const loadDocumentTypes = async () => {
    try {
      setLoadingDocuments(true);

      const response = await getDocumentTypes();

      setMandatoryDocuments(
        response.data.mandatoryDocuments || []
      );

      setOptionalDocuments(
        response.data.optionalDocuments || []
      );

    } catch (err) {
      console.error(err);
      showToast(
        err?.response?.data?.message || "Failed to load document types",
        "error"
      );
    } finally {
      setLoadingDocuments(false);
    }
  };

  // ── PayPal (outside India) ─────────────────────────────────────
  // Latest values for the PayPal button callbacks, which are created once.
  payPalCtxRef.current = {
    selectedPlanId,
    couponApplied,
    couponCode,
    termsAccepted,
  };

  const payPalCreateOrder = async () => {
    const ctx = payPalCtxRef.current;
    const sessionId = localStorage.getItem("registrationSessionId");

    const res = await createPayPalMembershipOrder({
      sessionId,
      planId: ctx.selectedPlanId,
      couponCode: ctx.couponApplied ? ctx.couponCode.trim().toUpperCase() : null,
    });

    const order = res.data;

    if (!order?.success || !order.payPalOrderId) {
      throw new Error(order?.message || "Unable to create PayPal order.");
    }

    payPalOrderMetaRef.current = { planId: order.planId };
    return order.payPalOrderId;
  };

  const payPalOnApprove = async (approval) => {
    try {
      setPaying(true);
      const sessionId = localStorage.getItem("registrationSessionId");

      const res = await capturePayPalMembership({
        sessionId,
        payPalOrderId: approval.orderID,
      });

      if (!res.data?.success) {
        throw new Error(res.data?.message || "PayPal payment could not be confirmed.");
      }

      const paymentInfo = {
        planId: payPalOrderMetaRef.current.planId || payPalCtxRef.current.selectedPlanId,
        razorpayOrderId: "",
        razorpayPaymentId: "",
        razorpaySignature: "",
        payPalOrderId: approval.orderID,
      };

      setPaymentData(paymentInfo);
      setPayStatus("success");
      setPaymentMessage(`Payment successful. Reference: ${approval.orderID}`);
      setPaying(false);

      // Payment captured — complete registration right away.
      submitEmployerAfterPay(paymentInfo);
    } catch (err) {
      setPaying(false);
      const msg =
        err?.response?.data?.message ||
        err?.message ||
        "PayPal payment could not be confirmed.";
      setPaymentMessage(msg);
      showToast(msg, "error");
    }
  };

  // 100% coupon on the PayPal side: no payment needed, just register.
  const handleFreePayPalRegistration = () => {
    setPayStatus("success");
    submitEmployerAfterPay({
      planId: selectedPlanId,
      razorpayOrderId: "",
      razorpayPaymentId: "",
      razorpaySignature: "",
      payPalOrderId: "",
    });
  };

  // Money text for the coupon summary, e.g. ₹12,602 (or "USD 49.99").
  const fmtMoney = (n) =>
    `${currencyPrefix}${Number(n || 0).toLocaleString(
      payCurrency === "INR" ? "en-IN" : "en-US",
      { minimumFractionDigits: 0, maximumFractionDigits: 2 },
    )}`;

  // Take the coupon off again (also unlocks the plan cards).
  const handleRemoveCoupon = () => {
    if (paying || couponLoading) return;
    setCouponCode("");
    setCouponApplied(false);
    setCouponMessage("");
    setCouponDiscount(0);
    setCouponFinalAmount(null);
  };

  // Pick a membership plan (card click / keyboard). Changing the plan
  // resets any coupon that was applied to the previous one.
  const handleSelectPlan = (planId) => {
    if (paying || couponLoading || couponApplied) return;
    if (planId === selectedPlanId) return;

    setSelectedPlanId(planId);

    const selectedPlan = recruiterPlans.find((plan) => plan.planId === planId);
    setRecruiterPlan(selectedPlan || null);

    setCouponCode("");
    setCouponApplied(false);
    setCouponMessage("");
    setCouponDiscount(0);
    setCouponFinalAmount(null);
  };

  const isFreeWithCoupon = couponApplied && couponFinalAmount === 0;
  const showPayPalButtons =
    step === 5 &&
    isPayPal &&
    payPalReady &&
    payStatus !== "success" &&
    !!selectedPlanId &&
    !isFreeWithCoupon;

  useEffect(() => {
    if (!showPayPalButtons || !payPalContainerRef.current || !window.paypal) return;

    const buttons = window.paypal.Buttons({
      style: { layout: "vertical", shape: "rect", label: "pay" },
      onClick: (_d, actions) => {
        if (!payPalCtxRef.current.termsAccepted) {
          showToast("Please accept the Terms of Service to continue.", "warning");
          return actions.reject();
        }
        return actions.resolve();
      },
      createOrder: payPalCreateOrder,
      onApprove: payPalOnApprove,
      onCancel: () => setPaymentMessage("Payment window closed before completion."),
      onError: (err) => {
        console.error("PayPal error", err);
        const msg = err?.message || "PayPal payment failed. Please try again.";
        setPaymentMessage(msg);
        showToast(msg, "error");
      },
    });

    buttons.render(payPalContainerRef.current).catch((e) => {
      console.error("PayPal buttons render failed", e);
    });

    return () => {
      try {
        buttons.close();
      } catch (e) {
        /* already closed */
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showPayPalButtons, selectedPlanId, couponApplied]);

  const handleEmployerPay = async () => {
    try {
      setPaying(true);

      const key =
        process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID || "";

      if (typeof window === "undefined") {
        setPaying(false);
        return;
      }

      if (!window.Razorpay) {
        setPaying(false);
        setPaymentMessage(
          "Razorpay SDK missing."
        );
        return;
      }

      const region = "in"; // Razorpay (India) plans use region code "in"
      const sessionId = localStorage.getItem("registrationSessionId");

      // Uses the recruiter-specific order endpoint (resolves the active,
      // admin-configured Recruiter MembershipPlan server-side) — NOT
      // createCandidateOrder, which was creating an order for the
      // candidate plan/price instead of the employer registration fee.
      const orderResponse = await createMembershipOrder({
        sessionId,
        region,
        planId: selectedPlanId,
        couponCode: couponApplied
          ? couponCode.trim().toUpperCase()
          : null,
      });

      const order = orderResponse.data;

      if (!order.success) {
        setPaying(false);
        setPaymentMessage(
          order.message || "Unable to create payment order."
        );
        return;
      }

      const activeKey = order.razorpayKeyId || key;
      if (!activeKey) {
        setPaying(false);
        setPaymentMessage("Razorpay key missing.");
        return;
      }

      const options = {
        key: activeKey,
        amount: order.finalAmountPaise,
        currency: order.currency || "INR",
        name: "Job Box",
        description: "Employer Registration Fee",
        order_id: order.orderId,
        handler: function (response) {
          console.log("RAZORPAY RESPONSE", response);

          const paymentInfo = {
            // Echoed back on submit-registration so the amount can be
            // re-verified server-side against this exact plan.
            planId: order.planId,
            razorpayOrderId: response.razorpay_order_id || "",
            razorpayPaymentId: response.razorpay_payment_id,
            razorpaySignature: response.razorpay_signature || "",
          };

          setPaymentData(paymentInfo);
          setPayStatus("success");
          setPaymentMessage(
            `Payment successful. Reference: ${response.razorpay_payment_id}`
          );
          setPaying(false);

          // Payment succeeded — complete registration right away, passing
          // the payment fields straight through (React state set above
          // hasn't re-rendered yet at this point in the callback).
          submitEmployerAfterPay(paymentInfo);
        },
        prefill: {
          name: data.contactName,
          contact: data.mobile,
          email: data.corpEmail,
        },
        theme: {
          color: "#ff9900",
        },
        modal: {
          ondismiss: () => {
            setPaying(false);
            setPaymentMessage(
              "Payment window closed before completion."
            );
          },
        },
      };

      const rzp = new window.Razorpay(options);
      rzp.open();

    } catch (error) {
      console.error("Razorpay initialization error", error);
      setPaying(false);
      setPaymentMessage("Payment initialization failed.");
    }
  };

  // paymentOverride lets the Razorpay success handler pass the
  // just-received planId/razorpayOrderId/PaymentId/Signature straight
  // through, since React state (paymentData) hasn't re-rendered yet at
  // that point in the callback — same pattern used on the candidate side.
  const submitEmployerAfterPay = async (paymentOverride) => {
    try {
      const sessionId = localStorage.getItem("registrationSessionId");
      const payInfo = paymentOverride || paymentData;

      const region = "in"; // Razorpay (India) plans use region code "in"

      const response = await submitRegistration({
        sessionId,
        consentGiven: true,
        consentVersion: "1.0",

        planId: payInfo.planId,

        region: isPayPal ? visitor.region : region,

        payPalOrderId: payInfo.payPalOrderId || null,

        couponCode: couponApplied
          ? couponCode.trim().toUpperCase()
          : null,

        razorpayOrderId: payInfo.razorpayOrderId,
        razorpayPaymentId: payInfo.razorpayPaymentId,
        razorpaySignature: payInfo.razorpaySignature,
      });

      if (response.data.success) {
        showToast("Registration completed", "success");
        router.push("/Login");
      } else {
        showToast(response.data.message || "Registration failed", "error");
      }
    } catch (err) {
      showToast(err.response?.data?.message || "Registration failed", "error");
    }
  };

  const handleDocumentSelect = (documentTypeId, file) => {
    if (!file) return;

    setSelectedDocuments((prev) => {
      const existing = prev.find(
        (x) => x.documentTypeId === documentTypeId
      );

      if (existing) {
        return prev.map((x) =>
          x.documentTypeId === documentTypeId
            ? { ...x, file }
            : x
        );
      }

      return [
        ...prev,
        {
          documentTypeId,
          file,
        },
      ];
    });
  };
  const handleAdditionalDocument = (index, file) => {
    if (!file) return;

    setAdditionalDocuments((prev) =>
      prev.map((doc, i) =>
        i === index
          ? {
            ...doc,
            file,
          }
          : doc
      )
    );
  };

  const addAdditionalDocument = () => {
    setAdditionalDocuments((prev) => [
      ...prev,
      {
        file: null,
      },
    ]);
  };

  const removeAdditionalDocument = (index) => {
    setAdditionalDocuments((prev) =>
      prev.filter((_, i) => i !== index)
    );
  };
  const InfoRow = ({ label, val, mono }) => (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        padding: "7px 0",
        borderBottom: "0.5px solid var(--color-border-tertiary)",
        fontSize: "var(--font-sm)",
      }}
    >
      <span style={{ color: "var(--color-text-secondary)" }}>{label}</span>
      <span
        style={{
          fontFamily: mono ? "monospace" : undefined,
          fontWeight: 500,
          textAlign: "right",
          maxWidth: "55%",
        }}
      >
        {val || "—"}
      </span>
    </div>
  );

  const handleStep1 = async () => {
    try {
      const response = await gstCheck({
        gstRegistered: data.hasGst,
        industryType:
          data.industry === "Other" ? data.customIndustry.trim() : data.industry,
      });

      if (response.data.success) {
        localStorage.setItem(
          "registrationSessionId",
          response.data.registrationSessionId,
        );

        setStep(2);
      }
    } catch (err) {
      showToast(err.response?.data?.message || "Something went wrong", "error");
    }
  };
  // ── Step 1: GST Selector ──────────────────
  const renderStep1 = () => (
    <div>
      <h3
        style={{
          fontSize: "var(--font-md)",
          fontWeight: 600,
          marginBottom: 6,
          color: "var(--color-text-primary)",
        }}
      >
        Is your company GST registered?
      </h3>
      <p
        style={{
          fontSize: "var(--font-sm)",
          color: "var(--color-text-secondary)",
          marginBottom: 20,
        }}
      >
        GST-registered companies get auto-filled details and a verified badge.
      </p>
      <div style={{ display: "flex", gap: 14, marginBottom: 20 }}>
        {[
          {
            val: true,
            icon: "✓",
            title: "Yes, GST Registered",
            sub: "GSTN → auto-fills all company details • No security deposit",
          },
          {
            val: false,
            icon: "—",
            title: "No, not registered",
            sub: "Manual entry required",
          },
        ].map((opt) => (
          <div
            key={String(opt.val)}
            onClick={() => set("hasGst", opt.val)}
            style={{
              flex: 1,
              padding: "18px 16px",
              borderRadius: 10,
              cursor: "pointer",
              border:
                data.hasGst === opt.val
                  ? "2px solid #ff9900"
                  : attempt1 && data.hasGst === null
                    ? "1px solid #E24B4A"
                    : "0.5px solid var(--color-border-secondary)",
              background:
                data.hasGst === opt.val
                  ? "#ffffff"
                  : "var(--color-background-primary)",
              transition: "all .15s",
            }}
          >
            <div style={{ fontSize: "var(--font-h6)", marginBottom: 8 }}>
              {opt.icon}
            </div>
            <div
              style={{
                fontSize: "var(--font-sm)",
                fontWeight: 600,
                marginBottom: 4,
                color: "var(--color-text-primary)",
              }}
            >
              {opt.title}
            </div>
            <div
              style={{
                fontSize: "var(--font-xs)",
                color: "var(--color-text-secondary)",
                lineHeight: 1.5,
              }}
            >
              {opt.sub}
            </div>
          </div>
        ))}
      </div>

      {data.hasGst === false && (
        <Alert type="warning">
          <strong>Non-GST entities:</strong> No registration fee for non-GST
          companies.
        </Alert>
      )}

      {attempt1 && data.hasGst === null && (
        <p style={{ fontSize: "var(--font-xs)", color: "#E24B4A", marginTop: -12, marginBottom: 16, fontWeight: 500 }}>
          Please select whether your company is GST registered.
        </p>
      )}

      <Field
        label="Industry Type"
        required
        hint="Start typing to search, or pick from the list — you can also enter your own industry."
        error={attempt1 && !data.industry ? "Industry type is required" : null}
      >
        <Combobox
          value={data.industry}
          onChange={(v) => set("industry", v)}
          options={industryOptions}
          placeholder="Type or select your industry (e.g. IT Services, Manufacturing)"
          error={attempt1 && !data.industry}
        />
      </Field>

      {data.industry === "Other" && (
        <Field
          label="Please specify your industry"
          required
          error={
            attempt1 && !data.customIndustry.trim()
              ? "Please specify your industry"
              : null
          }
        >
          <Input
            value={data.customIndustry}
            error={attempt1 && !data.customIndustry.trim()}
            onChange={(e) => set("customIndustry", e.target.value)}
            placeholder="Enter your industry (e.g. Aerospace, Textile)"
          />
        </Field>
      )}

      <div
        style={{ display: "flex", justifyContent: "flex-end", marginTop: 8 }}
      >
        <Btn
          variant="primary"
          onClick={() => {
            setAttempt1(true);
            if (data.hasGst === null || !data.industry.trim()) return;
            if (data.industry === "Other" && !data.customIndustry.trim()) return;
            handleStep1();
          }}
        >
          Continue →
        </Btn>
      </div>
    </div>
  );

  const handleStep2 = async () => {
    try {
      const sessionId = localStorage.getItem("registrationSessionId");

      const formData = new FormData();

      formData.append("legalName", data.legalName);
      formData.append("tradeName", data.tradeName);
      formData.append("businessType", data.businessType);
      formData.append("companySize", data.companySize);
      formData.append("cin", data.cin);
      formData.append("state", data.state);
      formData.append("city", data.city);
      formData.append("country", data.country || "India");
      formData.append("pincode", data.pincode);
      formData.append("addressLine1", data.address);
      formData.append("websiteUrl", data.officialWebsite);
      formData.append("gstn", data.gstn);
      formData.append("pan", data.pan);
      formData.append("natureOfCompany", data.natureOfCompany);
      formData.append(
        "placesCandidatesInternationally",
        data.placesInternationally === true ? "true" : "false"
      );
      formData.append(
        "companyLocationType",
        data.companyLocationType || ""
      );
      formData.append("companyDisplayName", data.tradeName || data.legalName);

      formData.append("addressLine2", "");

      formData.append(
        "industryType",
        data.industry === "Other" ? data.customIndustry.trim() : data.industry
      );

      formData.append("gstnRegistrationDate", data.gstRegDate);

      if (data.companyLogo) formData.append("companyLogo", data.companyLogo);

      const response = await saveCompanyDetails(formData, sessionId);

      if (response.data.success) {
        if (data.industry === "Other" && data.customIndustry.trim()) {
          try {
            await submitIndustrySuggestion({
              field: "industry",
              suggestedName: data.customIndustry.trim(),
              note: "Suggested other Industry Type during registration",
              submittedByName: data.contactName || "Recruiter",
              submittedByEmail: data.contactPersonEmail || data.corpEmail || "",
            });
          } catch (suggestionErr) {
            console.error("Failed to submit industry suggestion:", suggestionErr);
          }
        }
        setStep(3);
      }
    } catch (err) {
      showToast(err.response?.data?.message, "error");
    }
  };
  // ── Step 2: Company Details ───────────────
  const renderStep2 = () => (
    <div>
      <h3
        style={{
          fontSize: "var(--font-md)",
          fontWeight: 600,
          marginBottom: 16,
          color: "var(--color-text-primary)",
        }}
      >
        Company details
      </h3>

      {/* GST fields only for GST-registered employers */}
      {data.hasGst ? (
        <>
          <Alert type="info">
            ⚡ Enter your GSTN and click <strong>Auto-fill</strong> — our OCR
            will fetch legal name, trade name, PAN, address, and registration
            date automatically.
          </Alert>
          <Field
            label="GSTN"
            required
            hint="15-character alphanumeric GST number"
            error={
              attempt2 && data.hasGst && !isGstnValid
                ? "GSTN must be exactly 15 characters"
                : attempt2 &&
                  data.hasGst &&
                  data.gstn.length === 15 &&
                  !GSTIN_REGEX.test(data.gstn)
                  ? "This doesn't look like a valid GSTN format — please double-check"
                  : null
            }
          >
            <div style={{ display: "flex", gap: 8 }}>
              <Input
                value={data.gstn}
                onChange={(e) => set("gstn", e.target.value.toUpperCase())}
                placeholder="Enter your 15-character GSTN (e.g. 27AAPFU0939F1ZV)"
                maxLength={15}
                error={attempt2 && data.hasGst && !isGstnValid}
                style={{ fontFamily: "monospace", flex: 1 }}
              />
              <Btn
                variant="primary"
                disabled={data.gstn.length < 15 || ocrLoading}
                onClick={autoFillGst}
                style={{ flexShrink: 0, whiteSpace: "nowrap" }}
              >
                {ocrLoading ? "Fetching…" : "Auto-fill →"}
              </Btn>
            </div>
          </Field>
          <div
            style={{
              height: 0.5,
              background: "var(--color-border-tertiary)",
              margin: "16px 0",
            }}
          />
        </>
      ) : (
        <Alert type="warning">
          Manual entry mode — fill in your company details below.
        </Alert>
      )}

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
        <Field
          label="Legal / Company Name"
          required
          error={attempt2 && !data.legalName ? "Legal / company name is required" : null}
        >
          <Input
            value={data.legalName}
            error={attempt2 && !data.legalName}
            onChange={(e) => set("legalName", e.target.value)}
            placeholder="Enter your registered company name (e.g. Acme Pvt. Ltd.)"
            style={{
              background: data.hasGst && data.legalName ? "#ffffff" : undefined,
            }}
          />
        </Field>
        <Field label="Trade Name" hint="Brand / display name">
          <Input
            value={data.tradeName}
            onChange={(e) => set("tradeName", e.target.value)}
            placeholder="Enter your brand/trade name (e.g. Acme)"
          />
        </Field>

        {/* PAN only for GST employers (pre-filled from GSTN) */}
        {data.hasGst && (
          <Field label="PAN" hint="Auto-filled from GSTN for GST users">
            <Input
              value={data.pan}
              onChange={(e) => set("pan", e.target.value.toUpperCase())}
              placeholder="Enter your 10-character PAN (e.g. AAPFU0939F)"
              maxLength={10}
              style={{
                fontFamily: "monospace",
                background: data.pan ? "#ffffff" : undefined,
              }}
            />
          </Field>
        )}

        <Field
          label="Business Type"
          hint="Start typing to search, or pick from the list"
        >
          <Combobox
            value={data.businessType}
            onChange={(v) => set("businessType", v)}
            options={BUSINESS_TYPES}
            placeholder="Type or select business type (e.g. Private Limited)"
          />
        </Field>
        {data.hasGst && (
          <Field label="GST Registration Date" hint="Auto-filled for GST users">
            <Input
              type="date"
              value={data.gstRegDate}
              onChange={(e) => set("gstRegDate", e.target.value)}
              style={{ background: data.gstRegDate ? "#ffffff" : undefined }}
            />
          </Field>
        )}
        <Field label="Company Size">
          <Combobox
            value={data.companySize}
            onChange={(v) => set("companySize", v)}
            options={COMPANY_SIZES}
            placeholder="Type or select company size (e.g. 51-200 employees)"
          />
        </Field>
        <Field label="Company Type">
          <Combobox
            value={data.companyType}
            onChange={(v) => set("companyType", v)}
            options={COMPANY_TYPES}
            placeholder="Type or select company type (e.g. Product-based)"
          />
        </Field>

        {/* ── Nature of Company ─────────────────────────
            Drives which licence uploads show as required on the
            Licences step (see requiredDocumentNames below). */}
        <Field
          label="Nature of Company"
          error={
            attempt2 && !data.natureOfCompany
              ? "Please select the nature of your company"
              : null
          }
        >
          <Combobox
            value={data.natureOfCompany}
            onChange={(v) => set("natureOfCompany", v)}
            options={NATURE_OF_COMPANY_OPTIONS}
            placeholder="Select nature of company"
          />
        </Field>

        {data.natureOfCompany === "RecruitmentAgency" && (
          <Alert type="info">
            As a Recruitment Agency you'll need to upload your{" "}
            <strong>Certificate of Incorporation</strong> and{" "}
            <strong>Recruitment License</strong> on the next Licences step.
          </Alert>
        )}



        <Field
          label="Company Location Type"
          required
          error={
            attempt2 && !data.companyLocationType
              ? "Please select company location type"
              : null
          }
        >
          <Select
            value={data.companyLocationType}
            onChange={(e) =>
              set("companyLocationType", e.target.value)
            }
            error={attempt2 && !data.companyLocationType}
          >
            <option value="">Select Location Type</option>
            <option value="Onshore">Onshore</option>
            <option value="Offshore">Offshore</option>
          </Select>
        </Field>




        {/* ── International placement ───────────────────
            Asked regardless of Nature of Company — both a Recruitment
            Agency and a direct Employer can place candidates abroad. */}
        <Field
          label="Do you place candidates internationally?"
          error={
            attempt2 && data.placesInternationally === null
              ? "Please answer this question"
              : null
          }
        >
          <div style={{ display: "flex", gap: 10 }}>
            <Btn
              type="button"
              variant={data.placesInternationally === true ? "primary" : "outline"}
              style={{ flex: 1 }}
              onClick={() => set("placesInternationally", true)}
            >
              Yes
            </Btn>
            <Btn
              type="button"
              variant={data.placesInternationally === false ? "primary" : "outline"}
              style={{ flex: 1 }}
              onClick={() => set("placesInternationally", false)}
            >
              No
            </Btn>
          </div>
        </Field>

        {getLicenceRule(data.companyLocationType, data.country) === "onshoreAbroad" && (
          <Alert type="info">
            Since your company is <strong>Onshore outside India</strong>, you'll
            need to upload your <strong>POE License</strong> on the Licences
            step.
          </Alert>
        )}

        {getLicenceRule(data.companyLocationType, data.country) === "offshore" && (
          <Alert type="info">
            Since your company is <strong>Offshore</strong>, you'll need to
            upload either your <strong>RPSL License</strong> or your{" "}
            <strong>Registration Certificate</strong> on the Licences step. A
            POE License is not required.
          </Alert>
        )}

        {/* GST Registration Date only for GST employers */}


        <Field label="CIN" hint="Company Identification Number (if applicable)">
          <Input
            value={data.cin}
            onChange={(e) => set("cin", e.target.value.toUpperCase())}
            placeholder="Enter your CIN, if applicable (e.g. U74999MH2018PTC123456)"
            style={{ fontFamily: "monospace" }}
          />
        </Field>
      </div>

      <div
        style={{
          height: 0.5,
          background: "var(--color-border-tertiary)",
          margin: "8px 0 16px",
        }}
      />
      <p
        style={{
          fontSize: "var(--font-xs)",
          fontWeight: 600,
          color: "var(--color-text-secondary)",
          marginBottom: 14,
        }}
      >
        Registered Address
      </p>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
        <Field
          label="Country"
          required
          error={attempt2 && !data.country ? "Country is required" : null}
        >
          <Combobox
            value={data.country}
            error={attempt2 && !data.country}
            onChange={(v) => {
              const iso = getCountryIso(v);
              setData((p) => ({
                ...p,
                country: v,
                countryIso: iso,
                // Changing the country invalidates whatever state/city was
                // previously picked for a different country.
                state: "",
                stateIso: "",
                city: "",
              }));
            }}
            options={COUNTRY_NAMES}
            placeholder="Type or select your country (e.g. India)"
          />
        </Field>
        <Field
          label="State"
          required
          error={attempt2 && !data.state ? "State is required" : null}
        >
          <Combobox
            value={data.state}
            error={attempt2 && !data.state}
            disabled={!data.countryIso}
            onChange={(v) => {
              const iso = getStateIso(data.countryIso, v);
              setData((p) => ({
                ...p,
                state: v,
                stateIso: iso,
                city: "",
              }));
            }}
            options={getStateNamesForCountry(data.countryIso)}
            placeholder={
              data.countryIso
                ? "Type or select your state (e.g. Maharashtra)"
                : "Select a country first"
            }
          />
        </Field>
        <Field
          label="City"
          required
          error={attempt2 && !data.city ? "City is required" : null}
        >
          <Combobox
            value={data.city}
            error={attempt2 && !data.city}
            disabled={!data.stateIso}
            onChange={(v) => set("city", v)}
            options={getCityNamesForState(data.countryIso, data.stateIso)}
            placeholder={
              data.stateIso
                ? "Type or select your city (e.g. Mumbai)"
                : "Select a state first"
            }
          />
        </Field>
        <Field
          label="PIN Code"
          required
          error={
            attempt2 && !data.pincode
              ? "PIN code is required"
              : attempt2 && !PIN_REGEX.test(data.pincode)
                ? "Enter a valid 6-digit PIN code"
                : null
          }
        >
          <Input
            value={data.pincode}
            maxLength={6}
            error={attempt2 && !PIN_REGEX.test(data.pincode)}
            onChange={(e) => set("pincode", e.target.value.replace(/\D/g, ""))}
            placeholder="Enter your 6-digit PIN code (e.g. 400001)"
            style={{
              background: data.hasGst && data.pincode ? "#ffffff" : undefined,
            }}
          />
        </Field>
        <Field
          label="Full Registered Address"
          required
          error={attempt2 && !data.address ? "Full registered address is required" : null}
        >
          <Input
            value={data.address}
            error={attempt2 && !data.address}
            onChange={(e) => set("address", e.target.value)}
            placeholder="Enter your full registered address (e.g. 4th Floor, Business Park, Andheri, Mumbai, MH, 400001)"
            style={{
              background: data.hasGst && data.address ? "#ffffff" : undefined,
            }}
          />
        </Field>

        <Field label="Official Website">
          <Input
            value={data.officialWebsite}
            onChange={(e) => set("officialWebsite", e.target.value)}
            placeholder="Enter your company website (e.g. https://www.company.com)"
          />
        </Field>
      </div>


      <Field label="Company Logo">
        <div
          onClick={() => logoRef.current?.click()}
          style={{
            border: "1px dashed var(--color-border-secondary)",
            borderRadius: 8,
            padding: "20px",
            textAlign: "center",
            cursor: "pointer",
            background: "var(--color-background-secondary)",
          }}
        >
          {data.companyLogo ? (
            <p
              style={{
                fontSize: "var(--font-sm)",
                color: "#3B6D11",
                fontWeight: 600,
              }}
            >
              ✓ {data.companyLogo.name}
            </p>
          ) : (
            <>
              <p
                style={{
                  fontSize: "var(--font-sm)",
                  color: "var(--color-text-secondary)",
                }}
              >
                Click to upload logo
              </p>
              <p
                style={{
                  fontSize: "var(--font-xs)",
                  color: "var(--color-text-tertiary)",
                  marginTop: 4,
                }}
              >
                Any image format · Max 2 MB · Recommended 200×200px
              </p>
            </>
          )}
        </div>
        <input
          ref={logoRef}
          type="file"
          accept="image/*"
          style={{ display: "none" }}
          onChange={(e) => set("companyLogo", e.target.files?.[0] ?? null)}
        />
      </Field>

      {data.hasGst && data.legalName && (
        <Alert type="success">
          ✓ Company details auto-filled from GSTN via OCR. Highlighted fields
          are editable.
        </Alert>
      )}

      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          marginTop: 8,
        }}
      >
        <Btn variant="outline" onClick={() => setStep(1)}>
          ← Back
        </Btn>
        <Btn
          variant="primary"
          disabled={ocrLoading}
          onClick={() => {
            setAttempt2(true);
            if (!isStep3Valid) return;
            handleStep2();
          }}
        >
          Continue →
        </Btn>
      </div>
    </div>
  );

  const saveStep3 = async () => {
    try {
      const sessionId = localStorage.getItem("registrationSessionId");

      const response = await saveContactDetails(
        {
          contactPersonName: data.contactName,
          designation: data.designation,
          contactPersonEmail: data.contactPersonEmail,
          companyEmail: data.corpEmail,
          mobileNumber: data.mobile,
          countryCode: data.countryCode,
          companyDescription: data.profileSummary,
        },
        sessionId,
      );

      if (response.data.success) {
        showToast(response.data.message, "success");
        return true;
      }

      showToast(
        response.data.message || "Could not save contact details. Please try again.",
        "error",
      );
      return false;
    } catch (err) {
      showToast(
        err.response?.data?.message || "Could not save contact details. Please try again.",
        "error",
      );
      return false;
    }
  };


  const handleResendEmailOtp = async () => {
    try {
      const sessionId = localStorage.getItem("registrationSessionId");

      const response = await resendEmailOtp(sessionId);

      showToast(response.data.message, "success");
    } catch (err) {
      showToast(err.response?.data?.message, "error");
    }
  };
  // ── Step 3: Contact & OTP ─────────────────
  const renderStep3 = () => {
    const contactEmailTouched = data.contactPersonEmail.length > 0;
    const contactEmailValid = isValidEmail(data.contactPersonEmail);
    const corpEmailTouched = data.corpEmail.length > 0;
    const corpEmailValid = isValidEmail(data.corpEmail);

    return (
      <div>
        <h3
          style={{
            fontSize: "var(--font-md)",
            fontWeight: 600,
            marginBottom: 16,
            color: "var(--color-text-primary)",
          }}
        >
          Contact details & verification
        </h3>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
          <Field
            label="Contact Person Name"
            required
            error={attempt3 && !data.contactName ? "Contact person name is required" : null}
          >
            <Input
              value={data.contactName}
              error={attempt3 && !data.contactName}
              onChange={(e) => set("contactName", e.target.value)}
              placeholder="Enter contact person's full name (e.g. Arjun Mehta)"
            />
          </Field>
          <Field
            label="Designation"
            required
            error={attempt3 && !data.designation ? "Designation is required" : null}
          >
            <Input
              value={data.designation}
              error={attempt3 && !data.designation}
              onChange={(e) => set("designation", e.target.value)}
              placeholder="Enter their designation/role (e.g. HR Manager)"
            />
          </Field>
          {/* <Field
            label="Contact Person Email"
            required
            error={
              contactEmailTouched && !contactEmailValid
                ? "Enter a valid email address"
                : null
            }
          >
            <Input
              type="email"
              value={data.contactPersonEmail}
              error={contactEmailTouched && !contactEmailValid}
              onChange={(e) => {
                const val = e.target.value;
                if (val && /^\d+$/.test(val.trim())) return;
                set("contactPersonEmail", val.trim());
              }}
              placeholder="Enter contact person's email (e.g. contact@personal.com)"
            />
          </Field> */}
        </div>

        <Field
          label="Company Email"
          required
          hint="You'll use this email to log in to your account"
          error={
            corpEmailTouched && !corpEmailValid
              ? "Enter a valid company email address"
              : null
          }
        >
          <Input
            type="email"
            value={data.corpEmail}
            error={corpEmailTouched && !corpEmailValid && !data.corpEmailOtp.verified}
            disabled={data.corpEmailOtp.verified}
            onChange={(e) => {
              const val = e.target.value;
              if (val && /^\d+$/.test(val.trim())) return;
              set("corpEmail", val.trim());
            }}
            placeholder="Enter your official company email (e.g. hr@yourcompany.com)"
            style={{
              borderColor: data.corpEmailOtp.verified ? "#3B6D11" : undefined,
              backgroundColor: data.corpEmailOtp.verified ? "#f4f9f1" : undefined,
              color: data.corpEmailOtp.verified ? "#2b4e0c" : undefined,
              border: data.corpEmailOtp.verified ? "1px solid #3B6D11" : undefined,
            }}
          />

          {data.corpEmail && corpEmailValid && (
            <div style={{ marginTop: 8 }}>
              <OtpBlock
                target="corporate email"
                sent={data.corpEmailOtp.sent}
                verified={data.corpEmailOtp.verified}
                disabled={!corpEmailValid}
                onSend={sendCorpEmailOtp}
                onResend={handleResendEmailOtp}
                onVerify={verifyCorpEmailOtp}
                otpVal={data.corpEmailOtp.userVal}
                setOtpVal={(v) =>
                  setData((p) => ({
                    ...p,
                    corpEmailOtp: { ...p.corpEmailOtp, userVal: v.replace(/\D/g, "") },
                  }))
                }
              />
            </div>
          )}
        </Field>

        <Field label="Mobile Number" required>
          <MobileOtpField
            countryCode={data.countryCode}
            onCountryCodeChange={(v) => set("countryCode", v)}
            mobile={data.mobile}
            onMobileChange={(v) => set("mobile", v)}
            otp={data.mobileOtp}
            onOtpStateChange={(v) => setData((p) => ({ ...p, mobileOtp: v }))}
            sendMobileOtp={handleSendMobileOtp}
            verifyMobileOtp={handleVerifyMobileOtp}
            resendMobileOtp={handleResendMobileOtp}
          />
        </Field>

        <Field
          label="Company Profile Summary"
          hint="Brief description of your company and hiring focus (shown on job listings)"
        >

          <textarea
            className="form-control"
            value={data.profileSummary}
            onChange={(e) => set("profileSummary", e.target.value)}
            placeholder="e.g. We are a leading marine services company specialising in offshore and vessel crew placement."
            style={{
              minHeight: "150px",
              resize: "vertical",
            }}
          />
        </Field>

        {attempt3 && !isStep4Valid && (
          <Alert type="error">
            Please complete all required fields and verify both your mobile
            number and company email before continuing.
          </Alert>
        )}

        <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8 }}>
          <Btn variant="outline" onClick={() => setStep(2)}>
            ← Back
          </Btn>
          <Btn
            variant="primary"
            onClick={async () => {
              setAttempt3(true);
              if (!isStep4Valid) return;
              const ok = await saveStep3();
              if (ok) setStep(4);
            }}
          >
            Continue →
          </Btn>
        </div>
      </div>
    );
  };


  const [attempt4, setAttempt4] = useState(false);

  // ── Which document names are "required" for this registrant ──────
  // Certificate of Incorporation is required for everyone (it's also
  // seeded as globally mandatory at the master-data level, so it always
  // lands in mandatoryDocuments regardless of this list). Recruitment
  // License only applies to a Recruitment Agency. POE/RPSL only apply
  // once the registrant has said they place candidates internationally
  // — true for either nature of company. Matching is by exact document
  // name against what Admin has configured under Admin > Recruiters >
  // Document Types (see DOC_NAME_* constants above).

  const licenceRule = getLicenceRule(data.companyLocationType, data.country);

  const requiredDocumentNames = useMemo(() => {
    const names = [DOC_NAME_INCORPORATION];

    if (data.natureOfCompany === "RecruitmentAgency") {
      names.push(DOC_NAME_RECRUITMENT_LICENSE);
    }

    // Onshore outside India: POE License (RPSL not applicable).
    if (licenceRule === "onshoreAbroad") {
      names.push(DOC_NAME_POE_LICENSE);
    }

    // Offshore: RPSL License OR Registration Certificate (POE not
    // applicable). This either/or requirement is handled separately by
    // oneOfRequiredNames / missingRequiredDocumentNames.

    return names;
  }, [
    data.natureOfCompany,
    licenceRule,
  ]);

  // Offshore: at least ONE of these must be uploaded.
  const oneOfRequiredNames = useMemo(
    () =>
      licenceRule === "offshore"
        ? [DOC_NAME_RPSL_LICENSE, DOC_NAME_REGISTRATION_CERTIFICATE]
        : [],
    [licenceRule]
  );

  // Licences that don't apply to this company are hidden (and never
  // uploaded): RPSL for Onshore-outside-India, POE for Offshore.
  const isHiddenDocument = (documentName) =>
    (licenceRule === "onshoreAbroad" && documentName === DOC_NAME_RPSL_LICENSE) ||
    (licenceRule === "offshore" && documentName === DOC_NAME_POE_LICENSE);

  const visibleMandatoryDocuments = mandatoryDocuments.filter(
    (d) => !isHiddenDocument(d.documentName)
  );
  const visibleOptionalDocuments = optionalDocuments.filter(
    (d) => !isHiddenDocument(d.documentName)
  );




  const missingRequiredDocumentNames = useMemo(() => {
    const allDocuments = [...mandatoryDocuments, ...optionalDocuments];

    const findDocument = (documentName) =>
      allDocuments.find((d) => d.documentName === documentName);

    const isDocumentSelected = (documentName) => {
      const doc = findDocument(documentName);

      return !!doc && selectedDocuments.some(
        (x) => x.documentTypeId === doc.documentTypeId
      );
    };

    // Preserve the existing incorporation and recruitment-agency rules.
    // Apply POE/RPSL requirements separately according to location.
    const missing = requiredDocumentNames
      .filter(
        (name) =>
          name !== DOC_NAME_POE_LICENSE &&
          name !== DOC_NAME_RPSL_LICENSE
      )
      .filter((name) => !isDocumentSelected(name));

    if (licenceRule === "onshoreAbroad") {
      if (!isDocumentSelected(DOC_NAME_POE_LICENSE)) {
        missing.push(DOC_NAME_POE_LICENSE);
      }
    }

    if (licenceRule === "offshore") {
      const rpslDoc = findDocument(DOC_NAME_RPSL_LICENSE);
      const registrationDoc = findDocument(
        DOC_NAME_REGISTRATION_CERTIFICATE
      );

      const hasRpsl = isDocumentSelected(DOC_NAME_RPSL_LICENSE);
      const hasRegistrationCertificate = isDocumentSelected(
        DOC_NAME_REGISTRATION_CERTIFICATE
      );

      if (!hasRpsl && !hasRegistrationCertificate) {
        if (!rpslDoc && !registrationDoc) {
          missing.push(
            `${DOC_NAME_RPSL_LICENSE} or ${DOC_NAME_REGISTRATION_CERTIFICATE} (configure one in Admin)`
          );
        } else {
          missing.push(
            `${DOC_NAME_RPSL_LICENSE} or ${DOC_NAME_REGISTRATION_CERTIFICATE}`
          );
        }
      }
    }

    return [...new Set(missing)];
  }, [
    requiredDocumentNames,
    mandatoryDocuments,
    optionalDocuments,
    selectedDocuments,
    licenceRule,
  ]);


  const handleStep4 = async () => {
    try {
      // Soft-mandatory, consistent with how registration already treats
      // documents (Step 4 is optional server-side — SubmitRegistrationAsync
      // does not block submission on missing uploads). We still warn here
      // rather than silently letting the recruiter continue, so the
      // Nature of Company / international answers actually mean something
      // instead of just being decorative text on Step 2.
      if (missingRequiredDocumentNames.length > 0 && !attempt4) {
        setAttempt4(true);
        showToast(
          `Please upload: ${missingRequiredDocumentNames.join(", ")} — or click Continue again to skip and upload later.`,
          "warning"
        );
        return;
      }

      const sessionId = localStorage.getItem("registrationSessionId");

      // Drop licences that don't apply to this company (e.g. the user picked
      // a POE file, then switched the company to Offshore).
      const hiddenDocumentTypeIds = new Set(
        [...mandatoryDocuments, ...optionalDocuments]
          .filter((d) => isHiddenDocument(d.documentName))
          .map((d) => d.documentTypeId)
      );

      const documents = [
        ...selectedDocuments.filter(
          (x) =>
            x.file instanceof File &&
            !hiddenDocumentTypeIds.has(x.documentTypeId)
        ),

        ...additionalDocuments
          .filter((x) => x.file instanceof File)
          .map((x) => ({
            documentTypeId: null,
            category: "Additional",
            file: x.file,
          })),
      ];

      const response = await uploadDocuments(
        documents,
        sessionId
      );

      if (response.data.success) {
        showToast(response.data.message, "success");
        setStep(5);
      }
    } catch (err) {
      showToast(
        err?.response?.data?.message || "Document upload failed.",
        "error"
      );
    }
  };

  const renderStep4 = () => (
    <div>
      <h3
        style={{
          fontSize: "var(--font-md)",
          fontWeight: 600,
          marginBottom: 4,
          color: "var(--color-text-primary)",
        }}
      >
        Licence & document upload
      </h3>
      <p
        style={{
          fontSize: "var(--font-sm)",
          color: "var(--color-text-secondary)",
          marginBottom: 20,
          lineHeight: 1.5,
        }}
      >
        Upload all mandatory company documents to complete your registration.
        You may also upload optional documents to strengthen your company profile.
      </p>


      <Alert type="info">
        Based on your company details:
        <ul style={{ marginBottom: 0, paddingLeft: 20 }}>
          <li>Certificate of Incorporation is required.</li>
          {data.natureOfCompany === "RecruitmentAgency" && (
            <li>Recruitment License is required.</li>
          )}
          {licenceRule === "onshoreAbroad" && (
            <li>POE License is required for Onshore companies outside India.</li>
          )}
          {licenceRule === "offshore" && (
            <li>
              Upload either an RPSL License or a Registration Certificate
              (POE License is not required for Offshore companies).
            </li>
          )}
          {licenceRule === "default" && (
            <li>
              POE and RPSL licences are optional for Onshore companies in India.
            </li>
          )}
        </ul>
      </Alert>


      <div style={{ marginTop: 12 }}>
        <Alert type="info">
          <strong>Blue Tick</strong> requires: GST Verified + one active licence +
          corporate domain email — all simultaneously.
        </Alert>
      </div>



      <div
        style={{
          marginTop: 12,
          marginBottom: 14,
          display: "inline-flex",
          alignItems: "center",
          gap: 8,
          padding: "8px 12px",
          borderRadius: 8,
          border: "1px solid rgba(255,163,0,.32)",
          background: "#fff8ee",
          color: "#8a5a00",
          fontSize: "var(--font-xs)",
          fontWeight: 600,
        }}
      >
        <i className="fi fi-rr-lock" />
        Documents uploaded for verification are private and are not shared with
        candidates.
      </div>

      <div
        style={{
          display: "grid",
          gap: 20,
          marginBottom: 20,
        }}
      >
        {loadingDocuments ? (
          <p>Loading documents...</p>
        ) : (
          <>
            <div>
              <h5 style={{ marginBottom: 15 }}>
                Mandatory Documents
              </h5>

              {visibleMandatoryDocuments.map((doc) => {
                const selected = selectedDocuments.find(
                  (x) => x.documentTypeId === doc.documentTypeId
                );

                return (
                  <div
                    key={doc.documentTypeId}
                    style={{ marginBottom: 18 }}
                  >
                    <label
                      style={{
                        display: "block",
                        marginBottom: 8,
                        fontWeight: 600,
                      }}
                    >
                      {doc.documentName}
                    </label>

                    <input
                      type="file"
                      className="form-control"
                      accept=".pdf,.jpg,.jpeg,.png"
                      onChange={(e) =>
                        handleDocumentSelect(
                          doc.documentTypeId,
                          e.target.files?.[0]
                        )
                      }
                    />

                    {selected && (
                      <small
                        style={{
                          color: "#3B6D11",
                          display: "block",
                          marginTop: 6,
                        }}
                      >
                        ✓ {selected.file.name}
                      </small>
                    )}
                  </div>
                );
              })}
            </div>

            {visibleOptionalDocuments.length > 0 && (
              <div>
                <hr />

                <h5 style={{ marginBottom: 15 }}>
                  Optional Documents
                </h5>

                {visibleOptionalDocuments.map((doc) => {
                  const selected = selectedDocuments.find(
                    (x) => x.documentTypeId === doc.documentTypeId
                  );

                  const isOneOfRequired = oneOfRequiredNames.includes(
                    doc.documentName
                  );
                  const isConditionallyRequired =
                    requiredDocumentNames.includes(doc.documentName) ||
                    isOneOfRequired;

                  // For either/or documents (Offshore: RPSL or Registration
                  // Certificate) it is only "missing" if NONE of them is chosen.
                  const anyOneOfSelected =
                    isOneOfRequired &&
                    optionalDocuments.some(
                      (d) =>
                        oneOfRequiredNames.includes(d.documentName) &&
                        selectedDocuments.some(
                          (x) => x.documentTypeId === d.documentTypeId
                        )
                    );
                  const isMissingAndAttempted =
                    isConditionallyRequired &&
                    attempt4 &&
                    (isOneOfRequired ? !anyOneOfSelected : !selected);

                  return (
                    <div
                      key={doc.documentTypeId}
                      style={{ marginBottom: 18 }}
                    >
                      <label
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: 8,
                          marginBottom: 8,
                          fontWeight: 600,
                        }}
                      >
                        {doc.documentName}
                        {isConditionallyRequired && (
                          <span
                            style={{
                              fontSize: "var(--font-xs)",
                              fontWeight: 700,
                              color: isMissingAndAttempted ? "#c0392b" : "#8a5a00",
                              background: isMissingAndAttempted
                                ? "#fdecea"
                                : "#fff8ee",
                              border: `1px solid ${isMissingAndAttempted
                                ? "rgba(192,57,43,.35)"
                                : "rgba(255,163,0,.32)"
                                }`,
                              borderRadius: 6,
                              padding: "2px 8px",
                            }}
                          >
                            {isOneOfRequired
                              ? "Required (RPSL License or Registration Certificate)"
                              : "Required"}
                          </span>
                        )}
                      </label>

                      <input
                        type="file"
                        className="form-control"
                        accept=".pdf,.jpg,.jpeg,.png"
                        onChange={(e) =>
                          handleDocumentSelect(
                            doc.documentTypeId,
                            e.target.files?.[0]
                          )
                        }
                      />

                      {selected && (
                        <small
                          style={{
                            color: "#3B6D11",
                            display: "block",
                            marginTop: 6,
                          }}
                        >
                          ✓ {selected.file.name}
                        </small>
                      )}

                      {isMissingAndAttempted && (
                        <small
                          style={{
                            color: "#c0392b",
                            display: "block",
                            marginTop: 6,
                          }}
                        >
                          This document is required based on your answers on the
                          previous step.
                        </small>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

            <hr />
            <div>
              <h5 style={{ marginBottom: 15 }}>Additional Documents</h5>

              {additionalDocuments.map((doc, index) => (
                <div key={index} style={{ marginBottom: 18 }}>
                  <div
                    style={{
                      position: "relative",
                      display: "flex",
                      alignItems: "center",
                    }}
                  >
                    <input
                      type="file"
                      className="form-control"
                      accept=".pdf,.jpg,.jpeg,.png"
                      onChange={(e) =>
                        handleAdditionalDocument(index, e.target.files?.[0])
                      }
                      style={{
                        flex: 1,
                        paddingRight: additionalDocuments.length > 1 ? 36 : undefined,
                      }}
                    />

                    {additionalDocuments.length > 0 && (
                      <button
                        type="button"
                        onClick={() => removeAdditionalDocument(index)}
                        aria-label={`Remove document ${index + 1}`}
                        style={{
                          position: "absolute",
                          right: 8,
                          top: "50%",
                          transform: "translateY(-50%)",
                          zIndex: 10,

                          width: 22,
                          height: 22,
                          border: "none",
                          background: "transparent",
                          color: "#888",
                          fontSize: 16,
                          fontWeight: 700,
                          cursor: "pointer",

                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                        }}

                        onMouseLeave={(e) => {
                          e.currentTarget.style.background = "transparent";
                          e.currentTarget.style.color = "#888";
                        }}
                      >
                        ×
                      </button>
                    )}
                  </div>

                  {doc.file && (
                    <div style={{ marginTop: 6 }}>
                      <span style={{ fontSize: 13, color: "#555" }}>
                        {doc.file.name}
                      </span>
                    </div>
                  )}
                </div>
              ))}

              <Btn variant="outline" onClick={addAdditionalDocument}>
                + Add Additional Document
              </Btn>
            </div>
          </>
        )}
      </div>

      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          marginTop: 8,
        }}
      >
        <Btn variant="outline" onClick={() => setStep(3)}>
          ← Back
        </Btn>

        <div style={{ display: "flex", gap: 10 }}>
          <Btn
            variant="primary"
            onClick={() => {
              setAttempt4(true);
              handleStep4();
            }}
          >
            Continue →
          </Btn>
        </div>
      </div>
    </div>
  );

  const ReviewSection = ({ icon, title, editStep, children }) => (
    <div
      style={{
        background: "#ffffff",
        border: "1px solid rgba(18,35,89,0.08)",
        borderRadius: 16,
        padding: "18px 20px",
        marginBottom: 16,
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          marginBottom: 14,
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span
            style={{
              width: 32,
              height: 32,
              borderRadius: 10,
              flexShrink: 0,
              background: "linear-gradient(135deg,#122359,#1e3a8a)",
              color: "#ffa300",
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: 14,
            }}
          >
            <i className={icon} />
          </span>
          <p
            style={{
              fontSize: "var(--font-sm)",
              fontWeight: 700,
              color: "#122359",
              margin: 0,
              letterSpacing: 0.2,
            }}
          >
            {title}
          </p>
        </div>
        {editStep && (
          <button
            type="button"
            onClick={() => setStep(editStep)}
            style={{
              background: "none",
              border: "none",
              color: "#ff9900",
              fontSize: "var(--font-xs)",
              fontWeight: 700,
              cursor: "pointer",
              padding: "4px 8px",
            }}
          >
            <i className="fi fi-rr-pencil" style={{ marginRight: 4 }} />
            Edit
          </button>
        )}
      </div>
      {children}
    </div>
  );

  const ReviewRow = ({ label, val, mono }) => (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        gap: 12,
        padding: "8px 0",
        borderBottom: "1px solid #f1f4fb",
        fontSize: "var(--font-sm)",
      }}
    >
      <span style={{ color: "#66789c" }}>{label}</span>
      {val ? (
        <span
          style={{
            fontFamily: mono ? "monospace" : undefined,
            fontWeight: 600,
            color: "#122359",
            textAlign: "right",
            maxWidth: "60%",
          }}
        >
          {val}
        </span>
      ) : (
        <span style={{ color: "#b6c0d6", fontStyle: "italic", fontSize: "var(--font-xs)" }}>
          Not provided
        </span>
      )}
    </div>
  );

  const VerifyPill = ({ ok, label }) => (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        padding: "5px 12px",
        borderRadius: 999,
        fontSize: "var(--font-xs)",
        fontWeight: 700,
        background: ok ? "#DCFCE7" : "#FEF3C7",
        color: ok ? "#166534" : "#92400E",
      }}
    >
      <i className={ok ? "fi fi-rr-check" : "fi fi-rr-clock"} style={{ fontSize: 10 }} />
      {label}
    </span>
  );

  // ── Step 5: Review & Submit ───────────────
  const renderStep5 = () => (
    <div>
      <h3
        style={{
          fontSize: "var(--font-md)",
          fontWeight: 600,
          marginBottom: 4,
          color: "var(--color-text-primary)",
        }}
      >
        Review & submit
      </h3>
      <p
        style={{
          fontSize: "var(--font-sm)",
          color: "var(--color-text-secondary)",
          marginBottom: 18,
        }}
      >
        Confirm all details before creating your account. Use{" "}
        <strong>Edit</strong> on any section to make changes.
      </p>

      {/* ── Verification status strip ── */}
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: 8,
          padding: "12px 14px",
          marginBottom: 20,
          background: "#F8FAFF",
          border: "1px solid rgba(18,35,89,0.08)",
          borderRadius: 14,
        }}
      >
        <VerifyPill ok={!!data.hasGst} label={data.hasGst ? "GST Verified" : "Non-GST entity"} />
        <VerifyPill ok={data.mobileOtp.verified} label={data.mobileOtp.verified ? "Mobile Verified" : "Mobile Pending"} />
        <VerifyPill ok={data.corpEmailOtp.verified} label={data.corpEmailOtp.verified ? "Email Verified" : "Email Pending"} />

      </div>

      <ReviewSection icon="fi fi-rr-briefcase" title="Company Details" editStep={2}>
        <ReviewRow label="Legal name" val={data.legalName} />
        <ReviewRow label="Trade name" val={data.tradeName} />
        {data.hasGst && <ReviewRow label="GSTN" val={data.gstn} mono />}
        {data.hasGst && <ReviewRow label="PAN" val={data.pan} mono />}
        <ReviewRow label="Business type" val={labelFor(BUSINESS_TYPES, data.businessType)} />
        <ReviewRow label="Company size" val={labelFor(COMPANY_SIZES, data.companySize)} />
        <ReviewRow label="Company type" val={labelFor(COMPANY_TYPES, data.companyType)} />
        <ReviewRow
          label="Industry"
          val={data.industry === "Other" ? data.customIndustry : data.industry}
        />
        {data.hasGst && <ReviewRow label="GST reg. date" val={data.gstRegDate} />}
        <ReviewRow label="CIN" val={data.cin} mono />
        <ReviewRow label="Website" val={data.officialWebsite} />
      </ReviewSection>

      <ReviewSection icon="fi fi-rr-marker" title="Registered Address" editStep={2}>
        <ReviewRow
          label="Address"
          val={
            data.address
              ? `${data.address}, ${data.city}, ${data.state} – ${data.pincode}, ${data.country}`
              : ""
          }
        />
      </ReviewSection>

      <ReviewSection icon="fi fi-rr-user" title="Contact & Verification" editStep={3}>
        <ReviewRow label="Contact person" val={data.contactName} />
        <ReviewRow label="Designation" val={data.designation} />
        <ReviewRow
          label="Company email"
          val={data.corpEmail ? `${data.corpEmail}${data.corpEmailOtp.verified ? "  ✓ Verified" : ""}` : ""}
        />
        <ReviewRow
          label="Mobile"
          val={data.mobile ? `${data.countryCode} ${data.mobile}${data.mobileOtp.verified ? "  ✓ Verified" : ""}` : ""}
        />
      </ReviewSection>

      <ReviewSection icon="fi fi-rr-document" title="Documents & Licences" editStep={4}>
        <ReviewRow
          label="Company logo"
          val={data.companyLogo ? `✓ ${data.companyLogo.name}` : ""}
        />
        <ReviewRow
          label="Licences"
          val={
            [...selectedDocuments, ...additionalDocuments].length > 0
              ? [...selectedDocuments, ...additionalDocuments]
                .map((d) => d.file?.name || d.documentName)
                .join(", ")
              : ""
          }
        />
        <ReviewRow label="GST registered" val={data.hasGst ? "Yes" : "No"} />
      </ReviewSection>

      <div
        style={{
          display: "flex",
          alignItems: "flex-start",
          gap: 10,
          padding: "12px 14px",
          marginBottom: 8,
          borderRadius: 12,
          border: attempt5 && !termsAccepted ? "1px solid #E24B4A" : "1px solid rgba(18,35,89,0.08)",
          background: attempt5 && !termsAccepted ? "#FFF5F5" : "#F8FAFF",
        }}
      >
        <input
          type="checkbox"
          checked={termsAccepted}
          onChange={(e) => setTermsAccepted(e.target.checked)}
          style={{ width: 18, height: 18, marginTop: 2, flexShrink: 0, accentColor: "#ff9900" }}
        />
        <label style={{ fontSize: "var(--font-xs)", color: "var(--color-text-secondary)", lineHeight: 1.5 }}>
          I agree to the Terms of Service and Employer Policy, and confirm
          that the details provided above are accurate.
        </label>
      </div>
      {attempt5 && !termsAccepted && (
        <p style={{ fontSize: "var(--font-xs)", color: "#E24B4A", marginTop: 0, marginBottom: 14, fontWeight: 500 }}>
          Please accept the terms to continue.
        </p>
      )}

      <div style={{ marginTop: 14, marginBottom: 14 }}>
        <Field label="Registration Fee">

          {/* ── Membership Plan ── */}
          {recruiterPlans.length > 0 && (
            <div style={{ marginBottom: 18 }}>
              <label
                style={{
                  display: "block",
                  fontSize: "var(--font-xs)",
                  fontWeight: 600,
                  marginBottom: 10,
                  color: "var(--color-text-secondary)",
                }}
              >
                Choose your membership plan
              </label>

              <div
                role="radiogroup"
                aria-label="Membership plan"
                style={{
                  display: "grid",
                  gridTemplateColumns: "repeat(auto-fit, minmax(230px, 1fr))",
                  gap: 14,
                  paddingTop: 8,
                }}
              >
                {recruiterPlans.map((plan) => {
                  const isSelected = plan.planId === selectedPlanId;
                  const locked = paying || couponLoading || couponApplied;
                  const credits = Number(plan.initialCredits) || 0;
                  const months = Number(plan.validityMonths) || 0;
                  const features = Array.isArray(plan.features)
                    ? plan.features.filter(Boolean)
                    : [];
                  const shownFeatures = features.slice(0, 4);
                  const hiddenCount = features.length - shownFeatures.length;
                  const priceText = Number(plan.price || 0).toLocaleString(
                    payCurrency === "INR" ? "en-IN" : "en-US",
                    { maximumFractionDigits: 2 },
                  );

                  return (
                    <div
                      key={plan.planId}
                      role="radio"
                      aria-checked={isSelected}
                      aria-disabled={locked}
                      tabIndex={locked ? -1 : 0}
                      onClick={() => handleSelectPlan(plan.planId)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" || e.key === " ") {
                          e.preventDefault();
                          handleSelectPlan(plan.planId);
                        }
                      }}
                      style={{
                        position: "relative",
                        display: "flex",
                        flexDirection: "column",
                        gap: 12,
                        padding: "20px 16px 16px",
                        borderRadius: 14,
                        border: `2px solid ${
                          isSelected ? "#FF9800" : "rgba(18,35,89,0.12)"
                        }`,
                        background: isSelected ? "#FFF8EC" : "#fff",
                        boxShadow: isSelected
                          ? "0 8px 24px rgba(255,152,0,0.18)"
                          : "0 1px 3px rgba(18,35,89,0.06)",
                        opacity: locked && !isSelected ? 0.55 : 1,
                        cursor: locked ? "default" : "pointer",
                        transition: "all .18s ease",
                        outline: "none",
                      }}
                    >
                      {/* Name + radio indicator */}
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: 10,
                        }}
                      >
                        <span
                          aria-hidden="true"
                          style={{
                            flex: "0 0 auto",
                            width: 20,
                            height: 20,
                            borderRadius: "50%",
                            border: `2px solid ${
                              isSelected ? "#FF9800" : "rgba(18,35,89,0.25)"
                            }`,
                            background: isSelected ? "#FF9800" : "#fff",
                            color: "#fff",
                            fontSize: 12,
                            fontWeight: 700,
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                          }}
                        >
                          {isSelected ? "✓" : ""}
                        </span>
                        <span
                          style={{
                            fontSize: "var(--font-md, 16px)",
                            fontWeight: 700,
                            color: "#122359",
                          }}
                        >
                          {plan.planName}
                        </span>
                      </div>

                      {/* Price: monthly rate first, full payment underneath */}
                      {months > 0 && Number(plan.price) > 0 ? (
                        <div>
                          <div
                            style={{
                              display: "flex",
                              alignItems: "baseline",
                              gap: 6,
                            }}
                          >
                            <span
                              style={{
                                fontSize: 32,
                                fontWeight: 800,
                                lineHeight: 1.1,
                                color: "#122359",
                              }}
                            >
                              {currencyPrefix}
                              {(Number(plan.price) / months).toLocaleString(
                                payCurrency === "INR" ? "en-IN" : "en-US",
                                { maximumFractionDigits: 2 },
                              )}
                            </span>
                            <span
                              style={{
                                fontSize: "var(--font-sm)",
                                fontWeight: 700,
                                color: "#1F9D6B",
                              }}
                            >
                              / month
                            </span>
                          </div>
                          <div
                            style={{
                              marginTop: 6,
                              fontSize: "var(--font-xs)",
                              color: "var(--color-text-secondary)",
                            }}
                          >
                            Pay{" "}
                            <b style={{ color: "#122359" }}>
                              {currencyPrefix}
                              {priceText}
                            </b>{" "}
                            {plan.period || "one-time"} for {months}{" "}
                            {months === 1 ? "month" : "months"}
                          </div>
                        </div>
                      ) : (
                        <div style={{ display: "flex", alignItems: "baseline", gap: 6 }}>
                          <span
                            style={{
                              fontSize: 30,
                              fontWeight: 800,
                              lineHeight: 1.1,
                              color: "#122359",
                            }}
                          >
                            {currencyPrefix}
                            {priceText}
                          </span>
                          <span
                            style={{
                              fontSize: "var(--font-xs)",
                              color: "var(--color-text-secondary)",
                            }}
                          >
                            {plan.period || "one-time"}
                          </span>
                        </div>
                      )}

                      {/* Credits + validity */}
                      {(credits > 0 || months > 0) && (
                        <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                          {credits > 0 && (
                            <span
                              style={{
                                background: isSelected ? "#FFE8C2" : "#F1F4FA",
                                color: "#122359",
                                fontSize: 12,
                                fontWeight: 600,
                                padding: "5px 10px",
                                borderRadius: 8,
                              }}
                            >
                              {credits.toLocaleString()} credits
                            </span>
                          )}
                          {months > 0 && (
                            <span
                              style={{
                                background: isSelected ? "#FFE8C2" : "#F1F4FA",
                                color: "#122359",
                                fontSize: 12,
                                fontWeight: 600,
                                padding: "5px 10px",
                                borderRadius: 8,
                              }}
                            >
                              {months} {months === 1 ? "month" : "months"} validity
                            </span>
                          )}
                        </div>
                      )}

                      {/* Features */}
                      {shownFeatures.length > 0 && (
                        <ul
                          style={{
                            listStyle: "none",
                            margin: 0,
                            padding: 0,
                            display: "flex",
                            flexDirection: "column",
                            gap: 6,
                          }}
                        >
                          {shownFeatures.map((feature, i) => (
                            <li
                              key={i}
                              style={{
                                display: "flex",
                                gap: 8,
                                fontSize: "var(--font-xs)",
                                color: "var(--color-text-primary)",
                              }}
                            >
                              <span style={{ color: "#16A34A", fontWeight: 700 }}>✓</span>
                              <span>{feature}</span>
                            </li>
                          ))}
                          {hiddenCount > 0 && (
                            <li
                              style={{
                                fontSize: "var(--font-xs)",
                                color: "var(--color-text-secondary)",
                                paddingLeft: 20,
                              }}
                            >
                              +{hiddenCount} more
                            </li>
                          )}
                        </ul>
                      )}

                      <span
                        style={{
                          marginTop: "auto",
                          textAlign: "center",
                          fontSize: "var(--font-xs)",
                          fontWeight: 700,
                          padding: "8px 10px",
                          borderRadius: 8,
                          background: isSelected ? "#FF9800" : "#F1F4FA",
                          color: isSelected ? "#fff" : "#122359",
                        }}
                      >
                        {isSelected ? "Selected" : "Select plan"}
                      </span>
                    </div>
                  );
                })}
              </div>

              {couponApplied && !paying && (
                <p
                  style={{
                    margin: "10px 0 0",
                    fontSize: "var(--font-xs)",
                    color: "var(--color-text-secondary)",
                  }}
                >
                  A coupon is applied to this plan. Remove the coupon below if
                  you want to choose a different plan.
                </p>
              )}
            </div>
          )}

          {/* ── Recruiter Coupon ── */}
          {payStatus !== "success" && (
            <div
              style={{
                marginBottom: 16,
                padding: 16,
                borderRadius: 14,
                border: `1px solid ${
                  couponApplied ? "rgba(22,163,74,0.35)" : "rgba(18,35,89,0.12)"
                }`,
                background: couponApplied ? "#F4FBF6" : "#FAFBFE",
                transition: "all .18s ease",
              }}
            >
              {/* Title */}
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  marginBottom: couponApplied ? 12 : 12,
                }}
              >
                <span
                  aria-hidden="true"
                  style={{
                    flex: "0 0 auto",
                    width: 32,
                    height: 32,
                    borderRadius: 10,
                    background: couponApplied ? "#DCF3E3" : "#FFE8C2",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <svg
                    width="18"
                    height="18"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke={couponApplied ? "#16A34A" : "#E58A00"}
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M20.6 13.4 13.4 20.6a2 2 0 0 1-2.8 0L3 13V3h10l7.6 7.6a2 2 0 0 1 0 2.8z" />
                    <circle cx="7.5" cy="7.5" r="1.2" />
                  </svg>
                </span>
                <div>
                  <div
                    style={{
                      fontSize: "var(--font-sm)",
                      fontWeight: 700,
                      color: "#122359",
                    }}
                  >
                    {couponApplied ? "Coupon applied" : "Have a coupon code?"}
                  </div>
                  <div
                    style={{
                      fontSize: "var(--font-xs)",
                      color: "var(--color-text-secondary)",
                    }}
                  >
                    {couponApplied
                      ? "Your discount is included in the total below."
                      : "Enter it to see your discount before you pay."}
                  </div>
                </div>
              </div>

              {!couponApplied ? (
                <>
                  <div style={{ display: "flex", gap: 8, width: "100%" }}>
                    <Input
                      placeholder="Enter coupon code"
                      value={couponCode}
                      error={!!couponMessage}
                      disabled={couponLoading || paying}
                      onChange={(e) => {
                        setCouponCode(e.target.value.toUpperCase());
                        setCouponApplied(false);
                        setCouponMessage("");
                        setCouponDiscount(0);
                        setCouponFinalAmount(null);
                      }}
                      onKeyDown={(e) => {
                        if (
                          e.key === "Enter" &&
                          couponCode.trim() &&
                          selectedPlanId &&
                          !couponLoading &&
                          !paying
                        ) {
                          e.preventDefault();
                          handleApplyRecruiterCoupon();
                        }
                      }}
                      style={{
                        flex: 1,
                        textTransform: "uppercase",
                        letterSpacing: "0.06em",
                        fontWeight: 600,
                      }}
                    />

                    <Btn
                      type="button"
                      variant="primary"
                      disabled={
                        couponLoading ||
                        paying ||
                        !couponCode.trim() ||
                        !selectedPlanId
                      }
                      onClick={handleApplyRecruiterCoupon}
                      style={{ minWidth: 100 }}
                    >
                      {couponLoading ? "Checking..." : "Apply"}
                    </Btn>
                  </div>

                  {/* Error from a failed attempt */}
                  {couponMessage && (
                    <p
                      role="alert"
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: 6,
                        fontSize: "var(--font-xs)",
                        margin: "10px 0 0",
                        color: "#A32D2D",
                        fontWeight: 500,
                      }}
                    >
                      <span aria-hidden="true">⚠</span>
                      {couponMessage}
                    </p>
                  )}
                </>
              ) : (
                <>
                  {/* Applied coupon chip + remove */}
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      gap: 10,
                      flexWrap: "wrap",
                    }}
                  >
                    <span
                      style={{
                        display: "inline-flex",
                        alignItems: "center",
                        gap: 8,
                        background: "#fff",
                        border: "1.5px dashed #16A34A",
                        borderRadius: 10,
                        padding: "7px 12px",
                        fontSize: "var(--font-sm)",
                        fontWeight: 700,
                        letterSpacing: "0.08em",
                        color: "#166534",
                      }}
                    >
                      <span aria-hidden="true">✓</span>
                      {couponCode}
                    </span>

                    <button
                      type="button"
                      onClick={handleRemoveCoupon}
                      disabled={paying || couponLoading}
                      style={{
                        background: "none",
                        border: "none",
                        padding: "6px 4px",
                        fontSize: "var(--font-xs)",
                        fontWeight: 700,
                        color: "#A32D2D",
                        cursor: paying || couponLoading ? "default" : "pointer",
                        opacity: paying || couponLoading ? 0.5 : 1,
                        textDecoration: "underline",
                      }}
                    >
                      Remove
                    </button>
                  </div>

                  {/* Price breakdown */}
                  <div
                    style={{
                      marginTop: 14,
                      paddingTop: 12,
                      borderTop: "1px solid rgba(18,35,89,0.1)",
                      display: "flex",
                      flexDirection: "column",
                      gap: 8,
                      fontSize: "var(--font-sm)",
                    }}
                  >
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        color: "var(--color-text-secondary)",
                      }}
                    >
                      <span>{recruiterPlan?.planName || "Plan"} price</span>
                      <span>{fmtMoney(recruiterPlan?.price)}</span>
                    </div>

                    {couponDiscount > 0 && (
                      <div
                        style={{
                          display: "flex",
                          justifyContent: "space-between",
                          color: "#16A34A",
                          fontWeight: 600,
                        }}
                      >
                        <span>Coupon discount</span>
                        <span>− {fmtMoney(couponDiscount)}</span>
                      </div>
                    )}

                    {couponFinalAmount !== null && (
                      <div
                        style={{
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "baseline",
                          paddingTop: 10,
                          borderTop: "1px solid rgba(18,35,89,0.1)",
                          color: "#122359",
                          fontWeight: 800,
                        }}
                      >
                        <span>Total payable</span>
                        <span style={{ fontSize: 20 }}>
                          {Number(couponFinalAmount) === 0
                            ? "Free"
                            : fmtMoney(couponFinalAmount)}
                        </span>
                      </div>
                    )}
                  </div>

                  {couponMessage && (
                    <p
                      style={{
                        fontSize: "var(--font-xs)",
                        margin: "10px 0 0",
                        color: "#3B6D11",
                      }}
                    >
                      {couponMessage}
                    </p>
                  )}
                </>
              )}
            </div>
          )}

          {payStatus === "success" ? (
            <Alert type="success">
              {paying
                ? "Payment successful — creating your account..."
                : `Payment successful for ${payCurrency} ${couponApplied && couponFinalAmount !== null
                  ? couponFinalAmount.toFixed(2)
                  : recruiterPlan?.price || 150
                }. Your receipt will be sent to your registered email.`}
            </Alert>
          ) : (
            <>
              {isPayPal ? (
                isFreeWithCoupon ? (
                  <Btn
                    variant="primary"
                    onClick={handleFreePayPalRegistration}
                    disabled={!termsAccepted || !selectedPlanId}
                    style={{ width: "100%", padding: "11px 0", fontSize: "var(--font-sm)" }}
                  >
                    Complete registration (no payment due)
                  </Btn>
                ) : (
                  <>
                    <p style={{ fontSize: "var(--font-sm)", fontWeight: 600, marginBottom: 8 }}>
                      Pay {payCurrency}{" "}
                      {Number(
                        couponApplied && couponFinalAmount !== null
                          ? couponFinalAmount
                          : recruiterPlan?.price || 0
                      ).toFixed(2)}{" "}
                      with PayPal
                    </p>
                    {/* The PayPal SDK renders its own button here — it must be
                        PayPal's button to open the popup. */}
                    <div
                      ref={payPalContainerRef}
                      style={{
                        opacity: paying ? 0.5 : 1,
                        pointerEvents: paying ? "none" : "auto",
                      }}
                    />
                    {!payPalReady && (
                      <p style={{ fontSize: "var(--font-xs)", color: "var(--color-text-tertiary)" }}>
                        Loading PayPal…
                      </p>
                    )}
                  </>
                )
              ) : (
              <Btn
                variant="primary"
                onClick={handleEmployerPay}
                disabled={paying || !termsAccepted || !selectedPlanId}
                style={{
                  width: "100%",
                  padding: "11px 0",
                  fontSize: "var(--font-sm)",
                }}
              >
                {paying
                  ? "Processing..."
                  : `Pay INR ${couponApplied && couponFinalAmount !== null
                    ? couponFinalAmount.toFixed(2)
                    : recruiterPlan?.price || 150
                  } via Razorpay`}
              </Btn>
              )}

              {!termsAccepted && (
                <p
                  style={{
                    fontSize: "var(--font-xs)",
                    marginTop: 8,
                    color: "var(--color-text-tertiary)",
                  }}
                >
                  Please accept the Terms of Service above to continue to payment.
                </p>
              )}
            </>
          )}

          {paymentMessage && (
            <p
              style={{
                fontSize: "var(--font-xs)",
                marginTop: 8,
                color: "var(--color-text-tertiary)",
              }}
            >
              {paymentMessage}
            </p>
          )}
        </Field>
      </div>

      {payStatus === "success" && (
        <Btn
          variant="primary"
          style={{ width: "100%", padding: "13px 0", fontSize: "var(--font-md)", marginTop: 6 }}
          onClick={handleEmployerSubmit}
        >
          Create Account
        </Btn>
      )}
      <div
        style={{ display: "flex", justifyContent: "flex-start", marginTop: 12 }}
      >
        <Btn variant="outline" onClick={() => setStep(4)}>
          ← Back
        </Btn>
      </div>
    </div>
  );

  const steps = [
    renderStep1,
    renderStep2,
    renderStep3,
    renderStep4,
    renderStep5,
  ];
  return (
    <div>
      <StepBar current={step} total={TOTAL_EMP_STEPS} labels={STEP_LABELS} />
      {steps[step - 1]?.()}
    </div>
  );
}

// ─────────────────────────────────────────────
// ROOT PAGE — reads ?type= from URL
// ─────────────────────────────────────────────
function RegisterPageInner() {
  const searchParams = useSearchParams();
  const typeParam = searchParams.get("type"); // "candidate" | "employer" | null
  // Coming in via a direct link (the header's Register ▸ Candidate/Employer
  // menu) locks the page to that one role — no tab to switch away from it.
  // Only a plain /register visit (no type in the URL) shows both tiles so
  // the visitor can choose.
  const lockedRole =
    typeParam === "candidate" || typeParam === "employer" ? typeParam : null;
  const [role, setRole] = useState(lockedRole);

  // Client-side navigation (e.g. clicking Register ▸ Employer while already
  // on /register?type=candidate) changes the URL without remounting this
  // component, so the `role` state above — set only once on first mount —
  // would otherwise keep showing whichever form loaded first. Keep it in
  // sync with the URL whenever the locked-in type actually changes.
  useEffect(() => {
    setRole(lockedRole);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lockedRole]);

  return (
    <main
      style={{
        minHeight: "100vh",
        padding: "40px 16px 60px",
        position: "relative",
        overflow: "hidden",
        "--font-xxs": "11px",
        "--font-xs": "13px",
        "--font-sm": "15px",
        "--font-base": "15px",
        "--font-md": "17px",
        "--font-lg": "19px",
        "--font-xl": "21px",
      }}
    >
      <Script
        src="https://checkout.razorpay.com/v1/checkout.js"
        strategy="lazyOnload"
      />
      <img
        src="/assets/imgs/page/login-register/img-3.svg"
        alt=""
        aria-hidden="true"
        style={{
          position: "absolute",
          left: -90,
          bottom: -26,
          width: "min(520px, 50vw)",
          opacity: 0.13,
          pointerEvents: "none",
          userSelect: "none",
          filter: "var(--theme-image-palette-filter)",
        }}
      />
      <img
        src="/assets/imgs/page/login-register/img-2.svg"
        alt=""
        aria-hidden="true"
        style={{
          position: "absolute",
          right: -120,
          top: -42,
          width: "min(560px, 52vw)",
          opacity: 0.1,
          pointerEvents: "none",
          userSelect: "none",
          filter: "var(--theme-image-palette-filter)",
        }}
      />
      <img
        src="/assets/imgs/page/login-register/img-6.svg"
        alt=""
        aria-hidden="true"
        style={{
          position: "absolute",
          top: 26,
          left: 22,
          width: "min(96px, 13vw)",
          opacity: 0.2,
          pointerEvents: "none",
          userSelect: "none",
          filter: "var(--theme-image-palette-filter)",
        }}
      />
      <img
        src="/assets/imgs/page/login-register/img-4.svg"
        alt=""
        aria-hidden="true"
        style={{
          position: "absolute",
          bottom: 24,
          right: 26,
          width: "min(132px, 16vw)",
          opacity: 0.2,
          pointerEvents: "none",
          userSelect: "none",
          filter: "var(--theme-image-palette-filter)",
        }}
      />
      <div
        style={{
          maxWidth: role === "employer" ? 820 : 460,
          margin: "0 auto",
          position: "relative",
          zIndex: 1,
        }}
      >
        {/* Header */}
        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <div
            style={{
              fontSize: "var(--font-xs)",
              fontWeight: 700,
              letterSpacing: 1.5,
              color: "#ff9900",
              textTransform: "uppercase",
              marginBottom: 8,
            }}
          >
            <img src="assets/imgs/template/logo.svg" />
          </div>
          <h1
            style={{
              fontSize: "var(--font-h5)",
              fontWeight: 700,
              color: "var(--color-text-primary)",
              marginBottom: 8,
            }}
          >
            {role === "employer"
              ? "Employer Registration"
              : role === "candidate"
                ? "Candidate Registration"
                : "Create your account"}
          </h1>
          <p
            style={{
              fontSize: "var(--font-sm)",
              color: "var(--color-text-secondary)",
            }}
          >
            {role === "employer"
              ? "Complete your company profile to start posting jobs and accessing candidates."
              : role === "candidate"
                ? "Join thousands of skilled professionals finding their next opportunity."
                : "Select your account type to get started."}
          </p>
        </div>

        {/* Card */}
        <div
          className="auth-shadow-card"
          style={{
            background: "#ffffff",
            border: "none",
            borderRadius: 24,
            padding: role === "employer" ? "40px 44px" : "38px 34px",
            marginBottom: 0,
            boxSizing: "border-box",
          }}
        >
          {/* Role selector — only shown when no role was locked in via URL */}
          {!role ? (
            <div style={{ marginBottom: 8 }}>
              <p style={{ fontSize: "var(--font-xs)", fontWeight: 600, color: "var(--color-text-secondary)", marginBottom: 12 }}>
                I am registering as…
              </p>
              <div style={{ display: "flex", gap: 12 }}>
                {[
                  { val: "candidate", icon: "👤", label: "Job Seeker / Candidate", sub: "Find jobs, build profile" },
                  { val: "employer", icon: "🏢", label: "Employer / Company", sub: "Post jobs, hire talent" },
                ].map((r) => (
                  <div
                    key={r.val}
                    onClick={() => setRole(r.val)}
                    style={{
                      flex: 1,
                      padding: "18px 14px",
                      borderRadius: 10,
                      cursor: "pointer",
                      border: "1px solid var(--color-border-secondary, #C7D2E0)",
                      background: "var(--color-background-secondary)",
                      display: "flex",
                      alignItems: "flex-start",
                      gap: 12,
                    }}
                  >
                    <span style={{ fontSize: 24, flexShrink: 0 }}>{r.icon}</span>
                    <div>
                      <div style={{ fontSize: 14, fontWeight: 600, color: "var(--color-text-primary)" }}>
                        {r.label}
                      </div>
                      <div style={{ fontSize: "var(--font-xs)", color: "var(--color-text-secondary)", marginTop: 2 }}>
                        {r.sub}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            !lockedRole && (
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                {/* <span style={{ fontSize: "var(--font-sm)", color: "var(--color-text-secondary)" }}>
        Registering as{" "}
        <strong style={{ color: "var(--color-text-primary)" }}>
          {role === "candidate" ? "Job Seeker / Candidate" : "Employer / Company"}
        </strong>
      </span>
      <button
        type="button"
        onClick={() => setRole(null)}
        style={{
          background: "none",
          border: "none",
          color: "#ff9900",
          fontWeight: 600,
          fontSize: "var(--font-xs)",
          cursor: "pointer",
        }}
      >
        Change
      </button> */}
              </div>
            )
          )}

          {role === "candidate" && <CandidateForm />}
          {role === "employer" && <EmployerForm />}

          {!role && !lockedRole && (
            <p
              style={{
                textAlign: "center",
                fontSize: "var(--font-sm)",
                color: "var(--color-text-tertiary)",
                marginTop: 24,
              }}
            >
              Select an account type above to continue
            </p>
          )}
        </div>

        <p
          style={{
            textAlign: "center",
            fontSize: "var(--font-sm)",
            color: "var(--color-text-secondary)",
            marginTop: 20,
          }}
        >
          Already have an account?{" "}
          <a
            href="/Login"
            style={{
              color: "#ff9900",
              fontWeight: 600,
              textDecoration: "none",
            }}
          >
            Sign in
          </a>
        </p>
      </div>
    </main>
  );
}

export default function RegisterPage() {
  return (
    <Suspense
      fallback={
        <main
          style={{
            minHeight: "100vh",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          Loading…
        </main>
      }
    >
      <RegisterPageInner />
    </Suspense>
  );
}