'use client';
import React from "react";
// import Image from "next/image";
import Link from "next/link";

const JOB_LIST_CARD_STYLE = {
  border: "1px solid rgba(18, 35, 89, 0.08)",
  borderRadius: "24px",
  overflow: "hidden",
  transition: "all 0.35s ease",
  background: "#ffffff",
  boxShadow: "0 4px 14px rgba(18,35,89,0.04)",
  minHeight: "350px", // Add this
  display: "flex",
  flexDirection: "column",
};

const JOB_LIST_TAG_WRAP_STYLE = {
  display: "flex",
  flexWrap: "wrap",
  justifyContent: "flex-end",
  gap: 8,
  marginTop: 24,
  marginBottom: 14
};

const JOB_LIST_TAG_STYLE = {
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  padding: "6px 12px",
  borderRadius: 999,
  background: "#EAF4FF",
  border: "1px solid #B9DCFF",
  color: "#1D4ED8",
  fontSize: 12,
  fontWeight: 600,
  whiteSpace: "nowrap",
  lineHeight: 1,
  transition: "all 0.25s ease",
  cursor: "pointer"
};

// Text colour for location, work type and experience on saved job cards
const SAVED_JOB_META_COLOR = "#66789C";

const SAVED_JOB_ACTION_BUTTON_STYLE = {
  color: "#ffffff",
  background: "#FFA300",
  border: "1px solid #FFA300",
  transition: "all 0.25s ease"
};

const handleCardHoverEnter = (event) => {
  event.currentTarget.style.transform = "translateY(-8px)";
  event.currentTarget.style.border = "1px solid rgba(255, 153, 0, 0.22)";
  event.currentTarget.style.boxShadow = "0 20px 40px rgba(255,153,0,0.12)";
};

const handleCardHoverLeave = (event) => {
  event.currentTarget.style.transform = "translateY(0px)";
  event.currentTarget.style.border = "1px solid rgba(18, 35, 89, 0.08)";
  event.currentTarget.style.boxShadow = "0 4px 14px rgba(18,35,89,0.04)";
};

const handleTagHoverEnter = (event) => {
  event.currentTarget.style.background = "#1D4ED8";
  event.currentTarget.style.color = "#ffffff";
  event.currentTarget.style.transform = "translateY(-1px)";
};

const handleTagHoverLeave = (event) => {
  event.currentTarget.style.background = "#EAF4FF";
  event.currentTarget.style.color = "#1D4ED8";
  event.currentTarget.style.transform = "translateY(0px)";
};

const handleSavedJobButtonHoverEnter = (event) => {
  event.currentTarget.style.background = "#e68f00";
  event.currentTarget.style.border = "1px solid #e68f00";
  event.currentTarget.style.transform = "translateY(-1px)";
  event.currentTarget.style.boxShadow = "0 8px 18px rgba(255,153,0,0.22)";
};

const handleSavedJobButtonHoverLeave = (event) => {
  event.currentTarget.style.background = "#FFA300";
  event.currentTarget.style.border = "1px solid #FFA300";
  event.currentTarget.style.transform = "translateY(0px)";
  event.currentTarget.style.boxShadow = "none";
};

const ProfileJobCard = ({ job, isListView, applyToDetails = false, onUnsave }) => {
  const formatSalary = (value) => {
    if (!value) return "";

    if (
      value.toLowerCase() === "confidential"
    ) {
      return "Confidential";
    }

    const text = String(value)
      .replace(/INR|\u20B9/gi, "")
      .trim();

    return text.includes("$")
      ? text
      : `₹${text}`;
  };

  const displayPrice = (job.salaryVisibility === "Hide Salary" || job.salaryVisibility === "Hide_Salary" || job.salaryDisplayOption === "Hide Salary" || job.salaryDisplayOption === "Hide_Salary")
    ? ""
    : formatSalary(job.price);
  const visibleTags = applyToDetails
    ? (job.tags || []).slice(0, 2)
    : (job.tags || []);

  return (
    <div
      className={`card-grid-2 hover-up${isListView ? "" : " no-padding"}${applyToDetails ? " candidate-saved-job-card" : ""}`}
      style={applyToDetails ? JOB_LIST_CARD_STYLE : undefined}
      onMouseEnter={applyToDetails ? handleCardHoverEnter : undefined}
      onMouseLeave={applyToDetails ? handleCardHoverLeave : undefined}
    >
      {!applyToDetails && <span className="flash"></span>}
      <div className="row">
       <div className="col-lg-12 col-md-12 col-sm-12">
          <div
            className="card-grid-2-image-left"
            style={{
              display: "flex",
              alignItems: "flex-start",
              width: "100%",
              gap: "12px",
            }}
          >
            {/* <div className="image-box"> */}
            <div style={{ marginRight: "12px" }}>

              <img
                src={job.logo}
                alt={job.company || "Company logo"}
                width={52}
                height={52}
                className="candidate-job-logo"
                style={{
                  width: "52px",
                  height: "52px",
                  objectFit: "contain"
                }}
              />
            </div>
            <div
              className="right-info"
              style={{
                flex: 1,
                minWidth: 0,
              }}
            >
              <Link
                className="name-job"
                href={job.employerId ? `/company-details?employerId=${job.employerId}` : "/company-details"}
                style={{
                  display: "block",
                  maxWidth: "100%",
                  whiteSpace: "nowrap",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                }}
                title={job.company}
              >
                {job.company}
              </Link>
              <span
                className="location-small"
                style={{
                  whiteSpace: "nowrap",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  maxWidth: "180px",
                  display: "block",
                  ...(applyToDetails ? { color: SAVED_JOB_META_COLOR } : {}),
                }}
              >
                {job.location}
              </span>
            </div>
          </div>
        </div>
       
      </div>
      <div
        className={`card-block-info${applyToDetails ? " candidate-saved-job-card-info" : ""
          }`}
        style={{
          flex: 1,
          display: "flex",
          flexDirection: "column",
          maxHeight: "none",
        }}
      >
        <h4 className={applyToDetails ? "candidate-saved-job-title" : undefined}>
          <Link href={job.jobId ? `/job-details?jobId=${job.jobId}` : "/job-details"}>{job.title}</Link>
        </h4>
        <div className="mt-1">
          <span className="card-briefcase" style={applyToDetails ? { color: SAVED_JOB_META_COLOR } : undefined}>{job.type}</span>
          {applyToDetails ? (
            <span className="card-time" style={{ color: SAVED_JOB_META_COLOR }}>
              <span>Experience:</span>
              <span>{job.experience || "Not specified"}</span>
            </span>
          ) : (
            <span className="card-time">
              <span>{job.time.split(" ")[0]}</span>
              <span>{job.time.split(" ")[1]}</span>
            </span>
          )}
        </div>
        <p
          className="font-sm color-text-paragraph mt-10"
          style={{
            minHeight: "60px",
            overflow: "hidden",
            display: "-webkit-box",
            WebkitLineClamp: 3,
            WebkitBoxOrient: "vertical",
          }}
        >
          {job.description}
        </p>
        <div
          className={`card-2-bottom mt-20${isListView ? " mt-30" : " mt-30"
            }`}
          style={{ marginTop: "auto" }}
        >
          <div className="row">
            <div className="col-lg-7 col-7">
              {applyToDetails && displayPrice ? (
                <>
                  <span className="card-text-price">{displayPrice}</span>
                  <span className="text-muted">{job.priceUnit || "/month"}</span>
                </>
              ) : null}
            </div>
            <div className="col-lg-5 col-5 text-end" style={{ display: "flex", justifyContent: "flex-end", gap: "6px" }}>
              {applyToDetails ? (
                <>
                  <button
                    type="button"
                    className="btn btn-border"
                    style={{
                      padding: "8px 12px",
                      fontSize: "12px",
                      lineHeight: "1",
                      backgroundColor: "#FFF3E0",
                      borderColor: "#ffa300",
                      color: "#B15C00",
                      fontWeight: "600",
                      borderRadius: "8px",
                      minWidth: "fit-content",
                    }}
                    onClick={(e) => {
                      e.preventDefault();
                      onUnsave?.(job.jobId);
                    }}
                  >
                    Unsave
                  </button>
                  <Link
                    className="btn btn-apply-now"
                    style={{
                      ...SAVED_JOB_ACTION_BUTTON_STYLE,
                      padding: "8px 12px",
                      fontSize: "12px",
                      lineHeight: "1",
                      borderRadius: "8px",
                      minWidth: "fit-content",
                    }}
                    href={job.jobId ? `/job-details?jobId=${job.jobId}` : "/job-details"}
                    title="View job details"
                    data-bs-toggle="tooltip"
                    onMouseEnter={handleSavedJobButtonHoverEnter}
                    onMouseLeave={handleSavedJobButtonHoverLeave}
                  >
                    View Job
                  </Link>
                </>
              ) : (
                <div
                  className="btn btn-apply-now"
                  data-bs-toggle="modal"
                  data-bs-target="#ModalApplyJobForm"
                  title="Apply to this job"
                >
                  Apply now
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileJobCard;