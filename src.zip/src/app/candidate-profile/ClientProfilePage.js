"use client";
import { getCandidateId } from "@/utils/authHelper";
import { getProfileCompletion } from "@/services/candidate/profileCompletionService";
import { State } from "country-state-city";

import { useRouter } from "next/navigation";

import {
  getAvailability,
  updateAvailability,
} from "@/services/candidate/availabilityService";

import {
  getSkills,
  createSkill,
  updateSkill as updateCandidateSkill,
  deleteSkill,
} from "@/services/candidate/skillsService";

import {
  getWorkExperience,
  createWorkExperience,
  updateWorkExperience,
  deleteWorkExperience,
} from "@/services/candidate/workExperienceService";

import {
  getEducation,
  createEducation,
  updateEducation,
  deleteEducation,
} from "@/services/candidate/educationService";

import {
  getLanguages,
  createLanguage,
  updateLanguage,
  deleteLanguage,
} from "@/services/candidate/languagesService";

import {
  uploadResume,
  deleteResume,
  getDocuments,
  generateCv,
} from "@/services/candidate/candidateResume.js";
import { getUploadedDocuments } from "@/services/candidate/documentService";

import {
  uploadEducationCertificate,
  deleteEducationCertificate,
  getEducationCertificates,
} from "@/services/candidate/candidateEducationCert.js";

// import {
//   uploadPassport,
//   deletePassport,
// } from "@/services/candidate/candidatePassport";

import {
  getPersonalInfo,
  createPersonalInfo,
  updatePersonalInfo,
  uploadProfilePhoto,
} from "@/services/candidate/profileService";

import api from "@/services/api";

import React, { useCallback, useMemo, useState, useEffect } from "react";
import { mockProfile } from "./components/data.js";
import MyDocuments from "./components/MyDocuments";
import { useToast } from "@/components/Toast";


// ─── Theme tokens (matches site globals.css) ────────────────────────────────
const T = {
  navy: "#122359",
  orange: "#ffa300",
  orangeLight: "#ffc151",
  text: "#4f5e64",
  muted: "#66789c",
  border: "#e8ecf0",
  bg: "#f5f7fa",
  white: "#fff",
  success: "#3b6d11",
  successBg: "#eaf3de",
  error: "#a32d2d",
  errorBg: "#fcebeb",
};

// ─── Steps definition ────────────────────────────────────────────────────────
const STEPS = [
  { id: "personal", label: "Personal", iconClass: "fi-rr-user" },
  { id: "documents", label: "Documents", iconClass: "fi-rr-document" },
  { id: "work", label: "Experience", iconClass: "fi-rr-briefcase" },
  { id: "education", label: "Education", iconClass: "fi-rr-graduation-cap" },
  { id: "skills", label: "Skills", iconClass: "fi-rr-settings" },
  { id: "languages", label: "Languages", iconClass: "fi-rr-globe" },
];

const TOTAL = STEPS.length;
const PROFILE_PHOTO_PREVIEW_KEY = "candidate-profile-photo-preview";
const DEFAULT_PROFILE_PHOTO =
  "/assets/imgs/page/candidates/candidate-profile.png";

const COUNTRY_MAP = {
  "+91": "IN",
  "+1": "US",
  "+44": "GB",
  "+971": "AE",
};

const getStoredProfilePhotoPreview = () => {
  if (typeof window === "undefined") return "";

  return window.localStorage.getItem(PROFILE_PHOTO_PREVIEW_KEY) || "";
};

const storeProfilePhotoPreview = (previewUrl) => {
  if (typeof window === "undefined" || !previewUrl) return;

  window.localStorage.setItem(PROFILE_PHOTO_PREVIEW_KEY, previewUrl);
};

// ─── Shared UI ────────────────────────────────────────────────────────────────
const Field = ({ label, required, children, hint }) => (
  <div style={{ marginBottom: 18 }}>
    <label
      style={{
        display: "block",
        fontSize: 12,
        fontWeight: 700,
        color: T.navy,
        marginBottom: 6,
        textTransform: "uppercase",
        letterSpacing: "0.04em",
      }}
    >
      {label}
      {required && <span style={{ color: T.error, marginLeft: 3 }}>*</span>}
    </label>
    {children}
    {hint && (
      <p
        style={{
          fontSize: 11,
          color: T.muted,
          marginTop: 4,
          margin: "4px 0 0",
        }}
      >
        {hint}
      </p>
    )}
  </div>
);

const Inp = ({
  style = {},
  onFocus,
  onBlur,
  ...props
}) => (
  <input
    {...props}
    style={{
      width: "100%",
      height: 48,
      padding: "0 14px",
      borderRadius: 8,
      border: `1.5px solid ${T.border}`,
      fontSize: 14,
      color: T.navy,
      background: T.white,
      outline: "none",
      boxSizing: "border-box",
      transition: "border-color .15s",
      ...style,
    }}
    onFocus={(e) => {
      e.target.style.borderColor = T.orangeLight;
      onFocus?.(e);
    }}
    onBlur={(e) => {
      e.target.style.borderColor = T.border;
      onBlur?.(e);
    }}
  />
);

const Sel = ({ children, style = {}, ...props }) => (
  <select
    {...props}
    style={{
      width: "100%",
      height: 48,
      padding: "0 14px",
      borderRadius: 8,
      border: `1.5px solid ${T.border}`,
      fontSize: 14,
      color: T.navy,
      background: T.white,
      outline: "none",
      boxSizing: "border-box",
      appearance: "none",
      WebkitAppearance: "none",
      backgroundImage:
        "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%23122359' stroke-width='1.5' fill='none'/%3E%3C/svg%3E\")",
      backgroundRepeat: "no-repeat",
      backgroundPosition: "right 14px center",
      ...style,
    }}
  >
    {children}
  </select>
);

const Textarea = ({ style = {}, ...props }) => (
  <textarea
    {...props}
    style={{
      width: "100%",
      padding: "12px 14px",
      borderRadius: 8,
      border: `1.5px solid ${T.border}`,
      fontSize: 14,
      color: T.navy,
      background: T.white,
      outline: "none",
      boxSizing: "border-box",
      resize: "vertical",
      minHeight: 90,
      lineHeight: 1.6,
      transition: "border-color .15s",
      ...style,
    }}
    onFocus={(e) => (e.target.style.borderColor = T.orangeLight)}
    onBlur={(e) => (e.target.style.borderColor = T.border)}
  />
);

const Btn = ({
  children,
  variant = "primary",
  onClick,
  disabled,
  style = {},
  type = "button",
}) => {
  const variants = {
    primary: { background: T.orange, color: T.white, border: "none" },
    outline: {
      background: T.white,
      color: T.navy,
      border: `1.5px solid ${T.navy}`,
    },
    ghost: {
      background: T.bg,
      color: T.navy,
      border: `1.5px solid ${T.border}`,
    },
    danger: {
      background: T.errorBg,
      color: T.error,
      border: `1px solid ${T.error}`,
    },
    success: {
      background: T.successBg,
      color: T.success,
      border: `1px solid ${T.success}`,
    },
  };
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      style={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        gap: 7,
        padding: "10px 22px",
        borderRadius: 8,
        fontSize: 14,
        fontWeight: 600,
        cursor: disabled ? "not-allowed" : "pointer",
        opacity: disabled ? 0.55 : 1,
        transition: "all .15s",
        lineHeight: 1,
        whiteSpace: "nowrap",
        ...variants[variant],
        ...style,
      }}
    >
      {children}
    </button>
  );
};

const Tag = ({ label, onRemove }) => (
  <span
    style={{
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      padding: "5px 10px",
      background: "#e8f0fe",
      color: T.navy,
      borderRadius: 20,
      fontSize: 12,
      fontWeight: 600,
      margin: "3px",
    }}
  >
    {label}
    {onRemove && (
      <button
        onClick={onRemove}
        style={{
          background: "none",
          border: "none",
          cursor: "pointer",
          color: T.muted,
          fontSize: 14,
          padding: 0,
          lineHeight: 1,
        }}
      >
        <i className="fi-rr-cross-small" aria-hidden="true" />
      </button>
    )}
  </span>
);

const Card = ({ children, style = {} }) => (
  <div
    style={{
      background: T.white,
      border: `1px solid ${T.border}`,
      borderRadius: 12,
      padding: "20px 24px",
      marginBottom: 16,
      ...style,
    }}
  >
    {children}
  </div>
);

// ─── Step Progress Bar ────────────────────────────────────────────────────────
const StepBar = ({ current, onStepClick, completedSteps }) => (
  <div
    style={{
      display: "flex",
      alignItems: "flex-start",
      marginBottom: 32,
      overflowX: "auto",
      paddingBottom: 4,
    }}
  >
    {STEPS.map((step, i) => {
      const n = i + 1;
      const done = completedSteps ? completedSteps.has(n) : n < current;
      const active = n === current;
      const clickable = typeof onStepClick === "function";
      return (
        <React.Fragment key={step.id}>
          <div
            onClick={clickable ? () => onStepClick(n) : undefined}
            role={clickable ? "button" : undefined}
            tabIndex={clickable ? 0 : undefined}
            onKeyDown={
              clickable
                ? (e) => {
                  if (e.key === "Enter" || e.key === " ") onStepClick(n);
                }
                : undefined
            }
            title={clickable ? `Go to ${step.label}` : undefined}
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              gap: 6,
              minWidth: 64,
              cursor: clickable ? "pointer" : "default",
            }}
          >
            <div
              style={{
                width: 40,
                height: 40,
                borderRadius: "50%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: done ? 16 : 14,
                fontWeight: 700,
                flexShrink: 0,
                transition: "all .2s",
                background: done ? T.success : active ? T.orange : T.bg,
                color: done || active ? T.white : T.muted,
                border: active
                  ? `3px solid ${T.orangeLight}`
                  : `2px solid ${done ? T.success : T.border}`,
                boxSizing: "border-box",
                boxShadow: active ? `0 0 0 4px rgba(255,163,0,0.15)` : "none",
              }}
            >
              <i
                className={done ? "fi-rr-check" : step.iconClass}
                aria-hidden="true"
                style={{
                  fontSize: done ? 13 : 14,
                  lineHeight: 1,
                  display: "inline-flex",
                }}
              />
            </div>
            <span
              style={{
                fontSize: 13,
                fontWeight: active ? 700 : 500,
                color: active ? T.orange : done ? T.success : T.muted,
                textAlign: "center",
                whiteSpace: "nowrap",
              }}
            >
              {step.label}
            </span>
          </div>
          {i < TOTAL - 1 && (
            <div
              style={{
                flex: 1,
                height: 2,
                margin: "19px 4px 0",
                background: done ? T.success : T.border,
                transition: "background .3s",
                minWidth: 16,
              }}
            />
          )}
        </React.Fragment>
      );
    })}
  </div>
);

// ─── STEP 1 — Personal Information ───────────────────────────────────────────
const StepPersonal = ({
  data,
  onChange,
  onPhotoUpload,
  errors = {},
}) => {
  const [avatarPreview, setAvatarPreview] = useState(null);
  const avatarSrc = avatarPreview || data.avatar || DEFAULT_PROFILE_PHOTO;
  const [trades, setTrades] = useState([]);
  const [tradesLoading, setTradesLoading] = useState(true);
 
const [tradeSearch, setTradeSearch] = useState("");
const [showTradeOptions, setShowTradeOptions] = useState(false);

  const filteredTrades = trades.filter((trade) =>
  (trade.name || "")
    .toLowerCase()
    .includes(tradeSearch.toLowerCase())
);


  useEffect(() => {
    const fetchTrades = async () => {
      try {
        const response = await api.get("/api/candidate-trades");

        const result = response.data;

        const tradeList = Array.isArray(result)
          ? result
          : Array.isArray(result?.data)
            ? result.data
            : [];

        setTrades(tradeList);
      } catch (error) {
        console.error("Failed to fetch trades:", error);
        setTrades([]);
      } finally {
        setTradesLoading(false);
      }
    };

    fetchTrades();
  }, []);
  const handleAvatar = async (e) => {
    const file = e.target.files[0];

    if (!file) return;

    const reader = new FileReader();

    reader.onloadend = async () => {
      const previewUrl = reader.result;

      setAvatarPreview(previewUrl);
      storeProfilePhotoPreview(previewUrl);
      onChange("avatar", previewUrl);

      // console.log("Selected file:", file);

      await onPhotoUpload(file, previewUrl);
    };

    reader.readAsDataURL(file);
  };

  const states = State.getStatesOfCountry(data.country || "IN");
  return (
    <div>
      <h4 style={{ color: T.navy, marginBottom: 6, marginTop: 0 }}>
        Personal Information
      </h4>
      <p
        style={{ color: T.muted, fontSize: 14, marginBottom: 28, marginTop: 0 }}
      >
        Let employers know who you are
      </p>

      {/* Avatar */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 20,
          marginBottom: 28,
          padding: "16px 20px",
          background: T.bg,
          borderRadius: 12,
        }}
      >
        <div
          style={{
            width: 72,
            height: 72,
            borderRadius: "50%",
            overflow: "hidden",
            border: `3px solid ${T.orangeLight}`,
            flexShrink: 0,
          }}
        >
          <img
            src={avatarSrc}
            alt="Profile"
            onError={(e) => {
              e.currentTarget.src =
                getStoredProfilePhotoPreview() || DEFAULT_PROFILE_PHOTO;
            }}
            style={{ width: "100%", height: "100%", objectFit: "cover" }}
          />
        </div>
        <div>
          <p
            style={{
              margin: "0 0 8px",
              fontWeight: 600,
              fontSize: 14,
              color: T.navy,
            }}
          >
            Profile Photo
          </p>
          <input
            type="file"
            id="avatar-upload"
            onChange={handleAvatar}
            accept="image/*"
            style={{ display: "none" }}
          />
          <label
            htmlFor="avatar-upload"
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: 6,
              padding: "7px 16px",
              background: T.orange,
              color: T.white,
              borderRadius: 7,
              fontSize: 13,
              fontWeight: 600,
              cursor: "pointer",
            }}
          >
            <i
              className="fi-rr-camera"
              aria-hidden="true"
              style={{ lineHeight: 1 }}
            />
            Upload Photo
          </label>
        </div>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: "0 20px",
        }}
      >
        <Field label="First Name" required>
          <Inp
            value={data.firstName || ""}
            onChange={(e) =>
              onChange("firstName", e.target.value.replace(/^\s+/, ""))
            }
            placeholder="Enter your first name"
          />

          {errors.firstName && (
            <p
              style={{
                color: "red",
                fontSize: "12px",
                marginTop: "4px",
              }}
            >
              {errors.firstName}
            </p>
          )}
        </Field>
        <Field label="Last Name" required>
          <Inp
            value={data.lastName || ""}
            onChange={(e) =>
              onChange("lastName", e.target.value.replace(/^\s+/, ""))
            }
            placeholder="Enter your last name"
            required
          />
          {errors.lastName && (
            <p style={{ color: "red", fontSize: "12px", marginTop: "4px" }}>
              {errors.lastName}
            </p>
          )}
        </Field>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: "0 20px",
        }}
      >
        <Field label="Mobile Number" required>
          <Inp
            value={data.mobile || ""}
            onChange={(e) => onChange("mobile", e.target.value)}
            placeholder="Enter your mobile number"
            required
          />
          {errors.mobile && (
            <p style={{ color: "red", fontSize: "12px", marginTop: "4px" }}>
              {errors.mobile}
            </p>
          )}
        </Field>
        <Field label="Email Address" required>
          <Inp
            type="email"
            value={data.email || ""}
            onChange={(e) => onChange("email", e.target.value)}
            placeholder="Enter your email address"
            required
          />
          {errors.email && (
            <p style={{ color: "red", fontSize: "12px", marginTop: "4px" }}>
              {errors.email}
            </p>
          )}
        </Field>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: "0 20px",
        }}
      >
        <Field label="Date of Birth" required>
          <Inp
            type="date"
            value={data.dob || ""}
            onChange={(e) => onChange("dob", e.target.value)}
            required
          />
          {errors.dob && (
            <p style={{ color: "red", fontSize: "12px", marginTop: "4px" }}>
              {errors.dob}
            </p>
          )}
        </Field>
        <Field label="Gender" required>
          <Sel
            value={data.gender || ""}
            onChange={(e) => onChange("gender", e.target.value)}
            required
          >
            <option value="">Select gender</option>
            <option>Male</option>
            <option>Female</option>
            <option>Other</option>
            {/* <option>Prefer not to say</option> */}
          </Sel>
          {errors.gender && (
            <p style={{ color: "red", fontSize: "12px", marginTop: "4px" }}>
              {errors.gender}
            </p>
          )}
        </Field>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr 1fr",
          gap: "0 20px",
        }}
      >
        <Field label="City" required>
          <Inp
            value={data.city || ""}
            onChange={(e) => onChange("city", e.target.value)}
            placeholder="Enter your city"
            required
          />
          {errors.city && (
            <p style={{ color: "red", fontSize: "12px", marginTop: "4px" }}>
              {errors.city}
            </p>
          )}
        </Field>
        <Field label="State" required>
          <Sel
            value={data.state || ""}
            onChange={(e) => onChange("state", e.target.value)}
            required
          >
            <option value="">Select state</option>
            {states.map((state) => (
              <option key={state.isoCode} value={state.name}>
                {state.name}
              </option>
            ))}
          </Sel>
          {errors.state && (
            <p style={{ color: "red", fontSize: "12px", marginTop: "4px" }}>
              {errors.state}
            </p>
          )}
        </Field>
        <Field label="PIN Code" required>
          <Inp
            value={data.pin || ""}
            onChange={(e) => onChange("pin", e.target.value)}
            placeholder="Enter your PIN code"
            maxLength={6}
            required
          />
          {errors.pin && (
            <p style={{ color: "red", fontSize: "12px", marginTop: "4px" }}>
              {errors.pin}
            </p>
          )}
        </Field>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: "0 20px",
        }}
      >
        <Field label="Nationality" required>
          <Inp
            value={data.nationality || ""}
            onChange={(e) => onChange("nationality", e.target.value)}
            placeholder="Enter your nationality"
            required
          />
          {errors.nationality && (
            <p style={{ color: "red", fontSize: "12px", marginTop: "4px" }}>
              {errors.nationality}
            </p>
          )}
        </Field>
      
<Field label="Trade / Job Title" required>
  <div style={{ position: "relative" }}>
   <Inp
  value={tradeSearch || data.trade || ""}
  onChange={(e) => {
    setTradeSearch(e.target.value);
    onChange("trade", e.target.value);
  }}
  onFocus={() => setShowTradeOptions(true)}
  onBlur={() => {
    setTimeout(() => setShowTradeOptions(false), 150);
  }}
  placeholder={
    tradesLoading ? "Loading trades..." : "Search or enter a trade"
  }
  autoComplete="off"
  required
/>

    {showTradeOptions && !tradesLoading && (
      <div
        style={{
          position: "absolute",
          top: "100%",
          left: 0,
          right: 0,
          zIndex: 1000,
          background: T.white,
          border: `1px solid ${T.border}`,
          borderRadius: 8,
          maxHeight: 220,
          overflowY: "auto",
          boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
        }}
      >
        {filteredTrades.length > 0 ? (
          filteredTrades.map((trade) => (
            <button
              key={trade.tradeCategoryId}
              type="button"
              onMouseDown={(e) => e.preventDefault()}
           
onClick={() => {
  onChange("trade", trade.name);
  onChange("tradeCategoryId", trade.tradeCategoryId);
  setTradeSearch("");
  setShowTradeOptions(false);
}}

              style={{
                display: "block",
                width: "100%",
                padding: "12px 14px",
                textAlign: "left",
                border: "none",
                background: T.white,
                color: T.navy,
                cursor: "pointer",
                fontSize: 14,
              }}
            >
              {trade.name}
            </button>
          ))
        ) : (
          <div style={{ padding: 12, color: T.muted, fontSize: 13 }}>
            No matching trades found
          </div>
        )}
      </div>
    )}
  </div>

  {errors.trade && (
    <p style={{ color: "red", fontSize: 12, marginTop: 4 }}>
      {errors.trade}
    </p>
  )}
</Field>

      </div>

      <Field
        label="Professional Summary"
        hint="2–4 lines about your experience and specialisation"
        required
      >
        <Textarea
          value={data.summary || ""}
          onChange={(e) => onChange("summary", e.target.value)}
          rows={4}
          maxLength={1000}
          placeholder="Describe your key skills and years of experience..."
        />

        <div
          style={{
            textAlign: "right",
            fontSize: "12px",
            color: "#6c757d",
            marginTop: "4px",
          }}
        >
          {(data.summary || "").length}/1000
        </div>
        {errors.summary && (
          <p style={{ color: "red", fontSize: "12px", marginTop: "4px" }}>
            {errors.summary}
          </p>
        )}
      </Field>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: "0 20px",
        }}
      >
        <Field label="Expected Salary (₹/month)" required>
          <Inp
            type="number"
            value={data.salaryExpectation || ""}
            onChange={(e) =>
              onChange("salaryExpectation", Number(e.target.value))
            }
            placeholder="Enter expected monthly salary"
            required
          />
          {errors.salaryExpectation && (
            <p style={{ color: "red", fontSize: "12px", marginTop: "4px" }}>
              {errors.salaryExpectation}
            </p>
          )}
        </Field>
        <Field label="Years of Experience" required>
          <Inp
            type="number"
            value={data.yearsOfExperience || ""}
            onChange={(e) =>
              onChange("yearsOfExperience", Number(e.target.value))
            }
            placeholder="Enter years of experience"
            min={0}
            max={50}
            required
          />
          {errors.yearsOfExperience && (
            <p style={{ color: "red", fontSize: "12px", marginTop: "4px" }}>
              {errors.yearsOfExperience}
            </p>
          )}
        </Field>
      </div>
    </div>
  );
};

// ─── STEP 3 — Work Experience ─────────────────────────────────────────────────
// Pulls a 4-digit year (19xx/20xx) out of the free-text "Year / Details"
// field (e.g. "Passed: 2014 | Cert No: ITI/2014" or just "2021") so it can
// be saved as the actual passoutYear the employer-facing profile displays.
const extractYear = (text) => {
  const match = String(text || "").match(/\b(19|20)\d{2}\b/);
  return match ? Number(match[0]) : 0;
};

const NOTICE_PERIOD_OPTIONS = [
  "Immediate",
  "15 Days",
  "30 Days",
  "45 Days",
  "60 Days",
  "90 Days",
  "More than 90 Days",
];

const AVAILABILITY_OPTIONS = [
  "0.5 Months",
  "1 Month",
  "1.5 Months",
  "2 Months",
  "2.5 Months",
  "3 Months",
  "3+ Months",
];

const StepWork = ({ data, onUpdate, onAdd, onRemove }) => {
  const [showForm, setShowForm] = useState(false);
  const today = new Date().toISOString().split("T")[0];
  const [newEntry, setNewEntry] = useState({
    title: "",
    company: "",
    location: "",
    startDate: "",
    endDate: "",
    current: false,
    noticePeriod: "",
    isOffshore: false,
    description: "",
  });
  const showToast = useToast();

  const handleSave = async () => {
    if (!newEntry.title.trim() || !newEntry.company.trim()) {
      showToast(
        "Role and company name are required.",
        "error"
      );
      return;
    }

    if (!newEntry.startDate) {
      showToast("Start date is required.", "error");
      return;
    }

    // Start date cannot be in the future
    if (newEntry.startDate > today) {
      showToast(
        "Start date cannot be a future date.",
        "error"
      );
      return;
    }

    // End date required for previous employment
    if (!newEntry.current && !newEntry.endDate) {
      showToast(
        "End date is required unless this is your current job.",
        "error"
      );
      return;
    }

    if (!newEntry.current && newEntry.endDate) {
      // End date cannot be in the future
      if (newEntry.endDate > today) {
        showToast(
          "End date cannot be a future date.",
          "error"
        );
        return;
      }

      // End date cannot be before start date
      if (newEntry.endDate < newEntry.startDate) {
        showToast(
          "End date cannot be earlier than start date.",
          "error"
        );
        return;
      }
    }

    // Notice period required for current job
    if (
      newEntry.current &&
      !newEntry.noticePeriod
    ) {
      showToast(
        "Please select your notice period.",
        "error"
      );
      return;
    }

    const payload = {
      ...newEntry,

      // Ensure current jobs never save an old end date
      endDate: newEntry.current
        ? ""
        : newEntry.endDate,
    };

    const saved = await onAdd(payload);

    if (!saved) return;

    setNewEntry({
      title: "",
      company: "",
      location: "",
      startDate: "",
      endDate: "",
      current: false,
      noticePeriod: "",
      isOffshore: false,
      description: "",
    });

    setShowForm(false);
  };

  return (
    <div>
      <h4 style={{ color: T.navy, marginBottom: 6, marginTop: 0 }}>
        Work Experience
      </h4>
      <p
        style={{ color: T.muted, fontSize: 14, marginBottom: 24, marginTop: 0 }}
      >
        Add your employment history — most recent first
      </p>

      {data.workHistory.map((entry) => (
        <Card key={entry.id}>
          <div
            style={{
              display: "flex",
              alignItems: "flex-start",
              justifyContent: "space-between",
              gap: 12,
              marginBottom: 12,
            }}
          >
            <div>
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "1fr 1fr",
                  gap: "0 16px",
                }}
              >
                <Field label="Job Title" required>
                  <Inp
                    value={entry.title}
                    onChange={(e) =>
                      onUpdate(entry.id, "title", e.target.value)
                    }
                  />
                </Field>
                <Field label="Company Name" required>
                  <Inp
                    value={entry.company}
                    onChange={(e) =>
                      onUpdate(entry.id, "company", e.target.value)
                    }
                  />
                </Field>
              </div>
              <Field label="Location">
                <Inp
                  value={entry.location}
                  onChange={(e) =>
                    onUpdate(entry.id, "location", e.target.value)
                  }
                  placeholder="City, State"
                />
              </Field>
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "1fr 1fr",
                  gap: "0 16px",
                }}
              >
                <Field label="Start Date">
                  <Inp
                    type="date"
                    value={entry.startDate || ""}
                    max={today}
                    onChange={(e) => {
                      const newStartDate = e.target.value;

                      onUpdate(entry.id, "startDate", newStartDate);

                      // If existing end date becomes earlier than new start date,
                      // clear the invalid end date.
                      if (
                        entry.endDate &&
                        newStartDate &&
                        entry.endDate < newStartDate
                      ) {
                        onUpdate(entry.id, "endDate", "");
                      }
                    }}
                  />
                </Field>

                <Field label="End Date">
                  <Inp
                    type="date"
                    value={entry.endDate || ""}
                    min={entry.startDate || ""}
                    max={today}
                    onChange={(e) =>
                      onUpdate(
                        entry.id,
                        "endDate",
                        e.target.value
                      )
                    }
                    disabled={entry.current}
                  />
                </Field>
              </div>

              <div style={{ marginBottom: 12 }}>
                <label
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 8,
                    fontSize: 13,
                    color: T.text,
                    cursor: "pointer",
                  }}
                >
                  <input
                    type="checkbox"
                    checked={!!entry.current}
                    onChange={(e) => {
                      const checked = e.target.checked;

                      onUpdate(entry.id, "current", checked);

                      if (checked) {
                        onUpdate(entry.id, "endDate", "");
                      }
                    }}
                    style={{
                      width: 16,
                      height: 16,
                      accentColor: T.orange,
                    }}
                  />
                  Currently working here
                </label>
              </div>

              {entry.current && (
                <Field label="Notice Period" required>
                  <Sel
                    value={entry.noticePeriod || ""}
                    onChange={(e) =>
                      onUpdate(entry.id, "noticePeriod", e.target.value)
                    }
                  >
                    <option value="">Select notice period…</option>
                    {NOTICE_PERIOD_OPTIONS.map((opt) => (
                      <option key={opt} value={opt}>
                        {opt}
                      </option>
                    ))}
                  </Sel>
                </Field>
              )}
              <div style={{ marginBottom: 12 }}>
                <label
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 8,
                    fontSize: 13,
                    color: T.text,
                    cursor: "pointer",
                  }}
                >
                  <input
                    type="checkbox"
                    checked={!!entry.isOffshore}
                    onChange={(e) =>
                      onUpdate(entry.id, "isOffshore", e.target.checked)
                    }
                    style={{
                      width: 16,
                      height: 16,
                      accentColor: T.orange,
                    }}
                  />
                  Offshore Experience
                </label>
              </div>

              <Field label="Description">
                <Textarea
                  value={entry.description}
                  onChange={(e) =>
                    onUpdate(entry.id, "description", e.target.value)
                  }
                  rows={3}
                  maxLength={1000}
                />

                <div
                  style={{
                    textAlign: "right",
                    fontSize: "12px",
                    color: "#6c757d",
                    marginTop: "4px",
                  }}
                >
                  {(entry.description || "").length}/1000
                </div>
              </Field>
            </div>
            <button
              onClick={() => onRemove(entry.id)}
              style={{
                background: T.errorBg,
                border: "none",
                borderRadius: 7,
                padding: "6px 10px",
                cursor: "pointer",
                color: T.error,
                fontSize: 13,
                fontWeight: 600,
                flexShrink: 0,
                display: "inline-flex",
                alignItems: "center",
                gap: 6,
              }}
            >
              <i className="fi-rr-cross-small" aria-hidden="true" />
              Remove
            </button>
          </div>
        </Card>
      ))}

      {showForm && (
        <Card
          style={{
            background: "#fffbf0",
            border: `1.5px dashed ${T.orangeLight}`,
          }}
        >
          <h6 style={{ margin: "0 0 16px", color: T.navy }}>New Work Entry</h6>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              gap: "0 16px",
            }}
          >
            <Field label="Job Title" required>
              <Inp
                value={newEntry.title}
                onChange={(e) =>
                  setNewEntry((p) => ({ ...p, title: e.target.value }))
                }
              />
            </Field>
            <Field label="Company Name" required>
              <Inp
                value={newEntry.company}
                onChange={(e) =>
                  setNewEntry((p) => ({ ...p, company: e.target.value }))
                }
              />
            </Field>
          </div>
          <Field label="Location">
            <Inp
              value={newEntry.location}
              onChange={(e) =>
                setNewEntry((p) => ({ ...p, location: e.target.value }))
              }
              placeholder="City, State"
            />
          </Field>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              gap: "0 16px",
            }}
          >
            <Field label="Start Date">
              <Inp
                type="date"
                value={newEntry.startDate}
                max={today}
                onChange={(e) => {
                  const newStartDate = e.target.value;

                  setNewEntry((prev) => ({
                    ...prev,
                    startDate: newStartDate,

                    // Clear end date if it is now before start date
                    endDate:
                      prev.endDate &&
                        newStartDate &&
                        prev.endDate < newStartDate
                        ? ""
                        : prev.endDate,
                  }));
                }}
              />
            </Field>
            <Field label="End Date">
              <Inp
                type="date"
                value={newEntry.endDate}
                min={newEntry.startDate || ""}
                max={today}
                onChange={(e) =>
                  setNewEntry((prev) => ({
                    ...prev,
                    endDate: e.target.value,
                  }))
                }
                disabled={newEntry.current}
              />
            </Field>
          </div>
          <div style={{ marginBottom: 14 }}>
            <label
              style={{
                display: "flex",
                alignItems: "center",
                gap: 8,
                fontSize: 13,
                color: T.text,
                cursor: "pointer",
              }}
            >
              <input
                type="checkbox"
                checked={!!newEntry.current}
                onChange={(e) => {
                  const checked = e.target.checked;

                  setNewEntry((prev) => ({
                    ...prev,
                    current: checked,

                    // Current job should not have an end date
                    endDate: checked ? "" : prev.endDate,
                  }));
                }}
                style={{ width: 16, height: 16, accentColor: T.orange }}
              />
              Currently working here
            </label>
          </div>
          {newEntry.current && (
            <Field label="Notice Period" required>
              <Sel
                value={newEntry.noticePeriod || ""}
                onChange={(e) =>
                  setNewEntry((p) => ({
                    ...p,
                    noticePeriod: e.target.value,
                  }))
                }
              >
                <option value="">Select notice period…</option>
                {NOTICE_PERIOD_OPTIONS.map((opt) => (
                  <option key={opt} value={opt}>
                    {opt}
                  </option>
                ))}
              </Sel>
            </Field>
          )}

          <div style={{ marginBottom: 12 }}>
            <label
              style={{
                display: "flex",
                alignItems: "center",
                gap: 8,
                fontSize: 13,
                color: T.text,
                cursor: "pointer",
              }}
            >
              <input
                type="checkbox"
                checked={!!newEntry.isOffshore}
                onChange={(e) =>
                  setNewEntry((p) => ({
                    ...p,
                    isOffshore: e.target.checked,
                  }))
                }
                style={{
                  width: 16,
                  height: 16,
                  accentColor: T.orange,
                }}
              />
              Offshore Experience
            </label>
          </div>

          {/* <Field label="Description">
    <Textarea
      value={newEntry.description}
      onChange={e =>
        setNewEntry(p => ({
          ...p,
          description: e.target.value
        }))
      }
      rows={3}
    />
  </Field> */}

          <Field label="Description">
            <Textarea
              value={newEntry.description}
              onChange={(e) =>
                setNewEntry((p) => ({
                  ...p,
                  description: e.target.value,
                }))
              }
              rows={3}
              maxLength={1000}
            />

            <div
              style={{
                textAlign: "right",
                fontSize: "12px",
                color: "#6c757d",
                marginTop: "4px",
              }}
            >
              {(newEntry.description || "").length}/1000
            </div>
          </Field>
          <div style={{ display: "flex", gap: 10, marginTop: 4 }}>
            <Btn onClick={handleSave}>Save Entry</Btn>
            <Btn variant="ghost" onClick={() => setShowForm(false)}>
              Cancel
            </Btn>
          </div>
        </Card>
      )}

      {!showForm && (
        <button
          onClick={() => setShowForm(true)}
          style={{
            width: "100%",
            padding: "14px",
            border: `2px dashed ${T.border}`,
            background: "transparent",
            borderRadius: 10,
            cursor: "pointer",
            color: T.orange,
            fontSize: 14,
            fontWeight: 600,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
            transition: "all .15s",
          }}
          onMouseEnter={(e) => {
            e.target.style.borderColor = T.orange;
            e.target.style.background = "#fffbf0";
          }}
          onMouseLeave={(e) => {
            e.target.style.borderColor = T.border;
            e.target.style.background = "transparent";
          }}
        >
          <i className="fi-rr-add" aria-hidden="true" />
          Add Work Experience
        </button>
      )}
    </div>
  );
};

// ─── STEP 4 — Education ───────────────────────────────────────────────────────
const StepEducation = ({ data, onUpdate, onAdd, onRemove }) => {
  const [showForm, setShowForm] = useState(false);
  const [newEntry, setNewEntry] = useState({
    title: "",
    institution: "",
    meta: "",
  });
  const showToast = useToast();

  const handleSave = () => {
    if (!newEntry.title) {
      showToast("Qualification title is required.", "error");
      return;
    }
    onAdd(newEntry);
    setNewEntry({ title: "", institution: "", meta: "" });
    setShowForm(false);
  };

  return (
    <div>
      <h4 style={{ color: T.navy, marginBottom: 6, marginTop: 0 }}>
        Education & Qualifications
      </h4>
      <p
        style={{ color: T.muted, fontSize: 14, marginBottom: 24, marginTop: 0 }}
      >
        List your degrees, certificates, and training courses
      </p>

      {data.education.map((entry) => (
        <Card key={entry.id}>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              gap: 12,
            }}
          >
            <div style={{ flex: 1 }}>
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "1fr 1fr",
                  gap: "0 16px",
                }}
              >
                <Field label="Qualification / Degree" required>
                  <Inp
                    value={entry.title}
                    onChange={(e) =>
                      onUpdate(entry.id, "title", e.target.value)
                    }
                  />
                </Field>
                <Field label="Institute / Board">
                  <Inp
                    value={entry.institution}
                    onChange={(e) =>
                      onUpdate(entry.id, "institution", e.target.value)
                    }
                  />
                </Field>
              </div>
              <Field
                label="Year / Details"
                hint="E.g. Passed: 2014 | Cert No: ITI/2014"
              >
                <Inp
                  value={entry.meta}
                  onChange={(e) => onUpdate(entry.id, "meta", e.target.value)}
                  placeholder="Passed: 2014"
                />
              </Field>
              {entry.verified && (
                <span
                  style={{
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 5,
                    fontSize: 12,
                    color: T.success,
                    fontWeight: 600,
                  }}
                >
                  <i className="fi-rr-check" aria-hidden="true" />
                  AI Verified
                </span>
              )}
            </div>
            <button
              onClick={() => onRemove(entry.id)}
              style={{
                background: T.errorBg,
                border: "none",
                borderRadius: 7,
                padding: "6px 10px",
                cursor: "pointer",
                color: T.error,
                fontSize: 13,
                fontWeight: 600,
                flexShrink: 0,
                height: "fit-content",
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "center",
                gap: 6,
              }}
            >
              <i className="fi-rr-cross-small" aria-hidden="true" />
              Remove
            </button>
          </div>
        </Card>
      ))}

      {showForm && (
        <Card
          style={{
            background: "#fffbf0",
            border: `1.5px dashed ${T.orangeLight}`,
          }}
        >
          <h6 style={{ margin: "0 0 16px", color: T.navy }}>
            New Qualification
          </h6>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              gap: "0 16px",
            }}
          >
            <Field label="Qualification / Degree" required>
              <Inp
                value={newEntry.title}
                onChange={(e) =>
                  setNewEntry((p) => ({ ...p, title: e.target.value }))
                }
              />
            </Field>
            <Field label="Institute / Board">
              <Inp
                value={newEntry.institution}
                onChange={(e) =>
                  setNewEntry((p) => ({ ...p, institution: e.target.value }))
                }
              />
            </Field>
          </div>
          <Field label="Year / Details">
            <Inp
              value={newEntry.meta}
              onChange={(e) =>
                setNewEntry((p) => ({ ...p, meta: e.target.value }))
              }
              placeholder="Passed: 2014"
            />
          </Field>
          <div style={{ display: "flex", gap: 10 }}>
            <Btn onClick={handleSave}>Save</Btn>
            <Btn variant="ghost" onClick={() => setShowForm(false)}>
              Cancel
            </Btn>
          </div>
        </Card>
      )}

      {!showForm && (
        <button
          onClick={() => setShowForm(true)}
          style={{
            width: "100%",
            padding: "14px",
            border: `2px dashed ${T.border}`,
            background: "transparent",
            borderRadius: 10,
            cursor: "pointer",
            color: T.orange,
            fontSize: 14,
            fontWeight: 600,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
            transition: "all .15s",
          }}
          onMouseEnter={(e) => {
            e.target.style.borderColor = T.orange;
            e.target.style.background = "#fffbf0";
          }}
          onMouseLeave={(e) => {
            e.target.style.borderColor = T.border;
            e.target.style.background = "transparent";
          }}
        >
          <i className="fi-rr-add" aria-hidden="true" />
          Add Qualification
        </button>
      )}
    </div>
  );
};

// ─── STEP 5 — Skills ─────────────────────────────────────────────────────────
const StepSkills = ({ data, onToggle, onUpdateSkill }) => {
  const [customSkill, setCustomSkill] = useState("");
  const PROFICIENCY = ["Beginner", "Intermediate", "Expert"];
  const MAX_SKILLS = 30;

  const addCustom = () => {
    const skill = customSkill.trim();

    if (!skill) return;

    if ((data.selectedSkills || []).length >= MAX_SKILLS) {
      alert(`You can select a maximum of ${MAX_SKILLS} skills.`);
      return;
    }

    const exists = (data.selectedSkills || []).some(
      (s) => s.toLowerCase() === skill.toLowerCase()
    );

    if (exists) {
      alert("This skill is already selected.");
      return;
    }

    onToggle(skill);
    setCustomSkill("");
  };

  return (
    <div>
      <h4 style={{ color: T.navy, marginBottom: 6, marginTop: 0 }}>Skills</h4>
      <p
        style={{ color: T.muted, fontSize: 14, marginBottom: 24, marginTop: 0 }}
      >
        Select your trade skills and set your proficiency level
      </p>

      {/* Suggested skills */}
      <Card>
        <p
          style={{
            fontSize: 12,
            fontWeight: 700,
            color: T.navy,
            textTransform: "uppercase",
            letterSpacing: "0.04em",
            margin: "0 0 14px",
          }}
        >
          Tap to select skills
        </p>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
          {(data.suggestedSkills || []).map((skill) => {
            const selected = (data.selectedSkills || []).includes(skill);
            return (
              <button
                key={skill}
                disabled={
                  !selected &&
                  (data.selectedSkills || []).length >= MAX_SKILLS
                }
                onClick={() => {
                  if (selected) {
                    onToggle(skill);
                    return;
                  }

                  onToggle(skill);
                }}
                style={{
                  padding: "7px 14px",
                  borderRadius: 20,
                  fontSize: 13,
                  fontWeight: 600,
                  cursor:
                    !selected &&
                      (data.selectedSkills || []).length >= MAX_SKILLS
                      ? "not-allowed"
                      : "pointer",
                  opacity:
                    !selected &&
                      (data.selectedSkills || []).length >= MAX_SKILLS
                      ? 0.5
                      : 1,
                  border: `1.5px solid ${selected ? T.orange : T.border}`,
                  background: selected ? T.orange : T.white,
                  color: selected ? T.white : T.text,
                }}
              >
                {skill}
              </button>
            );
          })}
        </div>
        <div style={{ marginTop: 16, display: "flex", gap: 8 }}>
          <Inp
            value={customSkill}
            onChange={(e) => setCustomSkill(e.target.value)}
            placeholder="Add a custom skill..."
            onKeyDown={(e) => e.key === "Enter" && addCustom()}
            style={{ flex: 1, height: 42 }}
          />
          <Btn
            onClick={addCustom}
            disabled={
              !customSkill.trim() ||
              (data.selectedSkills || []).length >= MAX_SKILLS
            }
            style={{ padding: "8px 16px" }}
          >
            + Add
          </Btn>
        </div>
      </Card>

      {/* Skill matrix */}
      {(data.skillMatrix || []).length > 0 && (
        <Card>
          <p
            style={{
              fontSize: 12,
              fontWeight: 700,
              color: T.navy,
              textTransform: "uppercase",
              letterSpacing: "0.04em",
              margin: "0 0 14px",
            }}
          >
            Set proficiency levels
          </p>
          {(data.skillMatrix || []).map((entry) => (
            <div
              key={entry.id}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 14,
                marginBottom: 12,
                padding: "12px 16px",
                background: T.bg,
                borderRadius: 8,
              }}
            >
              <span
                style={{
                  flex: 1,
                  fontSize: 14,
                  fontWeight: 600,
                  color: T.navy,
                }}
              >
                {entry.name}
              </span>
              <div style={{ display: "flex", gap: 6 }}>
                {PROFICIENCY.map((p) => (
                  <button
                    key={p}
                    onClick={() => onUpdateSkill(entry.id, "proficiency", p)}
                    style={{
                      padding: "4px 12px",
                      borderRadius: 20,
                      fontSize: 12,
                      fontWeight: 600,
                      cursor: "pointer",
                      border: `1.5px solid ${entry.proficiency === p ? T.orange : T.border}`,
                      background: entry.proficiency === p ? T.orange : T.white,
                      color: entry.proficiency === p ? T.white : T.muted,
                      transition: "all .12s",
                    }}
                  >
                    {p}
                  </button>
                ))}
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <Inp
                  type="number"
                  value={entry.years}
                  min={0}
                  max={40}
                  onChange={(e) =>
                    onUpdateSkill(entry.id, "years", Number(e.target.value))
                  }
                  style={{ width: 70, height: 36, textAlign: "center" }}
                />
                <span
                  style={{ fontSize: 12, color: T.muted, whiteSpace: "nowrap" }}
                >
                  yrs
                </span>
              </div>
              <button
                onClick={() => onToggle(entry.name)}
                style={{
                  background: "none",
                  border: "none",
                  cursor: "pointer",
                  color: T.muted,
                  fontSize: 18,
                  display: "inline-flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <i className="fi-rr-cross-small" aria-hidden="true" />
              </button>
            </div>
          ))}
        </Card>
      )}

      <p
        style={{
          fontSize: 12,
          color:
            (data.selectedSkills || []).length >= MAX_SKILLS
              ? "#dc3545"
              : T.muted,
          fontWeight: 500,
        }}
      >
        {(data.selectedSkills || []).length}/{MAX_SKILLS} skills selected
      </p>
    </div>
  );
};

// ─── STEP 2 — Documents ───────────────────────────────────────────────────────
const DocUploadBox = ({ doc, docKey, onUpload, onClear }) => {
  const statusColors = {
    verified: {
      bg: "#e8f0fe",
      color: "#1a56c4",
      border: "#c7dcff",
      label: "Verified",
      iconClass: "fi-rr-check",
    },
    uploaded: {
      bg: "#e8f0fe",
      color: "#1a56c4",
      border: "#c7dcff",
      label: "Uploaded",
      iconClass: "fi-rr-check",
    },
    missing: {
      bg: "#e8f0fe",
      color: "#1a56c4",
      border: "#c7dcff",
      label: "Required",
      iconClass: "fi-rr-exclamation",
    },
    optional: {
      bg: "#e8f0fe",
      color: "#1a56c4",
      border: "#c7dcff",
      label: "Optional",
      iconClass: null,
    },
  };
  const s = statusColors[doc.status] || statusColors.optional;

  return (
    <Card style={{ padding: "16px 20px" }}>
      <div
        style={{
          display: "flex",
          alignItems: "flex-start",
          justifyContent: "space-between",
          gap: 16,
        }}
      >
        <div style={{ flex: 1 }}>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 10,
              marginBottom: 4,
            }}
          >
            <span style={{ fontWeight: 700, fontSize: 14, color: T.navy }}>
              {doc.label}
            </span>
            <span
              style={{
                padding: "2px 10px",
                borderRadius: 20,
                fontSize: 11,
                fontWeight: 700,
                background: s.bg,
                color: s.color,
                border: `1px solid ${s.border}`,
                display: "inline-flex",
                alignItems: "center",
                gap: 5,
              }}
            >
              {s.iconClass && (
                <i
                  className={s.iconClass}
                  aria-hidden="true"
                  style={{ fontSize: 10, lineHeight: 1 }}
                />
              )}
              {s.label}
            </span>
          </div>
          <p style={{ fontSize: 12, color: T.muted, margin: "0 0 8px" }}>
            {doc.description}
          </p>
          {doc.metaLines &&
            doc.metaLines.map((m, i) => (
              <p
                key={i}
                style={{ fontSize: 11, color: T.muted, margin: "2px 0" }}
              >
                {m}
              </p>
            ))}
          {(doc.file || doc.frontFile) && (
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 8,
                marginTop: 8,
                padding: "8px 12px",
                background: T.bg,
                borderRadius: 7,
              }}
            >
              <span
                style={{
                  fontSize: 13,
                  color: T.navy,
                  fontWeight: 500,
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 6,
                }}
              >
                <i className="fi-rr-clip" aria-hidden="true" />
                {(doc.file || doc.frontFile).name}
              </span>
              <span style={{ fontSize: 11, color: T.muted }}>
                {(doc.file || doc.frontFile).size}
              </span>
              {doc.status !== "verified" && (
                <button
                  onClick={() => onClear(docKey)}
                  style={{
                    marginLeft: "auto",
                    background: "none",
                    border: "none",
                    color: T.error,
                    cursor: "pointer",
                    fontSize: 13,
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 4,
                  }}
                >
                  <i className="fi-rr-cross-small" aria-hidden="true" />
                  Remove
                </button>
              )}
            </div>
          )}
        </div>
        {doc.status !== "verified" && doc.type !== "readonly" && (
          <div>
            <input
              type="file"
              id={`upload-${docKey}`}
              onChange={(e) =>
                e.target.files[0] && onUpload(docKey, e.target.files[0])
              }
              accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
              style={{ display: "none" }}
            />
            <label
              htmlFor={`upload-${docKey}`}
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: 6,
                padding: "8px 14px",
                background: T.bg,
                border: `1.5px solid ${T.border}`,
                borderRadius: 8,
                fontSize: 13,
                fontWeight: 600,
                cursor: "pointer",
                color: T.navy,
                whiteSpace: "nowrap",
              }}
            >
              <i className="fi-rr-upload" aria-hidden="true" />
              Upload
            </label>
          </div>
        )}
      </div>
    </Card>
  );
};

const StepDocuments = ({ data, onUpload, onClear }) => (
  <div>
    <h4 style={{ color: T.navy, marginBottom: 6, marginTop: 0 }}>Documents</h4>
    <p style={{ color: T.muted, fontSize: 14, marginBottom: 24, marginTop: 0 }}>
      Upload your certificates and ID proof for faster hiring
    </p>
    {Object.entries(data.documents).map(([key, doc]) => (
      <DocUploadBox
        key={key}
        doc={doc}
        docKey={key}
        onUpload={onUpload}
        onClear={onClear}
      />
    ))}
  </div>
);

// ─── STEP 6 — Languages ───────────────────────────────────────────────────────
const LANG_OPTIONS = [
  "Hindi",
  "English",
  "Marathi",
  "Tamil",
  "Telugu",
  "Kannada",
  "Malayalam",
  "Bengali",
  "Gujarati",
  "Punjabi",
  "Urdu",
  "Arabic",
  "Nepali",
];
const PROF_LEVELS = ["Beginner", "Conversational", "Professional", "Native"];

const StepLanguages = ({ data, onAdd, onRemove, onUpdate }) => {
  const [newLang, setNewLang] = useState("");
  const handleAdd = () => {
    if (!newLang) return;
    onAdd({
      name: newLang,
      proficiency: "Conversational",
      reading: true,
      writing: true,
      speaking: true,
    });
    setNewLang("");
  };

  return (
    <div>
      <h4 style={{ color: T.navy, marginBottom: 6, marginTop: 0 }}>
        Language Preferences
      </h4>
      <p
        style={{ color: T.muted, fontSize: 14, marginBottom: 24, marginTop: 0 }}
      >
        Languages you can communicate in
      </p>

      {(data.languages || []).map((lang) => (
        <Card key={lang.name}>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              gap: 12,
            }}
          >
            <span
              style={{
                fontWeight: 700,
                fontSize: 14,
                color: T.navy,
                minWidth: 90,
              }}
            >
              {lang.name}
            </span>
            <div style={{ display: "flex", gap: 12, flex: 1 }}>
              {["reading", "writing", "speaking"].map((skill) => (
                <label
                  key={skill}
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    gap: 4,
                    fontSize: 11,
                    color: T.muted,
                    cursor: "pointer",
                    textTransform: "capitalize",
                  }}
                >
                  <input
                    type="checkbox"
                    checked={!!lang[skill]}
                    onChange={(e) =>
                      onUpdate(lang.name, skill, e.target.checked)
                    }
                    style={{ width: 16, height: 16, accentColor: T.orange }}
                  />
                  {skill}
                </label>
              ))}
            </div>
            <button
              onClick={() => onRemove(lang.name)}
              style={{
                background: "none",
                border: "none",
                cursor: "pointer",
                color: T.muted,
                fontSize: 18,
                padding: "0 4px",
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <i className="fi-rr-cross-small" aria-hidden="true" />
            </button>
          </div>
        </Card>
      ))}

      <Card
        style={{
          background: "#fffbf0",
          border: `1.5px dashed ${T.orangeLight}`,
        }}
      >
        <p
          style={{
            fontSize: 12,
            fontWeight: 700,
            color: T.navy,
            margin: "0 0 12px",
            textTransform: "uppercase",
          }}
        >
          Add Language
        </p>
        <div style={{ display: "flex", gap: 10, alignItems: "flex-end" }}>
          <div style={{ flex: 1 }}>
            <Sel
              value={newLang}
              onChange={(e) => setNewLang(e.target.value)}
              style={{ height: 44 }}
            >
              <option value="">Select language</option>
              {LANG_OPTIONS.filter(
                (l) => !(data.languages || []).find((x) => x.name === l),
              ).map((l) => (
                <option key={l}>{l}</option>
              ))}
            </Sel>
          </div>
          <Btn
            onClick={handleAdd}
            disabled={!newLang}
            style={{ height: 44, padding: "0 20px", gap: 6 }}
          >
            <i className="fi-rr-add" aria-hidden="true" />
            Add
          </Btn>
        </div>
      </Card>
    </div>
  );
};

// Maps each profile-completion checklist item to the wizard step that
// actually lets the candidate fix it (see stepContent() switch below:
// 1=Personal, 2=Documents, 3=Work, 4=Education, 5=Skills, 6=Languages).
const COMPLETION_ITEM_TO_STEP = {
  photo: 1,
  personalInfo: 1,
  summary: 1,
  resume: 2,
  aadhaar: 2,
  passport: 2,
  workHistory: 3,
  education: 4,
  skills: 5,
};

// ─── Completion Summary (final step done) ────────────────────────────────────
const CompletionSummary = ({
  completion,
  onEdit,
  onNavigateToItem,
  router,
}) => {
  const percent = completion?.overallPct || 0;

  const completedItems =
    completion?.items?.filter((item) => item.completed) || [];

  const pendingItems =
    completion?.items?.filter((item) => !item.completed) || [];

  return (
    <div
      style={{
        maxWidth: 700,
        margin: "0 auto",
        padding: "30px 20px",
      }}
    >
      {/* Success Icon */}
      <div style={{ textAlign: "center" }}>
        <div
          style={{
            width: 90,
            height: 90,
            borderRadius: "50%",
            background: "#EAF7EC",
            border: "3px solid #4CAF50",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            margin: "0 auto 20px",
            fontSize: 36,
            color: "#4CAF50",
          }}
        >
          ✓
        </div>

        <h2
          style={{
            color: "#122359",
            marginBottom: 10,
          }}
        >
          Profile Completion
        </h2>

        <p
          style={{
            color: "#66789C",
            marginBottom: 30,
          }}
        >
          Your profile is{" "}
          <strong style={{ color: "#FFA300" }}>
            {percent}% complete
          </strong>
        </p>
      </div>

      {/* Progress Card */}
      <div
        style={{
          background: "#fff",
          border: "1px solid #E8ECF0",
          borderRadius: 16,
          padding: 24,
          marginBottom: 24,
          boxShadow: "0 8px 24px rgba(18,35,89,.05)",
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            marginBottom: 12,
            fontWeight: 600,
          }}
        >
          <span>Profile Strength</span>

          <span style={{ color: "#FFA300" }}>
            {percent}%
          </span>
        </div>

        <div
          style={{
            height: 10,
            background: "#EEF2F6",
            borderRadius: 20,
            overflow: "hidden",
          }}
        >
          <div
            style={{
              width: `${percent}%`,
              height: "100%",
              background: "#FFA300",
              borderRadius: 20,
            }}
          />
        </div>
      </div>

      {/* Checklist */}
      <div
        style={{
          background: "#fff",
          borderRadius: 16,
          border: "1px solid #E8ECF0",
          padding: 24,
          boxShadow: "0 8px 24px rgba(18,35,89,.05)",
        }}
      >
        <h4
          style={{
            marginBottom: 20,
            color: "#122359",
          }}
        >
          Complete Your Profile
        </h4>

        {completedItems.map((item) => (
          <div
            key={item.key}
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              padding: "12px 0",
              borderBottom: "1px solid #F3F4F6",
            }}
          >
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 12,
              }}
            >
              <div
                style={{
                  width: 28,
                  height: 28,
                  borderRadius: "50%",
                  background: "#EAF7EC",
                  color: "#28A745",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontWeight: 700,
                }}
              >
                ✓
              </div>

              <span>{item.label}</span>
            </div>

            <span
              style={{
                color: "#28A745",
                fontWeight: 600,
                fontSize: 13,
              }}
            >
              Completed
            </span>
          </div>
        ))}

        {pendingItems.map((item) => (
          <div
            key={item.key}
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              padding: "12px 0",
              borderBottom: "1px solid #F3F4F6",
            }}
          >
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 12,
              }}
            >
              <div
                style={{
                  width: 28,
                  height: 28,
                  borderRadius: "50%",
                  background: "#FFF5E8",
                  color: "#FFA300",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontWeight: 700,
                }}
              >
                !
              </div>

              <div>
                <div
                  style={{
                    fontWeight: 600,
                  }}
                >
                  {item.label}
                </div>

                <div
                  style={{
                    fontSize: 13,
                    color: "#66789C",
                  }}
                >
                  {item.actionHint}
                </div>
              </div>
            </div>

            <button
              onClick={() => onNavigateToItem?.(item.key)}
              style={{
                border: "none",
                background: "#FFF5E8",
                color: "#FFA300",
                padding: "8px 16px",
                borderRadius: 8,
                cursor: "pointer",
                fontWeight: 600,
              }}
            >
              Pending
            </button>
          </div>
        ))}
      </div>

      <div
        style={{
          display: "flex",
          justifyContent: "center",
          gap: 15,
          marginTop: 30,
        }}
      >
        <Btn variant="outline" onClick={onEdit}>
          Edit Profile
        </Btn>

        <Btn onClick={() => router.push("/jobs-list")}>
          Browse Jobs
        </Btn>
      </div>
    </div>
  );
};

// ─── Availability toggle (lives in the profile sidebar) ─────────────────────
const AvailabilityToggle = ({
  available,
  availableIn,
  onToggle,
  onAvailableInChange,
  bordered = true,
}) => (
  <div
    style={{
      padding: "12px 20px",
      background: T.white,
      borderBottom: bordered ? `1px solid ${T.border}` : "none",
    }}
  >
    <div
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: 10,
      }}
    >
      <div style={{ minWidth: 0 }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: T.navy }}>
          {available ? "Available now" : "Not available"}
        </div>
        <div style={{ fontSize: 11, color: T.muted, marginTop: 2 }}>
          {available ? "Visible to employers" : "Hidden from employers"}
        </div>
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={!!available}
        aria-label="Available now"
        onClick={() => onToggle(!available)}
        style={{
          position: "relative",
          width: 40,
          height: 22,
          borderRadius: 11,
          border: "none",
          padding: 0,
          flexShrink: 0,
          cursor: "pointer",
          background: available ? T.orange : "#cfd6e4",
          transition: "background .2s",
        }}
      >
        <span
          style={{
            position: "absolute",
            top: 2,
            left: 2,
            width: 18,
            height: 18,
            borderRadius: "50%",
            background: T.white,
            boxShadow: "0 1px 3px rgba(0,0,0,0.25)",
            transform: available ? "translateX(18px)" : "translateX(0)",
            transition: "transform .2s",
          }}
        />
      </button>
    </div>

    {!available && (
      <div style={{ marginTop: 10 }}>
        <div
          style={{
            fontSize: 11,
            fontWeight: 600,
            color: T.navy,
            marginBottom: 5,
          }}
        >
          When will you be available?
          <span style={{ color: T.error, marginLeft: 3 }}>*</span>
        </div>
        <select
          value={availableIn || ""}
          onChange={(e) => onAvailableInChange(e.target.value)}
          style={{
            width: "100%",
            padding: "7px 10px",
            fontSize: 12,
            color: T.navy,
            background: T.white,
            border: `1px solid ${T.border}`,
            borderRadius: 8,
            outline: "none",
          }}
        >
          <option value="">Select availability</option>
          {AVAILABILITY_OPTIONS.map((option) => (
            <option key={option} value={option}>
              {option}
            </option>
          ))}
        </select>
      </div>
    )}
  </div>
);

// ─── Profile Sidebar (progress overview) ─────────────────────────────────────
const ProfileMini = ({
  data,
  percent,
  currentStep,
  onJump,
  completedSteps,
  onAvailabilityToggle,
  onAvailableInChange,
}) => (
  <div
    style={{
      background: T.white,
      border: `1px solid ${T.border}`,
      borderRadius: 14,
      overflow: "hidden",
      position: "sticky",
      top: 90,
    }}
  >
    {/* Header banner */}
    <div
      style={{
        background: `linear-gradient(135deg, ${T.navy} 0%, #1e3a8a 100%)`,
        padding: "24px 20px",
        textAlign: "center",
      }}
    >
      <div
        style={{
          width: 68,
          height: 68,
          borderRadius: "50%",
          overflow: "hidden",
          border: `3px solid ${T.orange}`,
          margin: "0 auto 12px",
          background: T.bg,
        }}
      >
        <img
          src={data.avatar || DEFAULT_PROFILE_PHOTO}
          alt="Profile"
          onError={(e) => {
            e.currentTarget.src =
              getStoredProfilePhotoPreview() || DEFAULT_PROFILE_PHOTO;
          }}
          style={{ width: "100%", height: "100%", objectFit: "cover" }}
        />
      </div>
      <div style={{ color: T.white, fontWeight: 700, fontSize: 15 }}>
        {data.firstName} {data.lastName}
      </div>
      <div style={{ color: T.orangeLight, fontSize: 12, marginTop: 4 }}>
        {data.trade}
      </div>
      <div style={{ marginTop: 14 }}>
        <div
          style={{
            fontSize: 11,
            color: "rgba(255,255,255,0.6)",
            marginBottom: 6,
          }}
        >
          Profile Strength
        </div>
        <div
          style={{
            height: 5,
            background: "rgba(255,255,255,0.2)",
            borderRadius: 3,
            overflow: "hidden",
          }}
        >
          <div
            style={{
              height: "100%",
              width: `${percent}%`,
              background: T.orange,
              borderRadius: 3,
              transition: "width .5s",
            }}
          />
        </div>
        <div
          style={{
            fontSize: 13,
            fontWeight: 700,
            color: T.orange,
            marginTop: 4,
          }}
        >
          {percent}%
        </div>
      </div>
    </div>

    {/* Availability */}
    {onAvailabilityToggle && (
      <AvailabilityToggle
        available={data.availableForWork}
        availableIn={data.availableIn}
        onToggle={onAvailabilityToggle}
        onAvailableInChange={onAvailableInChange}
      />
    )}

    {/* Steps list */}
    <div style={{ padding: "12px 0" }}>
      {STEPS.map((step, i) => {
        const n = i + 1;
        const done = completedSteps ? completedSteps.has(n) : n < currentStep;
        const active = n === currentStep;
        const canJump = typeof onJump === "function";
        return (
          <button
            key={step.id}
            onClick={() => canJump && onJump(n)}
            disabled={!canJump}
            style={{
              width: "100%",
              display: "flex",
              alignItems: "center",
              gap: 12,
              padding: "10px 20px",
              background: active ? "#fff8ec" : "transparent",
              border: "none",
              borderLeft: active
                ? `3px solid ${T.orange}`
                : "3px solid transparent",
              cursor: canJump ? "pointer" : "default",
              textAlign: "left",
              transition: "all .15s",
            }}
          >
            <span
              style={{
                fontSize: 12,
                width: 22,
                height: 22,
                borderRadius: "50%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                flexShrink: 0,
                background: done ? T.success : active ? T.orange : T.bg,
                color: done || active ? T.white : T.muted,
                fontWeight: 700,
              }}
            >
              <i
                className={done ? "fi-rr-check" : step.iconClass}
                aria-hidden="true"
                style={{ fontSize: 11, lineHeight: 1, display: "inline-flex" }}
              />
            </span>
            <span
              style={{
                fontSize: 13,
                fontWeight: active ? 700 : 500,
                color: active ? T.orange : done ? T.navy : T.muted,
              }}
            >
              {step.label}
            </span>
          </button>
        );
      })}
    </div>
  </div>
);

// ─── Main Page ────────────────────────────────────────────────────────────────
const createId = (prefix) =>
  `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
const buildProfilePhotoUrl = (photoUrl) => {
  if (!photoUrl) return DEFAULT_PROFILE_PHOTO;

  const baseUrl = process.env.NEXT_PUBLIC_API_URL || "";
  const absoluteUrl = photoUrl.startsWith("http")
    ? photoUrl
    : `${baseUrl}${photoUrl}`;
  const separator = absoluteUrl.includes("?") ? "&" : "?";

  return `${absoluteUrl}${separator}t=${Date.now()}`;
};
const formatFileSize = (bytes) => {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
};

const CandidateProfilePage = () => {
  const candidateId = useMemo(() => {
    try {
      return getCandidateId();
    } catch {
      return null;
    }
  }, []);

  const showToast = useToast();
  const router = useRouter();
  const [itiInfo, setItiInfo] = useState(null);
  const [errors, setErrors] = useState({});

  const validatePersonalInfo = () => {
    const newErrors = {};

    // Name
    if (!profileData.firstName.trim()) {
      newErrors.firstName = "First name is required";
    }

    if (!profileData.lastName.trim()) {
      newErrors.lastName = "Last name is required";
    }

    // Mobile
    if (!profileData.mobile.trim()) {
      newErrors.mobile = "Mobile number is required";
    } else if (!/^\d{10}$/.test(profileData.mobile.replace(/\D/g, ""))) {
      newErrors.mobile = "Enter a valid 10-digit mobile number";
    }

    // Email
    if (!profileData.email.trim()) {
      newErrors.email = "Email is required";
    } else if (
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(profileData.email)
    ) {
      newErrors.email = "Enter a valid email address";
    }

    // DOB
    if (!profileData.dob) {
      newErrors.dob = "Date of birth is required";
    }

    // Gender
    if (!profileData.gender) {
      newErrors.gender = "Please select gender";
    }

    // Address
    if (!profileData.city.trim()) {
      newErrors.city = "City is required";
    }

    if (!profileData.state) {
      newErrors.state = "State is required";
    }

    if (!profileData.pin.trim()) {
      newErrors.pin = "PIN code is required";
    } else if (!/^\d{6}$/.test(profileData.pin)) {
      newErrors.pin = "PIN code must be 6 digits";
    }

    // Nationality
    if (!profileData.nationality.trim()) {
      newErrors.nationality = "Nationality is required";
    }

    // Trade
    if (!profileData.trade.trim()) {
      newErrors.trade = "Trade/Job Title is required";
    }

    const summary = profileData.summary.trim();

    if (!summary) {
      newErrors.summary = "Professional summary is required";
    } else if (summary.length > 500) {
      newErrors.summary =
        "Professional summary cannot exceed 500 characters";
    }

    // Salary
    if (
      !profileData.salaryExpectation ||
      profileData.salaryExpectation <= 0
    ) {
      newErrors.salaryExpectation =
        "Expected salary must be greater than 0";
    }

    // Experience
    if (
      profileData.yearsOfExperience === "" ||
      profileData.yearsOfExperience < 0
    ) {
      newErrors.yearsOfExperience =
        "Enter valid years of experience";
    }

    setErrors(newErrors);

    return Object.keys(newErrors).length === 0;
  };

  const [profileData, setProfileData] = useState(() => ({
    ...mockProfile,
    avatar: getStoredProfilePhotoPreview() || mockProfile.avatar,
    salaryExpectation: "",
    isITI: false,
    passportNumber: "",
    passportExpiry: "",
    id: "",
    firstName: "",
    lastName: "",
    fullName: "",
    mobile: "",
    email: "",
    trade: "",
    yearsOfExperience: "",
    nationality: "",
    dob: "",
    gender: "",
    city: "",
    state: "",
    pin: "",
    address: "",
    // role: "",
    category: "",
    country: "IN",
    hasDisability: false,
    disabilityNote: "",
    preferredWorkLocation: "",
    jobType: "",
    summary: "",
    availableForWork: false,
    availableIn: "",
    completionHint: "",
    sidebarBadges: [],
    workHistory: [],
    education: [],
    selectedSkills: [],
    skillMatrix: [],
    languages: [],
  }));
  const [currentStep, setCurrentStep] = useState(1);
  const [done, setDone] = useState(false);
  const [saving, setSaving] = useState(false);
  const [profileCompletion, setProfileCompletion] = useState(null);
  const [initialPersonalInfo, setInitialPersonalInfo] = useState(null);
  const [initialWorkHistory, setInitialWorkHistory] = useState([]);

  const loadAvailability = useCallback(async () => {
    if (!candidateId) return;

    try {
      const response = await getAvailability();

      if (response.data.success) {
        setProfileData((prev) => ({
          ...prev,
          availableForWork:
            response.data.data.availabilityStatus === "Available",
          availableIn:
            response.data.data.availableIn || "",
        }));
      }
    } catch (error) {
      console.error("Failed to load availability", error);
    }
  }, [candidateId]);
  useEffect(() => {
    loadAvailability();
  }, [loadAvailability]);
  //load ITI info from API
  const loadITIInfo = useCallback(async () => {
    if (!candidateId) return;

    try {
      const response = await getPersonalInfo();

      if (response.data.success) {
        setItiInfo(response.data.data);
      }
    } catch (error) {
      console.error(error);
    }
  }, [candidateId]);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    loadITIInfo();
  }, [loadITIInfo]);

  useEffect(() => {
    if (!itiInfo) return;

    // eslint-disable-next-line react-hooks/set-state-in-effect
    setProfileData((prev) => ({
      ...prev,
      documents: {
        ...prev.documents,

        itiCertificate: {
          label: "ITI Certificate",
          status: itiInfo.itiCertified ? "verified" : "missing",

          type: "readonly",

          description: itiInfo.itiTrade || "ITI Trade",

          metaLines: [
            `Primary Trade: ${itiInfo.primaryTrade}`,
            `Marks: ${itiInfo.itiMarks}`,
            `College: ${itiInfo.itiCollege}`,
          ],

          file: null,
        },
      },
    }));
  }, [itiInfo]);

  const loadProfileCompletion = useCallback(async () => {
    if (!candidateId) return;

    try {
      const [completionRes, uploadedDocsRes] = await Promise.all([
        getProfileCompletion(),
        getUploadedDocuments().catch(() => null),
      ]);

      if (completionRes.data.success) {
        let completionData = completionRes.data.data;

        // Check if there is any verified Aadhaar Card in the uploaded documents
        const uploadedDocs = uploadedDocsRes?.data?.documents || [];
        const isAadhaarVerified = uploadedDocs.some(
          (doc) =>
            (doc.documentType || "").toLowerCase().includes("aadhaar") &&
            doc.verificationStatus === "Verified"
        );

        if (isAadhaarVerified && completionData && Array.isArray(completionData.items)) {
          // Find Aadhaar item and mark it as completed
          completionData = {
            ...completionData,
            items: completionData.items.map((item) => {
              const isAadhaarItem =
                (item.key || "").toLowerCase().includes("aadhaar") ||
                (item.key || "").toLowerCase().includes("aadhar") ||
                (item.label || "").toLowerCase().includes("aadhaar") ||
                (item.label || "").toLowerCase().includes("aadhar");

              if (isAadhaarItem) {
                return { ...item, completed: true };
              }
              return item;
            }),
          };

          // Re-calculate overall percentage
          const completedCount = completionData.items.filter((item) => item.completed).length;
          const totalCount = completionData.items.length;
          completionData.overallPct = Math.round((completedCount / totalCount) * 100);
        }

        setProfileCompletion(completionData);
      }
    } catch (error) {
      console.error("Failed to load profile completion", error);
    }
  }, [candidateId]);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    loadProfileCompletion();
  }, [loadProfileCompletion]);



  //Loading profile data from API
  const loadPersonalInfo = useCallback(async () => {
    if (!candidateId) return;

    try {
      const response = await api.get(
        `/api/candidate/profile/personal-info?candidateId=${candidateId}`,
      );

      console.log("PROFILE DATA", response.data);

      if (response.data.success) {
        const profile = response.data.data;
        const country = COUNTRY_MAP[profile.countryCode] || "IN";
        // console.log("profilePhotoUrl =", profile.profilePhotoUrl);
        const names = profile.fullName ? profile.fullName.split(" ") : [];
        const personalInfoData = {
          firstName: names[0] || "",
          lastName: names.slice(1).join(" ") || "",
          mobile: profile.mobileNumber || "",
          trade: profile.role || profile.jobTitle || "",
tradeCategoryId: profile.tradeCategoryId || null,
          nationality: profile.nationality || "",
          dob: profile.dateOfBirth ? profile.dateOfBirth.split("T")[0] : "",
          gender: profile.gender || "",
          email: profile.email || "",
          city: profile.currentCity || "",
          state: profile.currentState || "",
          pin: profile.pincode || "",
          summary: profile.about || "",
          availableIn: profile.availableIn || "",
          yearsOfExperience: profile.totalExperienceYears || 0,
          salaryExpectation:
            profile.expectedSalary || profile.salaryExpectation || "",
        };

        setInitialPersonalInfo(personalInfoData);

        setProfileData((prev) => ({
          ...prev,
          country,

          firstName: names[0] || "",
          lastName: names.slice(1).join(" ") || "",

          mobile: profile.mobileNumber || "",
          email: profile.email || "",

          dob: profile.dateOfBirth ? profile.dateOfBirth.split("T")[0] : "",

          gender: profile.gender || "",

          city: profile.currentCity || "",
          state: profile.currentState || "",
          pin: profile.pincode || "",
      tradeCategoryId: profile.tradeCategoryId || null,
subTradeId: profile.subTradeId || null,
          summary: profile.about || "",

          yearsOfExperience: profile.totalExperienceYears || 0,
          trade: profile.role || profile.jobTitle || "",
          nationality: profile.nationality || "",
          salaryExpectation:
            profile.expectedSalary || profile.salaryExpectation || "",
          availableIn: profile.availableIn || "",
          avatar: profile.profilePhotoUrl
            ? buildProfilePhotoUrl(profile.profilePhotoUrl)
            : DEFAULT_PROFILE_PHOTO,
        }));
        // console.log(
        //   "Final Avatar URL:",
        //   profile.profilePhotoUrl
        //     ? buildProfilePhotoUrl(profile.profilePhotoUrl)
        //     : "default-image",
        // );
      }
    } catch (error) {
      console.error("Failed to load profile", error);
    }
  }, [candidateId]);

  useEffect(() => {
    // console.log("API URL =", process.env.NEXT_PUBLIC_API_URL);
    // eslint-disable-next-line react-hooks/set-state-in-effect
    loadPersonalInfo();
    loadAvailability();
  }, [loadPersonalInfo, loadAvailability]);

  //Update profile data to API

  const savePersonalInfo = async () => {
    // console.log("Candidate ID:", candidateId);
    if (!candidateId) {
      showToast("Please log in again to save your profile.", "error");
      return false;
    }
    if (!validatePersonalInfo()) {
      return false;
    }
    // const validatePersonalInfo = () => {
    //   const newErrors = {};

    //   if (!profileData.firstName.trim()) {
    //     newErrors.firstName = "Enter first name";
    //   }

    //   if (!profileData.lastName.trim()) {
    //     newErrors.lastName = "Enter last name";
    //   }

    //   if (!profileData.mobile.trim()) {
    //     newErrors.mobile = "Enter mobile number";
    //   }

    //   if (!profileData.email.trim()) {
    //     newErrors.email = "Enter email address";
    //   }

    //   if (!profileData.trade.trim()) {
    //     newErrors.trade = "Enter trade/job title";
    //   }

    //   console.log("Validation Errors:", newErrors);

    //   setErrors(newErrors);

    //   return Object.keys(newErrors).length === 0;
    // };
    const currentPersonalInfo = {
      fullName: `${profileData.firstName} ${profileData.lastName}`,

      role: profileData.trade,
        tradeCategoryId: profileData.tradeCategoryId || null,
  subTradeId: profileData.subTradeId || null,
      email: profileData.email,
      mobileNumber: profileData.mobile,
      countryCode: "+91",

      dateOfBirth: profileData.dob,
      gender: profileData.gender,
      nationality: profileData.nationality,

      currentCity: profileData.city,
      currentState: profileData.state,
      pincode: profileData.pin,

      about: profileData.summary,

      totalExperienceYears: profileData.yearsOfExperience,
      expectedSalary: profileData.salaryExpectation,

      currentlyAvailableForWork: profileData.availableForWork,

      availableIn: profileData.availableForWork
        ? null
        : profileData.availableIn,
      newsletterOptIn: false,
    };
    // console.log("Sending Payload:", currentPersonalInfo);
    try {

      if (
        profileData.availableForWork === false &&
        !profileData.availableIn
      ) {
        showToast(
          "Please select when you will be available.",
          "error"
        );

        return false;
      }

      await updatePersonalInfo(currentPersonalInfo);

      showToast("Personal information updated successfully", "success");

      if (typeof window !== "undefined") {
        window.dispatchEvent(new Event("profileUpdate"));
      }

      return true;
    } catch (error) {
      console.error(error);

      showToast("Failed to update personal information", "error");

      return false;
    }
    // console.log("SENDING DATA:", currentPersonalInfo);
    const personalChanged =
      JSON.stringify(currentPersonalInfo) !==
      JSON.stringify(initialPersonalInfo);

    try {
      let savedMessage = "Profile saved successfully";
      // console.log("Current:", currentPersonalInfo);
      // console.log("Initial:", initialPersonalInfo);
      // console.log("Changed:", personalChanged);

      if (!personalChanged) {
        await updateAvailability({
          availabilityStatus: profileData.availableForWork
            ? "Available"
            : "Not Available",

          availableIn: profileData.availableForWork
            ? null
            : profileData.availableIn,
        });

        showToast(savedMessage, "success");
        return true;
      }

      const payload = {
        fullName: `${profileData.firstName} ${profileData.lastName}`.trim(),
        mobileNumber: profileData.mobile || "",
        trade: profileData.trade || "",
        jobTitle: profileData.trade || "",
        nationality: profileData.nationality || "",
        dateOfBirth: profileData.dob || null,
        gender: profileData.gender || "",
        email: profileData.email || "",
        currentCity: profileData.city || "",
        currentState: profileData.state || "",
        pincode: profileData.pin || "",
        professionalSummary: profileData.summary || "",
        expectedSalary: Number(profileData.salaryExpectation) || 0,
        salaryExpectation: Number(profileData.salaryExpectation) || 0,
        about: profileData.about || "",
        noticePeriod: profileData.noticePeriod || "",
        totalExperienceYears: Number(profileData.yearsOfExperience) || 0,
        newsletterOptIn: profileData.newsletterOptIn || false,
      };

      const response = await api.put(
        `/api/candidate/profile/personal-info?candidateId=${candidateId}`,
        payload,
      );

      if (response.data.success) {
        await updateAvailability({
          availabilityStatus: profileData.availableForWork
            ? "Available"
            : "Not Available",

          availableIn: profileData.availableForWork
            ? null
            : profileData.availableIn,
        });

        savedMessage = response.data.message || savedMessage;

        setInitialPersonalInfo(currentPersonalInfo);

        showToast(savedMessage, "success");

        // console.log("Profile Completion:", response.data.profileCompletionPct);

        return true; // <-- ADD THIS
      }

      return false; // <-- ADD THIS
    } catch (error) {
      // console.log("STATUS:", error.response?.status);
      // console.log("ERROR DATA:", error.response?.data);
      // console.log("PAYLOAD:", payload);

      console.error("Failed to update profile", error);

      return false;
    }
  };

  // Upload profile photo to API
  // Upload profile photo to API
  const uploadProfile = async (file, previewUrl) => {
    try {
      const response = await uploadProfilePhoto(file);
      // ... rest unchanged

      console.log("PHOTO UPLOADED", response.data);

      const uploadedPhotoUrl =
        response.data?.data?.profilePhotoUrl ||
        response.data?.profilePhotoUrl ||
        response.data?.data?.photoUrl ||
        response.data?.photoUrl;

      if (uploadedPhotoUrl) {
        const uploadedAvatar = buildProfilePhotoUrl(uploadedPhotoUrl);

        storeProfilePhotoPreview(uploadedAvatar);

        setProfileData((prev) => ({
          ...prev,
          avatar: uploadedAvatar,
        }));
      } else if (previewUrl) {
        storeProfilePhotoPreview(previewUrl);

        setProfileData((prev) => ({
          ...prev,
          avatar: previewUrl,
        }));
      }

      showToast("Profile photo uploaded successfully", "success");

      if (typeof window !== "undefined") {
        window.dispatchEvent(new Event("profileUpdate"));
      }
    } catch (error) {
      console.error("UPLOAD ERROR", error);

      console.log("Response Data:", error.response?.data);
      console.log("Status:", error.response?.status);

      showToast("Photo upload failed", "error");
    }
  };

  // Load work experience from API
  const loadWorkExperience = useCallback(async () => {
    if (!candidateId) return;

    try {
      const response = await getWorkExperience();

      if (response.data.success) {
        const workData = response.data.data.map((item) => ({
          id: item.workId,
          title: item.jobTitle,
          company: item.companyName,
          location: item.workLocation,
          startDate: item.startDate ? item.startDate.split("T")[0] : "",
          endDate: item.endDate ? item.endDate.split("T")[0] : "",
          current: item.isCurrent,
          noticePeriod: item.noticePeriod || "",
          description: item.jobDescription || "",
          isOffshore: item.isOffshore || false,
        }));

        setInitialWorkHistory(workData);

        setProfileData((prev) => ({
          ...prev,
          workHistory: workData,
        }));
      }
    } catch (error) {
      console.error("Failed to load work experience", error);
    }
  }, [candidateId]);

  // Work

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    loadWorkExperience();
  }, [loadWorkExperience]);

  const completionPercent = useMemo(() => {
    const checks = [
      Boolean(profileData.firstName && profileData.lastName),
      Boolean(profileData.mobile),
      Boolean(profileData.trade),
      Boolean(profileData.city && profileData.state),
      profileData.workHistory.length > 0,
      profileData.education.length > 0,
      (profileData.selectedSkills || []).length >= 3,
      Boolean(
        profileData.documents?.nationalId?.frontFile ||
        profileData.documents?.nationalId?.file,
      ),
      (profileData.languages || []).length > 0,
      Boolean(profileData.salaryExpectation),
    ];
    return Math.round((checks.filter(Boolean).length / checks.length) * 100);
  }, [profileData]);

  // Which steps get the green check. Derived straight from the loaded data
  // (not from a session-only "did the user click Save" flag), using the same
  // required-field rules as each step's own validation. This is recomputed
  // whenever profileData changes, so it survives a refresh and always
  // reflects what's actually saved on the server.
  const completedSteps = useMemo(() => {
    const set = new Set();

    if (profileCompletion && Array.isArray(profileCompletion.items)) {
      // Check completeness of Steps 1 to 5 based on the checklist items
      for (let stepNum = 1; stepNum <= 5; stepNum++) {
        // Find all checklist items that map to this step
        const stepItems = profileCompletion.items.filter(
          (item) => COMPLETION_ITEM_TO_STEP[item.key] === stepNum
        );

        // If we have items for this step, check if they are all completed
        if (stepItems.length > 0) {
          const allCompleted = stepItems.every((item) => item.completed);
          if (allCompleted) {
            set.add(stepNum);
          }
        }
      }
    }

    // Step 6 (Languages) is not in the checklist, so check local state
    const languagesComplete = (profileData.languages || []).length > 0;
    if (languagesComplete) set.add(6);

    return set;
  }, [profileData, profileCompletion]);

  const updateField = useCallback(
    (field, value) => setProfileData((p) => ({ ...p, [field]: value })),
    [],
  );

  // Work handlers
  // Update existing work experience
  const updateWork = (id, field, value) => {
    setProfileData((prev) => ({
      ...prev,
      workHistory: prev.workHistory.map((work) =>
        work.id === id
          ? {
            ...work,
            [field]: value,
          }
          : work,
      ),
    }));
  };

  const saveWork = async (work) => {
    const originalWork = initialWorkHistory.find((w) => w.id === work.id);

    if (originalWork && JSON.stringify(originalWork) === JSON.stringify(work)) {
      return true;
    }
    if (!validateWorkPayload(work)) {
      return false;
    }

    if (!work?.id || String(work.id).startsWith("work-")) {
      showToast(
        "Please add this work experience again so it can be saved to the server.",
        "error",
      );

      return false;
    }

    try {
      await updateWorkExperience(work.id, buildWorkPayload(work));

      showToast("Work experience updated", "success");

      await loadWorkExperience();
      await loadProfileCompletion();
      return true;
    } catch (error) {
      console.log(
        "Failed to update work experience",
        error.response?.data || error.message,
      );
      showToast("Failed to update work experience", "error");
      return false;
    }
  };

  // Add new work experience

  const addWork = async (entry) => {
    if (!validateWorkPayload(entry)) {
      return false;
    }

    try {
      const payload = buildWorkPayload(entry);

      await createWorkExperience(payload);

      await loadWorkExperience();
      await loadProfileCompletion();

      showToast("Work experience added", "success");
      return true;
    } catch (error) {
      console.log(
        "Failed to add work experience",
        error.response?.data || error.message,
      );
      showToast("Failed to add work experience", "error");
      return false;
    }
  };

  // Remove work experience
  const removeWork = async (workId) => {
    try {
      await deleteWorkExperience(workId);

      await loadWorkExperience();
      await loadProfileCompletion();

      showToast("Work experience removed", "success");
      return true;
    } catch (error) {
      console.log(
        "Failed to remove work experience",
        error.response?.data || error.message,
      );
      showToast("Failed to remove work experience", "error");
      return false;
    }
  };

  const buildWorkPayload = (work) => ({
    jobTitle: work.title || "",
    companyName: work.company || "",
    workLocation: work.location || "",
    startDate: work.startDate || null,
    endDate: work.current ? null : work.endDate || null,
    isCurrent: !!work.current,
    jobDescription: work.description || "",
    noticePeriod: work.noticePeriod || "",
    isOffshore: work.isOffshore || false,
  });

  const validateWorkPayload = (work) => {
    if (!work.title || !work.company) {
      showToast("Role and company name are required.", "error");
      return false;
    }

    if (!work.startDate) {
      showToast("Start date is required.", "error");
      return false;
    }

    if (!work.current && !work.endDate) {
      showToast(
        "End date is required unless this is your current job.",
        "error",
      );
      return false;
    }
    if (
      work.startDate &&
      work.endDate &&
      new Date(work.endDate) < new Date(work.startDate)
    ) {
      showToast("End Date cannot be earlier than Start Date.", "error");
      return false;
    }

    if (work.current && (!work.noticePeriod || !String(work.noticePeriod).trim())) {
      showToast("Notice period is required for your current job.", "error");
      return false;
    }

    return true;
  };

  // Load education from API
  const loadEducation = useCallback(async () => {
    if (!candidateId) return;

    try {
      const response = await getEducation(candidateId);

      if (response.data.success) {
        setProfileData((prev) => ({
          ...prev,
          education: response.data.data.map((item) => ({
            id: item.educationId,
            title: item.qualificationDegree,
            institution: item.instituteName,
            // Affinda-parsed entries populate passoutYear but not yearDetails
            // (that field is really a grade/certificate note). Fall back to
            // the year so it isn't shown as blank when it's actually known.
            meta:
              item.yearDetails ||
              (item.passoutYear ? String(item.passoutYear) : ""),
            certificateNumber: item.certificateNumber || "",
            verified: item.isAiVerified,
          })),
        }));
      }
    } catch (error) {
      console.error(error);
    }
  }, [candidateId]);
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    loadEducation();
  }, [loadEducation]);

  // Education handlers

  // Update existing education entry
  const updateEdu = (id, field, value) => {
    setProfileData((prev) => ({
      ...prev,
      education: prev.education.map((edu) =>
        edu.id === id
          ? {
            ...edu,
            [field]: value,
          }
          : edu,
      ),
    }));
  };
  const validateEducationPayload = (education) => {
    if (!education.title || !String(education.title).trim()) {
      showToast("Qualification / Degree is required.", "error");
      return false;
    }
    return true;
  };

  const saveEducation = async (education) => {
    if (!validateEducationPayload(education)) {
      return false;
    }

    try {
      await updateEducation(
        education.id,

        {
          qualificationDegree: education.title,
          instituteName: education.institution,
          yearDetails: education.meta,
          isAiVerified: education.verified || false,
          passoutYear: extractYear(education.meta),
          certificateNumber: education.certificateNumber || "",
        },
      );

      showToast("Education updated", "success");

      await loadEducation();
      await loadProfileCompletion();
      return true;
    } catch (error) {
      console.log(error.response?.data);
      console.error(error);
      showToast("Failed to update education", "error");
      return false;
    }
  };

  // Add new education entry
  const addEdu = async (entry) => {
    if (!validateEducationPayload(entry)) {
      return false;
    }

    const payload = {
      qualificationDegree: entry.title,
      instituteName: entry.institution,
      yearDetails: entry.meta,
      isAiVerified: false,
      passoutYear: extractYear(entry.meta),
      certificateNumber: "",
    };
    try {
      await createEducation(payload);

      await loadEducation();
      await loadProfileCompletion();

      showToast("Education added", "success");
      return true;
    } catch (error) {
      console.log(error.response?.data);
      console.error(error);
      showToast("Failed to add education", "error");
      return false;
    }
  };

  // Remove education entry
  const removeEdu = async (educationId) => {
    try {
      await deleteEducation(educationId);

      await loadEducation();
      await loadProfileCompletion();

      showToast("Education removed", "success");
    } catch (error) {
      console.log(error.response?.data);
      console.error(error);
    }
  };

  const loadSkills = useCallback(async () => {
    if (!candidateId) return;

    try {
      const response = await getSkills(candidateId);

      if (response.data.success) {
        const skills = response.data.data.skills || [];

        setProfileData((prev) => ({
          ...prev,

          selectedSkills: skills.map((s) => s.skillName),

          skillMatrix: skills.map((s) => ({
            id: s.skillId,
            name: s.skillName,
            proficiency: s.proficiencyLevel || "Beginner",
            years: s.yearsOfExperience || 0,
          })),
        }));
      }
    } catch (error) {
      console.error("Failed to load skills", error);
    }
  }, [candidateId]);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    loadSkills();
  }, [loadSkills]);

  //Add new skill to API
  const addSkill = async (skillName) => {
    try {
      await createSkill({
        skillName,
        proficiencyLevel: "Beginner",
        yearsOfExperience: 1,
      });

      await loadSkills();
      await loadProfileCompletion();

      showToast("Skill added", "success");

      return true;
    } catch (error) {
      console.log("STATUS:", error.response?.status);
      console.log("DATA:", error.response?.data);

      showToast("Failed to add skill", "error");

      return false;
    }
  };
  //Update existing skill in API
  const saveSkill = async (skill) => {
    try {
      const payload = {
        skillName: skill.name,
        proficiencyLevel: skill.proficiency || "Beginner",
        yearsOfExperience: Number(skill.years) || 0,
      };

      console.log("Skill Id:", skill.id);
      console.log("Payload:", payload);

      await updateCandidateSkill(skill.id, payload);

      await loadSkills();
      await loadProfileCompletion();

      showToast("Skill updated", "success");
      return true;
    } catch (error) {
      console.log("STATUS:", error.response?.status);
      console.log("DATA:", error.response?.data);
      console.log("HEADERS:", error.config?.headers);
      console.log("REQUEST DATA:", error.config?.data);

      showToast("Failed to update skill", "error");
      return false;
    }
  };

  //Remove skill from API
  const removeSkill = async (skillId) => {
    try {
      await deleteSkill(skillId);

      await loadSkills();
      await loadProfileCompletion();

      showToast("Skill removed", "success");
      return true;
    } catch (error) {
      console.log(error.response?.data);
      showToast("Failed to remove skill", "error");
      return false;
    }
  };

  const loadLanguages = useCallback(async () => {
    if (!candidateId) return;

    try {
      const response = await getLanguages(candidateId);

      if (response.data.success) {
        const languages = Array.isArray(response.data.data)
          ? response.data.data
          : response.data.data?.languages || [];

        setProfileData((prev) => ({
          ...prev,
          languages: languages.map((item) => ({
            id:
              item.languageId ||
              item.candidateLanguageId ||
              item.id ||
              item.skillId,
            name: item.languageName,
            proficiency: item.proficiencyLevel || "Conversational",
            reading: !!item.canRead,
            writing: !!item.canWrite,
            speaking: !!item.canSpeak,
          })),
        }));
      }
    } catch (error) {
      if (error.response?.status === 404) {
        setProfileData((prev) => ({
          ...prev,
          languages: [],
        }));
        return;
      }

      console.error("Failed to load languages", error);
    }
  }, [candidateId]);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    loadLanguages();
  }, [loadLanguages]);

  // A resume upload (or any other action that dispatches "profileUpdate")
  // can change data across several sections at once via AI parsing — not
  // just Personal Info. Previously this only refreshed Personal Info and
  // the completion percentage, so newly-imported Work Experience, Education,
  // Skills, and Languages sat correctly saved on the server but never
  // reflected in the UI until a full page reload re-ran every load*
  // function from scratch.
  useEffect(() => {
    const handleProfileUpdate = () => {
      loadProfileCompletion();
      loadPersonalInfo();
      loadWorkExperience();
      loadEducation();
      loadSkills();
      loadLanguages();
    };
    if (typeof window !== "undefined") {
      window.addEventListener("profileUpdate", handleProfileUpdate);
    }
    return () => {
      if (typeof window !== "undefined") {
        window.removeEventListener("profileUpdate", handleProfileUpdate);
      }
    };
  }, [
    loadProfileCompletion,
    loadPersonalInfo,
    loadWorkExperience,
    loadEducation,
    loadSkills,
    loadLanguages,
  ]);

  // Add new language to API
  const addLanguage = async (lang) => {
    try {
      await createLanguage({
        languageName: lang.name,
        proficiencyLevel: lang.proficiency,
        canRead: lang.reading,
        canWrite: lang.writing,
        canSpeak: lang.speaking,
      });

      await loadLanguages();

      showToast("Language added", "success");
      return true;
    } catch (error) {
      const errorData = error.response?.data;
      console.log(errorData);

      if (error.response?.status === 409) {
        await loadLanguages();
        showToast(errorData?.message || "Language already added", "info");
        return true;
      }

      showToast("Failed to add language", "error");
      return false;
    }
  };

  const saveLanguage = async (lang) => {
    if (!lang.id || String(lang.id).startsWith("language-")) {
      return addLanguage(lang);
    }

    try {
      await updateLanguage(lang.id, {
        languageName: lang.name,
        proficiencyLevel: lang.proficiency,
        canRead: lang.reading,
        canWrite: lang.writing,
        canSpeak: lang.speaking,
      });

      await loadLanguages();

      showToast("Language updated", "success");
      return true;
    } catch (error) {
      console.log(error.response?.data);
      showToast("Failed to update language", "error");
      return false;
    }
  };

  // Remove language from API
  const removeLanguage = async (languageId) => {
    try {
      await deleteLanguage(languageId);

      await loadLanguages();

      showToast("Language removed", "success");
      return true;
    } catch (error) {
      console.log(error.response?.data);
      showToast("Failed to remove language", "error");
      return false;
    }
  };
  // Skills
  const toggleSkill = async (skill) => {
    const existing = (profileData.skillMatrix || []).find(
      (entry) => entry.name === skill,
    );

    if (existing) {
      if (existing.id && !String(existing.id).startsWith("skill-")) {
        await removeSkill(existing.id);
        return;
      }

      setProfileData((p) => ({
        ...p,
        selectedSkills: (p.selectedSkills || []).filter((s) => s !== skill),
        skillMatrix: (p.skillMatrix || []).filter((e) => e.name !== skill),
      }));
      return;
    }

    await addSkill(skill);
  };
  const updateSkillState = useCallback((id, field, value) => {
    setProfileData((p) => ({
      ...p,
      skillMatrix: p.skillMatrix.map((e) =>
        e.id === id
          ? {
            ...e,
            [field]: value,
            isModified: true, // mark changed
          }
          : e,
      ),
    }));
  }, []);

  const persistAvailability = async (available, availableIn) => {
    try {
      await updateAvailability({
        availabilityStatus: available ? "Available" : "Not Available",
        availableIn: available ? null : availableIn,
      });
      showToast("Availability updated", "success");
      return true;
    } catch (error) {
      console.error("Failed to update availability", error);
      showToast("Failed to update availability", "error");
      return false;
    }
  };

  // Toggle lives in the sidebar. "Available now" saves immediately; "Not
  // available" waits until the candidate picks when they will be available.
  const handleAvailabilityChange = async (checked) => {
    const previous = {
      availableForWork: profileData.availableForWork,
      availableIn: profileData.availableIn,
    };

    setProfileData((prev) => ({
      ...prev,
      availableForWork: checked,
      availableIn: checked ? "" : prev.availableIn,
    }));

    if (checked) {
      const saved = await persistAvailability(true, null);
      if (!saved) setProfileData((prev) => ({ ...prev, ...previous }));
    }
  };

  const handleAvailableInChange = async (value) => {
    setProfileData((prev) => ({ ...prev, availableIn: value }));
    if (value) await persistAvailability(false, value);
  };

  // Documents
  const uploadDoc = useCallback(
    (docKey, file, fieldKey = "file") => {
      const fileData = { name: file.name, size: formatFileSize(file.size) };
      setProfileData((p) => {
        const doc = p.documents[docKey];
        if (!doc) return p;
        const next = { ...doc, [fieldKey]: fileData };
        if (docKey === "nationalId") next.status = "verified";
        else if (docKey !== "itiCertificate") next.status = "uploaded";
        return { ...p, documents: { ...p.documents, [docKey]: next } };
      });
      showToast(`${file.name} uploaded.`, "success");
    },
    [showToast],
  );
  const clearDoc = useCallback(
    (docKey) => {
      setProfileData((p) => {
        const doc = p.documents[docKey];
        if (!doc) return p;
        const next = {
          ...doc,
          file: null,
          frontFile: null,
          status: "optional",
        };
        return { ...p, documents: { ...p.documents, [docKey]: next } };
      });
      showToast("File removed.", "info");
    },
    [showToast],
  );

  // Languages
  const addLang = async (lang) => {
    await addLanguage(lang);
  };
  const removeLang = async (name) => {
    const existing = (profileData.languages || []).find((l) => l.name === name);

    if (existing?.id && !String(existing.id).startsWith("language-")) {
      await removeLanguage(existing.id);
      return;
    }

    setProfileData((p) => ({
      ...p,
      languages: (p.languages || []).filter((l) => l.name !== name),
    }));
    showToast("Language removed.", "info");
  };
  const updateLang = useCallback(
    (name, field, value) =>
      setProfileData((p) => ({
        ...p,
        languages: (p.languages || []).map((l) =>
          l.name === name ? { ...l, [field]: value } : l,
        ),
      })),
    [],
  );

  const handleSaveStep = async () => {
    if (saving) return;

    setSaving(true);

    try {
      // console.log("Current Step:", currentStep);
      if (currentStep === 1) {
        const saved = await savePersonalInfo();
        // console.log("savePersonalInfo returned:", saved);

        if (!saved) {
          // console.log("NOT MOVING TO NEXT STEP");
          return;
        }
      }

      if (currentStep === 3) {
        const serverWorkEntries = profileData.workHistory.filter(
          (work) => work.id && !String(work.id).startsWith("work-"),
        );

        const results = await Promise.all(
          serverWorkEntries.map((work) => saveWork(work)),
        );

        if (results.some((saved) => !saved)) return;
      }

      if (currentStep === 4) {
        const serverEducationEntries = profileData.education.filter(
          (edu) => edu.id && !String(edu.id).startsWith("edu-"),
        );

        const results = await Promise.all(
          serverEducationEntries.map((edu) => saveEducation(edu)),
        );

        if (results.some((saved) => !saved)) return;
      }

      if (currentStep === 5) {
        const results = await Promise.all(
          (profileData.skillMatrix || [])
            .filter((skill) => skill.isModified)
            .map((skill) => {
              if (!skill.id || String(skill.id).startsWith("skill-")) {
                return addSkill(skill.name);
              }

              return saveSkill(skill);
            }),
        );

        if (results.some((saved) => !saved)) return;
      }

      if (currentStep === 6) {
        const results = await Promise.all(
          (profileData.languages || []).map((language) => saveLanguage(language)),
        );

        if (results.some((saved) => !saved)) return;
      }

      const names = [
        "Personal Information",
        "Documents",
        "Work Experience",
        "Education",
        "Skills",
        "Languages",
      ];

      // Don't show a second toast for Personal Information
      if (currentStep !== 1) {
        showToast(`${names[currentStep - 1]} saved!`, "success");
      }

      if (currentStep < TOTAL) {
        setCurrentStep((s) => s + 1);
      } else {
        setDone(true);
      }
    } catch (error) {
      console.error("Save step failed:", error);

      showToast(
        "Something went wrong while saving. Please try again.",
        "error"
      );
    } finally {
      setSaving(false);
    }
  };

  const stepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <StepPersonal

            data={profileData}
            onChange={updateField}
            onPhotoUpload={uploadProfile}
            errors={errors}
          />
        );
      case 2:
        return <MyDocuments />;
      case 3:
        return (
          <StepWork
            data={profileData}
            onUpdate={updateWork}
            onAdd={addWork}
            onRemove={removeWork}
          />
        );
      case 4:
        return (
          <StepEducation
            data={profileData}
            onUpdate={updateEdu}
            onAdd={addEdu}
            onRemove={removeEdu}
          />
        );
      case 5:
        return (
          <StepSkills
            data={profileData}
            onToggle={toggleSkill}
            onUpdateSkill={updateSkillState}
          />
        );
      case 6:
        return (
          <StepLanguages
            data={profileData}
            onAdd={addLang}
            onRemove={removeLang}
            onUpdate={updateLang}
          />
        );
      default:
        return null;
    }
  };

  //Documents
  const loadDocuments = useCallback(async () => {
    try {
      const response = await getDocuments();

      // console.log("DOCUMENTS:", response.data);

      if (response.data.success) {
        const docs = response.data.data;

        setProfileData((prev) => ({
          ...prev,
          documents: {
            ...prev.documents,

            // Resume
            resume: {
              ...prev.documents.resume,
              status: docs.resume ? "uploaded" : "missing",

              file: docs.resume
                ? {
                  id: docs.resume.cvId,
                  name: docs.resume.cvFileUrl.split("/").pop(),
                  url: docs.resume.cvFileUrl,
                }
                : null,

              metaLines: docs.resume
                ? [
                  `Status: ${docs.resume.verificationStatus}`,
                  `Uploaded: ${new Date(
                    docs.resume.uploadedAt,
                  ).toLocaleDateString()}`,
                ]
                : [],
            },

            // Education Certificates
            educationCertificate: {
              ...prev.documents.educationCertificate,

              status:
                docs.educationCertificates?.length > 0 ? "uploaded" : "missing",

              file:
                docs.educationCertificates?.length > 0
                  ? {
                    id: docs.educationCertificates[0].educationId,

                    name: docs.educationCertificates[0].educationLevel,
                  }
                  : null,

              metaLines:
                docs.educationCertificates?.map(
                  (item) => `${item.educationLevel} - ${item.instituteName}`,
                ) || [],
            },

            // Passport
            passport: {
              ...prev.documents.passport,

              status: docs.passport ? "uploaded" : "optional",

              file: docs.passport
                ? {
                  id: docs.passport.passportId,
                  name: docs.passport.passportNumber,
                }
                : null,
            },

            // Aadhaar
            aadhaar: {
              ...prev.documents.aadhaar,

              status: docs.aadhaar ? "uploaded" : "optional",

              file: docs.aadhaar
                ? {
                  id: docs.aadhaar.aadhaarId,
                  name: docs.aadhaar.aadhaarNumber,
                }
                : null,
            },
          },
        }));
      }
    } catch (error) {
      console.error("Failed to load documents", error);
    }
  }, []);

  const handleDocumentUpload = async (docKey, file) => {
    try {
      if (docKey === "resume") {
        await uploadResume(file);
        await loadDocuments();
        return;
      }
      gti;
      if (docKey === "educationCertificate") {
        const education = profile.education[0];

        await uploadEducationCertificate(
          {
            title: education.title,
            institution: education.institution,
            passoutYear: 2024,
            marksPercentage: "75%",
            certificateNumber: "",
          },
          file,
        );

        await loadDocuments();

        showToast("Education certificate uploaded", "success");

        return;
      }
    } catch (error) {
      console.error(error);
      showToast("Upload failed", "error");
    }
  };

  const handleDocumentClear = async (docKey) => {
    try {
      if (docKey === "resume") {
        await deleteResume();

        await loadDocuments();

        showToast("Resume deleted successfully", "success");
        return;
      }
    } catch (error) {
      console.error(error);

      showToast("Resume delete failed", "error");
    }
  };

  return (
    <main className="main">
      <section style={{ padding: "40px 0 60px" }}>
        <div className="container">
          {/* Page header */}
          <div style={{ marginBottom: 32 }}>
            <h2
              style={{
                color: T.navy,
                margin: "0 0 6px",
                fontSize: 26,
                fontWeight: 800,
              }}
            >
              My Profile
            </h2>
            <p style={{ color: T.muted, fontSize: 14, margin: 0 }}>
              Complete your profile to get discovered by top employers
            </p>
          </div>

          <div className="row">
            {/* Left sidebar */}
            <div className="col-lg-3 col-md-4 d-none d-md-block">
              <ProfileMini
                data={profileData}
                percent={profileCompletion?.overallPct || 0}
                currentStep={currentStep}
                onJump={done ? null : (n) => setCurrentStep(n)}
                completedSteps={completedSteps}
                onAvailabilityToggle={handleAvailabilityChange}
                onAvailableInChange={handleAvailableInChange}
              />
            </div>

            {/* Main form area */}
            <div className="col-lg-9 col-md-8 col-sm-12">
              {/* Sidebar is hidden on small screens, so keep the toggle reachable */}
              <div
                className="d-md-none"
                style={{
                  background: T.white,
                  border: `1px solid ${T.border}`,
                  borderRadius: 12,
                  overflow: "hidden",
                  marginBottom: 16,
                }}
              >
                <AvailabilityToggle
                  available={profileData.availableForWork}
                  availableIn={profileData.availableIn}
                  onToggle={handleAvailabilityChange}
                  onAvailableInChange={handleAvailableInChange}
                  bordered={false}
                />
              </div>

              <div
                style={{
                  background: T.white,
                  border: `1px solid ${T.border}`,
                  borderRadius: 16,
                  overflow: "hidden",
                  boxShadow: "0 2px 16px rgba(18,35,89,0.06)",
                }}
              >
                {/* Top stepper */}
                <div
                  style={{
                    padding: "28px 32px 0",
                    borderBottom: `1px solid ${T.border}`,
                  }}
                >
                  <StepBar
                    current={done ? TOTAL + 1 : currentStep}
                    onStepClick={done ? undefined : (n) => setCurrentStep(n)}
                    completedSteps={completedSteps}
                  />
                </div>

                {/* Content area */}
                <div style={{ padding: "32px 32px 24px" }}>
                  {done ? (
                    <CompletionSummary
                      percent={
                        profileCompletion?.overallPct ?? completionPercent
                      }
                      onEdit={() => {
                        setDone(false);
                        setCurrentStep(1);
                      }}
                      onNavigateToItem={(key) => {
                        const step = COMPLETION_ITEM_TO_STEP[key] || 1;
                        setDone(false);
                        setCurrentStep(step);
                      }}
                      completion={profileCompletion}
                      router={router}
                    />
                  ) : (
                    stepContent()
                  )}
                </div>

                {/* Footer nav */}
                {!done && (
                  <div
                    style={{
                      padding: "16px 32px 24px",
                      borderTop: `1px solid ${T.border}`,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                    }}
                  >
                    <Btn
                      variant="outline"
                      onClick={() => setCurrentStep((s) => Math.max(1, s - 1))}
                      disabled={currentStep === 1}
                      style={{ border: `1.5px solid ${T.orange}` }}
                    >
                      <i
                        className="fi-rr-arrow-small-left"
                        aria-hidden="true"
                      />
                      Back
                    </Btn>
                    <div
                      style={{ display: "flex", alignItems: "center", gap: 6 }}
                    >
                      {STEPS.map((_, i) => (
                        <div
                          key={i}
                          style={{
                            width: i + 1 === currentStep ? 20 : 7,
                            height: 7,
                            borderRadius: 4,
                            background: completedSteps.has(i + 1)
                              ? T.success
                              : i + 1 === currentStep
                                ? T.orange
                                : T.border,
                            transition: "all .2s",
                          }}
                        />
                      ))}
                    </div>
                    <Btn
                      onClick={handleSaveStep}
                      disabled={saving}
                    >
                      {saving ? (
                        <>
                          <span
                            style={{
                              width: 14,
                              height: 14,
                              border: "2px solid rgba(255,255,255,0.4)",
                              borderTopColor: "#fff",
                              borderRadius: "50%",
                              display: "inline-block",
                              animation: "profileSaveSpin 0.7s linear infinite",
                            }}
                          />
                          <span>Saving...</span>
                        </>
                      ) : currentStep === TOTAL ? (
                        <>
                          <span>Save & Complete</span>
                          <i className="fi-rr-check" aria-hidden="true" />
                        </>
                      ) : (
                        <>
                          <span>Save & Continue</span>
                          <i
                            className="fi-rr-arrow-small-right"
                            aria-hidden="true"
                          />
                        </>
                      )}
                    </Btn>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>
      <style jsx>{`
  @keyframes profileSaveSpin {
    to {
      transform: rotate(360deg);
    }
  }
`}</style>
    </main>

  );


};

export default CandidateProfilePage;